const DEFAULTS = {
  transport: 'stdio',
  agent: 'codex',
  restBase: '',
  siteUrl: '',
  siteFingerprint: '',
  token: '',
  sessionToken: '',
  httpBasicUsername: '',
  httpBasicPassword: '',
  pairingScopes: 'read,preview,write',
  projectLabel: '',
  wpRoot: '',
  agentWorkspaceRoot: '',
  framework: '',
  toolProfile: 'full',
  host: '127.0.0.1',
  port: 7681,
  tool: '',
  toolArgs: {},
  output: 'json',
  allowParentThemeWrites: false,
  verbose: false
}

function loadConfig(argv = []) {
  const config = {
    transport: process.env.LCFA_TRANSPORT || DEFAULTS.transport,
    agent: process.env.LCFA_AGENT || DEFAULTS.agent,
    restBase: process.env.LCFA_REST_BASE || DEFAULTS.restBase,
    siteUrl: process.env.LCFA_SITE_URL || DEFAULTS.siteUrl,
    siteFingerprint: process.env.LCFA_SITE_FINGERPRINT || DEFAULTS.siteFingerprint,
    token: process.env.LCFA_MCP_TOKEN || DEFAULTS.token,
    sessionToken: process.env.LCFA_MCP_SESSION || process.env.LCFA_MCP_SESSION_TOKEN || DEFAULTS.sessionToken,
    httpBasicUsername: process.env.LCFA_HTTP_BASIC_USERNAME || DEFAULTS.httpBasicUsername,
    httpBasicPassword: process.env.LCFA_HTTP_BASIC_PASSWORD || DEFAULTS.httpBasicPassword,
    pairingScopes: process.env.LCFA_PAIRING_SCOPES || DEFAULTS.pairingScopes,
    projectLabel: process.env.LCFA_PROJECT_LABEL || DEFAULTS.projectLabel,
    wpRoot: process.env.LCFA_WP_ROOT || DEFAULTS.wpRoot,
    agentWorkspaceRoot: process.env.LCFA_AGENT_WORKSPACE_ROOT || DEFAULTS.agentWorkspaceRoot,
    framework: process.env.LCFA_FRAMEWORK || DEFAULTS.framework,
    toolProfile: process.env.LCFA_TOOL_PROFILE || DEFAULTS.toolProfile,
    host: process.env.LCFA_MCP_HOST || DEFAULTS.host,
    port: parsePort(process.env.LCFA_MCP_PORT || DEFAULTS.port),
    tool: process.env.LCFA_TOOL || DEFAULTS.tool,
    toolArgs: parseToolArguments(process.env.LCFA_TOOL_ARGS || ''),
    output: process.env.LCFA_OUTPUT || DEFAULTS.output,
    allowParentThemeWrites: process.env.LCFA_ALLOW_PARENT_THEME_WRITES === '1',
    verbose: process.env.LCFA_VERBOSE === '1'
  }

  for (let index = 0; index < argv.length; index += 1) {
    const item = argv[index]

    if (!item.startsWith('--')) {
      continue
    }

    const option = item.slice(2)
    const separatorIndex = option.indexOf('=')
    const rawKey = separatorIndex === -1 ? option : option.slice(0, separatorIndex)
    const inlineValue = separatorIndex === -1 ? undefined : option.slice(separatorIndex + 1)
    const key = rawKey.trim()
    const value = inlineValue !== undefined ? inlineValue : argv[index + 1]

    if (inlineValue === undefined && argv[index + 1] && !argv[index + 1].startsWith('--')) {
      index += 1
    }

    switch (key) {
      case 'transport':
        config.transport = value || config.transport
        break
      case 'agent':
        config.agent = value || config.agent
        break
      case 'rest-base':
        config.restBase = value || config.restBase
        break
      case 'site-url':
        config.siteUrl = value || config.siteUrl
        break
      case 'site-fingerprint':
        config.siteFingerprint = value || config.siteFingerprint
        break
      case 'token':
        config.token = value || config.token
        break
      case 'session':
      case 'session-token':
        config.sessionToken = value || config.sessionToken
        break
      case 'pairing-scopes':
        config.pairingScopes = value || config.pairingScopes
        break
      case 'project-label':
        config.projectLabel = value || config.projectLabel
        break
      case 'wp-root':
        config.wpRoot = value || config.wpRoot
        break
      case 'agent-workspace-root':
        config.agentWorkspaceRoot = value || config.agentWorkspaceRoot
        break
      case 'framework':
        config.framework = value || config.framework
        break
      case 'tool-profile':
        config.toolProfile = value || config.toolProfile
        break
      case 'host':
        config.host = value || config.host
        break
      case 'port':
        config.port = parsePort(value)
        break
      case 'tool':
        config.tool = value || config.tool
        break
      case 'tool-args':
        config.toolArgs = parseToolArguments(value)
        break
      case 'output':
        config.output = value || config.output
        break
      case 'allow-parent-theme-writes':
        config.allowParentThemeWrites = true
        break
      case 'verbose':
        config.verbose = true
        break
      default:
        break
    }
  }

  config.restBase = normalizeRestBase(config.restBase, config.siteUrl)
  config.framework = normalizeFramework(config.framework)
  config.toolProfile = normalizeToolProfile(config.toolProfile)

  if (!['stdio', 'bridge'].includes(config.transport)) {
    throw new Error(`Unsupported transport "${config.transport}". Use stdio or bridge.`)
  }

  if (!['json', 'pretty'].includes(config.output)) {
    throw new Error(`Unsupported output "${config.output}". Use json or pretty.`)
  }

  if (!config.restBase) {
    throw new Error('Missing REST base. Set LCFA_REST_BASE or pass --rest-base.')
  }

  return config
}

function normalizeFramework(value) {
  const framework = String(value || '').trim().toLowerCase()
  return ['picowind', 'picostrap'].includes(framework) ? framework : ''
}

function normalizeToolProfile(value) {
  return String(value || '').trim().toLowerCase() === 'compact' ? 'compact' : 'full'
}

function normalizeRestBase(restBase, siteUrl) {
  if (restBase) {
    return ensureTrailingSlash(restBase)
  }

  if (!siteUrl) {
    return ''
  }

  return ensureTrailingSlash(`${siteUrl.replace(/\/$/, '')}/wp-json/lcfa/v1`)
}

function ensureTrailingSlash(value) {
  return value.endsWith('/') ? value : `${value}/`
}

function parsePort(value) {
  const port = Number.parseInt(String(value), 10)

  if (Number.isNaN(port) || port < 1 || port > 65535) {
    return DEFAULTS.port
  }

  return port
}

function parseToolArguments(value) {
  if (!value) {
    return {}
  }

  if (typeof value === 'object') {
    return value
  }

  try {
    const parsed = JSON.parse(String(value))
    return parsed && typeof parsed === 'object' ? parsed : {}
  } catch (error) {
    throw new Error('Invalid --tool-args payload. Pass a valid JSON object.')
  }
}

module.exports = {
  loadConfig
}
