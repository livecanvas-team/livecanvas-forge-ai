const PROTOCOL_VERSION = '2024-11-05'
const SUPPORTED_PROTOCOL_VERSIONS = ['2024-11-05', '2025-06-18', '2025-11-25']
const fs = require('node:fs')
const PACKAGE_VERSION = String(require('../package.json').version || 'unknown')
const { workflowDiscovery } = require('./workflow-discovery')

async function runStdioServer({ client, tools, config }) {
  process.stdin.resume()
  let buffer = Buffer.alloc(0)
  const debugLogPath = process.env.LCFA_MCP_DEBUG_LOG || ''

  debugLog(debugLogPath, `server.start transport=stdio agent=${config && config.agent ? config.agent : ''}`)

  if (config.verbose) {
    void client.getMcpStatus()
      .then((preflight) => {
        process.stderr.write(`[livecanvas-forge-mcp] connected to ${preflight.mcp.endpoint}\n`)
      })
      .catch((error) => {
        process.stderr.write(`[livecanvas-forge-mcp] preflight failed: ${error instanceof Error ? error.message : String(error)}\n`)
      })
  }

  process.stdin.on('data', async (chunk) => {
    debugLog(debugLogPath, `stdin.chunk bytes=${chunk.length} preview=${previewChunk(chunk)}`)
    buffer = Buffer.concat([buffer, chunk])
    const parsed = extractMessages(buffer)
    buffer = parsed.remaining

    for (const entry of parsed.messages) {
      const message = entry && entry.message ? entry.message : entry
      const format = entry && entry.format ? entry.format : 'content-length'

      try {
        await handleMessage(message, tools, debugLogPath, format)
      } catch (error) {
        debugLog(debugLogPath, `message.error id=${message && Object.prototype.hasOwnProperty.call(message, 'id') ? message.id : 'none'} method=${message && message.method ? message.method : ''} error=${error instanceof Error ? error.message : String(error)}`)
        if (message && Object.prototype.hasOwnProperty.call(message, 'id')) {
          writeError(message.id, -32000, error instanceof Error ? error.message : String(error), debugLogPath, format)
        }
      }
    }
  })
}

async function handleMessage(message, tools, debugLogPath = '', format = 'content-length') {
  const method = message.method
  debugLog(debugLogPath, `message.received id=${Object.prototype.hasOwnProperty.call(message, 'id') ? message.id : 'none'} method=${method || ''}`)

  if (method === 'notifications/initialized') {
    return
  }

  if (method === 'initialize') {
    const negotiatedProtocolVersion = resolveProtocolVersion(message)

    writeResponse(message.id, {
      protocolVersion: negotiatedProtocolVersion,
      instructions: 'Call get_connection_handoff to verify the site. Discover workflow descriptions with list_workflows and read only the relevant body with read_workflow before generating changes; the same workflows are available as MCP resources and prompts. Before any site mutation call get_write_context for the exact content ID, URL or child-theme path. Inspect the actual renderer, framework, roots and shared impact. Pass write_context unchanged and refresh after each mutation. Picowind uses Tailwind/WindPress; DaisyUI and Typography require compile evidence. Picostrap uses Bootstrap/Sass. Keep layout CSS/scripts out of editorial content. Content and child-theme source writes return private changesets: use list_changesets and undo_changeset with fresh target_id or file path context. Local file writes use the authenticated WordPress coordinator; never bypass failure with shell writes. Compiler-cache and whole-site Undo remain unqualified. Report saved, compiled, visually verified and published separately. Compare a reference layout before restoring it. Bridge cannot enforce these rules for arbitrary shell or database operations.',
      capabilities: {
        tools: {},
        resources: {},
        prompts: {}
      },
      serverInfo: {
        name: 'livecanvas-ai-bridge-mcp',
        version: PACKAGE_VERSION
      }
    }, debugLogPath, format)

    return
  }

  if (method === 'server/discover') {
    writeResponse(message.id, buildServerDiscovery(tools), debugLogPath, format)
    return
  }

  if (method === 'ping') {
    writeResponse(message.id, {}, debugLogPath, format)
    return
  }

  if (method === 'tools/list') {
    writeResponse(message.id, {
      tools: tools.list(),
      _meta: {
        'io.livecanvas/cache-ttl-ms': 30000,
        'io.livecanvas/cache-scope': 'site_session'
      }
    }, debugLogPath, format)

    return
  }

  if (method === 'tools/call') {
    const toolName = message.params && message.params.name ? message.params.name : ''
    const args = message.params && message.params.arguments ? message.params.arguments : {}
    const result = await tools.invoke(toolName, args)
    const responseResult = formatToolResultForMcp(toolName, result)

    writeResponse(message.id, {
      content: [
        {
          type: 'text',
          text: JSON.stringify(responseResult, null, 2)
        }
      ],
      structuredContent: responseResult,
      isError: result?.ok === false || result?.result?.ok === false
    }, debugLogPath, format)

    return
  }

  const discovery = await workflowDiscovery(method, message.params || {}, tools)
  if (discovery !== null) {
    writeResponse(message.id, discovery, debugLogPath, format)
    return
  }

  writeError(message.id, -32601, `Unsupported method "${method}"`, debugLogPath, format)
}

function formatToolResultForMcp(toolName, result) {
  if (toolName !== 'content_patch_preview' && toolName !== 'content_patch_apply') {
    return result
  }

  const wrapped = isPlainObject(result) && isPlainObject(result.result)
  const source = wrapped ? result.result : result

  if (!isPlainObject(source)) {
    return result
  }

  const data = isPlainObject(source.data) ? source.data : {}
  const patch = isPlainObject(source.content_patch) ? source.content_patch : {}
  const audit = isPlainObject(data.audit)
    ? data.audit
    : (isPlainObject(source.audit) ? source.audit : {})
  const publicPreview = isPlainObject(data.public_preview)
    ? data.public_preview
    : (isPlainObject(source.public_preview) ? source.public_preview : {})
  const frameworkValidation = compactFrameworkValidation(source.framework_validation)
  const compact = {
    ok: source.ok !== false,
    action: source.action || '',
    mode: source.mode || (toolName === 'content_patch_preview' ? 'preview' : 'apply'),
    message: source.message || '',
    summary: source.summary || '',
    target_type: source.target_type || '',
    target_id: source.target_id || 0,
    target_title: source.target_title || '',
    operation: patch.operation || source.operation || '',
    match_count: numberOrZero(patch.match_count ?? source.match_count),
    changed: Boolean(patch.changed ?? source.changed),
    framework_validation: frameworkValidation,
    warnings: Array.isArray(source.warnings) ? source.warnings : [],
    frontend_url: source.frontend_url || data.frontend_url || '',
    edit_url: source.edit_url || data.edit_url || '',
    preview_url: source.preview_url || publicPreview.url || '',
    preview_expires_at: publicPreview.expires_at || '',
    audit_id: source.audit_id || audit.id || '',
    rollback_available: Boolean(source.rollback_available ?? audit.rollback_available),
    rollback_reference: isPlainObject(audit.rollback_reference) ? audit.rollback_reference : {},
    changeset: isPlainObject(source.changeset) ? source.changeset : {},
    verification_states: isPlainObject(source.verification_states) ? source.verification_states : {},
    response_detail: 'compact',
    omitted_fields: ['existing_html', 'patched_html', 'diff_html']
  }

  return wrapped ? { ...result, result: compact } : compact
}

function compactFrameworkValidation(validation) {
  if (!isPlainObject(validation)) {
    return {}
  }

  const data = isPlainObject(validation.data) ? validation.data : {}
  const warnings = Array.isArray(validation.warnings)
    ? validation.warnings
    : (Array.isArray(data.warnings) ? data.warnings : [])

  return {
    ok: validation.ok !== false,
    valid: Object.prototype.hasOwnProperty.call(data, 'valid') ? Boolean(data.valid) : validation.ok !== false,
    framework: data.framework || validation.framework || '',
    validation_error: data.validation_error || validation.validation_error || '',
    warnings
  }
}

function numberOrZero(value) {
  const parsed = Number(value)
  return Number.isFinite(parsed) ? parsed : 0
}

function isPlainObject(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value)
}

function extractMessages(buffer) {
  const messages = []
  let working = buffer

  while (working.length > 0) {
    if (looksLikeHeaderFramedMessage(working)) {
      const separator = resolveHeaderSeparator(working)
      const headerEnd = separator.index

      if (headerEnd === -1) {
        break
      }

      const headerBlock = working.slice(0, headerEnd).toString('utf8')
      const lengthMatch = headerBlock.match(/Content-Length:\s*(\d+)/i)

      if (!lengthMatch) {
        throw new Error('Missing Content-Length header')
      }

      const contentLength = Number.parseInt(lengthMatch[1], 10)
      const messageEnd = headerEnd + separator.length + contentLength

      if (working.length < messageEnd) {
        break
      }

      const rawMessage = working.slice(headerEnd + separator.length, messageEnd).toString('utf8')
      messages.push({
        message: JSON.parse(rawMessage),
        format: 'content-length'
      })
      working = working.slice(messageEnd)
      continue
    }

    const newlineIndex = working.indexOf('\n')

    if (newlineIndex === -1) {
      break
    }

    const rawLine = working.slice(0, newlineIndex).toString('utf8').replace(/\r$/, '').trim()
    working = working.slice(newlineIndex + 1)

    if (rawLine === '') {
      continue
    }

    messages.push({
      message: JSON.parse(rawLine),
      format: 'ndjson'
    })
  }

  return {
    messages,
    remaining: working
  }
}

function resolveHeaderSeparator(buffer) {
  const crlfIndex = buffer.indexOf('\r\n\r\n')

  if (crlfIndex !== -1) {
    return {
      index: crlfIndex,
      length: 4
    }
  }

  const lfIndex = buffer.indexOf('\n\n')

  return {
    index: lfIndex,
    length: lfIndex === -1 ? 0 : 2
  }
}

function looksLikeHeaderFramedMessage(buffer) {
  const preview = buffer.slice(0, 32).toString('utf8')
  return /^Content-Length:/i.test(preview)
}

function resolveProtocolVersion(message) {
  const requested = message && message.params && typeof message.params.protocolVersion === 'string'
    ? message.params.protocolVersion.trim()
    : ''

  if (requested && SUPPORTED_PROTOCOL_VERSIONS.includes(requested)) {
    return requested
  }

  return PROTOCOL_VERSION
}

function buildServerDiscovery(tools) {
  return {
    protocolVersions: SUPPORTED_PROTOCOL_VERSIONS,
    capabilities: {
      tools: {
        ttlMs: 30000,
        cacheScope: 'site_session'
      }
    },
    serverInfo: {
      name: 'livecanvas-ai-bridge-mcp',
      version: PACKAGE_VERSION
    },
    tools: tools.list(),
    ttlMs: 30000,
    cacheScope: 'site_session'
  }
}

function writeResponse(id, result, debugLogPath = '', format = 'content-length') {
  debugLog(debugLogPath, `message.response id=${id}`)
  writeMessage({
    jsonrpc: '2.0',
    id,
    result
  }, format)
}

function writeError(id, code, message, debugLogPath = '', format = 'content-length') {
  debugLog(debugLogPath, `message.error_response id=${id} code=${code} message=${message}`)
  writeMessage({
    jsonrpc: '2.0',
    id,
    error: {
      code,
      message
    }
  }, format)
}

function writeMessage(message, format = 'content-length') {
  const payload = JSON.stringify(message)
  if (format === 'ndjson') {
    process.stdout.write(`${payload}\n`)
    return
  }

  process.stdout.write(`Content-Length: ${Buffer.byteLength(payload, 'utf8')}\r\n\r\n${payload}`)
}

function debugLog(debugLogPath, line) {
  if (!debugLogPath) {
    return
  }

  try {
    fs.appendFileSync(debugLogPath, `[${new Date().toISOString()}] ${line}\n`)
  } catch (error) {
    // ignore debug logging failures
  }
}

function previewChunk(chunk) {
  return chunk
    .toString('utf8')
    .replace(/\r/g, '\\r')
    .replace(/\n/g, '\\n')
    .slice(0, 240)
}

module.exports = {
  runStdioServer,
  formatToolResultForMcp
}
