<?php

defined('ABSPATH') || exit;

if (!class_exists('LCFA_Thread_Message_Actions', false) && defined('LCFA_DIR')) {
    require_once LCFA_DIR . 'includes/class-lcfa-thread-message-actions.php';
}
if (!class_exists('LCFA_Genesis_Executor', false) && defined('LCFA_DIR')) {
    require_once LCFA_DIR . 'includes/class-lcfa-genesis-executor.php';
}
if (!class_exists('LCFA_Direct_Agent_Onboarding', false) && defined('LCFA_DIR')) {
    require_once LCFA_DIR . 'includes/class-lcfa-direct-agent-onboarding.php';
}
if (!class_exists('LCFA_Power_Mode', false) && defined('LCFA_DIR')) {
    require_once LCFA_DIR . 'includes/class-lcfa-power-mode.php';
}
if (!class_exists('LCFA_Theme_Library_Catalog', false) && defined('LCFA_DIR')) {
    require_once LCFA_DIR . 'includes/class-lcfa-theme-library-catalog.php';
}
if (!class_exists('LCFA_Theme_Library_Validator', false) && defined('LCFA_DIR')) {
    require_once LCFA_DIR . 'includes/class-lcfa-theme-library-validator.php';
}
if (!class_exists('LCFA_Theme_Library_Installer', false) && defined('LCFA_DIR')) {
    require_once LCFA_DIR . 'includes/class-lcfa-theme-library-installer.php';
}
if (!class_exists('LCFA_Theme_Library_Importer', false) && defined('LCFA_DIR')) {
    require_once LCFA_DIR . 'includes/class-lcfa-theme-library-importer.php';
}
if (!class_exists('LCFA_Theme_Library_Rollback', false) && defined('LCFA_DIR')) {
    require_once LCFA_DIR . 'includes/class-lcfa-theme-library-rollback.php';
}

final class LCFA_Admin {
    private const THEME_LIBRARY_PREVIEW_TRANSIENT_PREFIX = 'lcfa_theme_library_preview_';
    private const THEME_LIBRARY_PREVIEW_TTL = 1800;

    private LCFA_Environment $environment;
    private LCFA_Installer $installer;
    private LCFA_Inventory $inventory;
    private LCFA_Theme_Files_Bridge $theme_files_bridge;
    private LCFA_Connection_Tester $connection_tester;
    private ?LCFA_Connection_Diagnostics $connection_diagnostics = null;
    private LCFA_Remote_Client $remote_client;
    private LCFA_Context_Builder $context_builder;
    private LCFA_Connection_Onboarding $connection_onboarding;
    private ?LCFA_Direct_Agent_Onboarding $direct_agent_onboarding = null;
    private ?LCFA_Power_Mode $power_mode = null;
    private LCFA_Connection_Wizard_Presenter $connection_wizard_presenter;
    private LCFA_Admin_Hero_Presenter $admin_hero_presenter;
    private LCFA_Command_Deck $command_deck;
    private LCFA_Prompt_Suggester $prompt_suggester;
    private LCFA_Genesis_Planner $genesis_planner;
    private ?LCFA_Genesis_Executor $genesis_executor = null;
    private ?LCFA_Ability_Registry $ability_registry = null;
    private LCFA_Theme_Library_Catalog $theme_library_catalog;
    private LCFA_Theme_Library_Installer $theme_library_installer;
    private LCFA_Theme_Library_Importer $theme_library_importer;
    private LCFA_Theme_Library_Rollback $theme_library_rollback;

    public function __construct(LCFA_Environment $environment, LCFA_Installer $installer, LCFA_Inventory $inventory, LCFA_Theme_Files_Bridge $theme_files_bridge, LCFA_Connection_Tester $connection_tester, LCFA_Remote_Client $remote_client, LCFA_Context_Builder $context_builder, LCFA_Connection_Onboarding $connection_onboarding, LCFA_Command_Deck $command_deck, LCFA_Prompt_Suggester $prompt_suggester, LCFA_Genesis_Planner $genesis_planner, ?LCFA_Genesis_Executor $genesis_executor = null, ?LCFA_Ability_Registry $ability_registry = null, ?LCFA_Design_System_Build_Gateway $design_system_build_gateway = null) {
        $this->environment  = $environment;
        $this->installer    = $installer;
        $this->inventory    = $inventory;
        $this->theme_files_bridge = $theme_files_bridge;
        $this->connection_tester = $connection_tester;
        $this->connection_diagnostics = new LCFA_Connection_Diagnostics($environment);
        $this->remote_client = $remote_client;
        $this->context_builder = $context_builder;
        $this->connection_onboarding = $connection_onboarding;
        $this->direct_agent_onboarding = new LCFA_Direct_Agent_Onboarding();
        $this->power_mode = new LCFA_Power_Mode();
        $this->connection_wizard_presenter = new LCFA_Connection_Wizard_Presenter();
        $this->admin_hero_presenter = new LCFA_Admin_Hero_Presenter();
        $this->command_deck = $command_deck;
        $this->prompt_suggester = $prompt_suggester;
        $this->genesis_planner = $genesis_planner;
        $this->genesis_executor = $genesis_executor;
        $this->ability_registry = $ability_registry;
        $theme_library_validator = new LCFA_Theme_Library_Validator();
        $theme_library_windpress_bridge = new LCFA_WindPress_Bridge($environment);
        $this->theme_library_catalog = new LCFA_Theme_Library_Catalog();
        $this->theme_library_installer = new LCFA_Theme_Library_Installer($theme_library_validator, $theme_library_windpress_bridge);
        $this->theme_library_rollback = new LCFA_Theme_Library_Rollback($theme_library_windpress_bridge);
        $this->theme_library_importer = new LCFA_Theme_Library_Importer($this->theme_library_installer, $theme_library_validator, $theme_library_windpress_bridge, $design_system_build_gateway, $this->theme_library_rollback);
    }

    public function hooks(): void {
        add_action('admin_menu', [$this, 'register_menus'], 20);
        add_action('current_screen', [$this, 'suppress_external_admin_notices'], 0);
        add_action('admin_notices', [$this, 'render_picostrap_windpress_admin_notice']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('admin_init', [$this, 'maybe_redirect_after_activation']);
        add_action('wp_ajax_lcfa_connections_secondary', [$this, 'handle_connections_secondary_ajax']);
        add_action('admin_post_lcfa_setup', [$this, 'handle_setup_post']);
        add_action('admin_post_lcfa_reset_setup', [$this, 'handle_reset_setup_post']);
        add_action('admin_post_lcfa_connections', [$this, 'handle_connections_post']);
        add_action('admin_post_lcfa_test_connections', [$this, 'handle_connection_test_post']);
        add_action('admin_post_lcfa_install_client_bundle', [$this, 'handle_install_client_bundle_post']);
        add_action('admin_post_lcfa_download_client_bundle', [$this, 'handle_download_client_bundle_post']);
        add_action('admin_post_lcfa_repair_codex_connection', [$this, 'handle_repair_codex_connection_post']);
        add_action('admin_post_lcfa_install_mcp_adapter', [$this, 'handle_install_mcp_adapter_post']);
        add_action('admin_post_lcfa_run_connection_diagnostics', [$this, 'handle_run_connection_diagnostics_post']);
        add_action('admin_post_lcfa_mcp_pairing_approve', [$this, 'handle_mcp_pairing_approve_post']);
        add_action('admin_post_lcfa_mcp_session_revoke', [$this, 'handle_mcp_session_revoke_post']);
        add_action('admin_post_lcfa_reconfigure_connection', [$this, 'handle_reconfigure_connection_post']);
        add_action('admin_post_lcfa_resolve_framework_change_connection', [$this, 'handle_framework_change_connection_post']);
        add_action('admin_post_lcfa_deactivate_redundant_windpress', [$this, 'handle_deactivate_redundant_windpress_post']);
        add_action('admin_post_lcfa_project_brief', [$this, 'handle_project_brief_post']);
        add_action('admin_post_lcfa_generate_plan', [$this, 'handle_generate_plan_post']);
        add_action('admin_post_lcfa_genesis_execute', [$this, 'handle_genesis_execute_post']);
        add_action('admin_post_lcfa_theme_library', [$this, 'handle_theme_library_post']);
        add_action('admin_post_lcfa_create_thread', [$this, 'handle_create_thread_post']);
        add_action('admin_post_lcfa_command', [$this, 'handle_command_post']);
        add_action('lc_editor_header', [$this, 'render_editor_bridge_styles']);
        add_action('lc_editor_before_body_closing', [$this, 'render_editor_bridge']);
    }

    public function suppress_external_admin_notices($screen = null): void {
        if (!$this->is_forge_dashboard_request()) {
            return;
        }

        $hooks = [
            'network_admin_notices',
            'user_admin_notices',
            'admin_notices',
            'all_admin_notices',
        ];

        $screen_id = '';
        if (is_object($screen) && isset($screen->id) && is_scalar($screen->id)) {
            $screen_id = sanitize_key((string) $screen->id);
        }

        if ($screen_id !== '') {
            $hooks[] = $screen_id . '_admin_notices';
        }

        foreach ($hooks as $hook) {
            remove_all_actions($hook);
        }
    }

    public function render_picostrap_windpress_admin_notice(): void {
        if (!current_user_can('activate_plugins')) {
            return;
        }

        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        $screen_id = is_object($screen) && isset($screen->id) ? (string) $screen->id : '';
        if (!in_array($screen_id, ['plugins', 'plugins-network'], true)) {
            return;
        }

        $outcome = sanitize_key((string) ($_GET['lcfa_windpress'] ?? ''));
        if ($outcome === 'deactivated') {
            echo '<div class="notice notice-success is-dismissible"><p><strong>';
            echo esc_html__('WindPress deactivated.', 'livecanvas-forge-ai');
            echo '</strong> ' . esc_html__('The active Picostrap theme continues to use its Bootstrap and Sass build.', 'livecanvas-forge-ai');
            echo '</p></div>';
            return;
        }

        $snapshot = $this->environment->get_snapshot();
        if (!$this->should_recommend_windpress_deactivation($snapshot)) {
            return;
        }

        echo '<div class="notice notice-warning lcfa-windpress-framework-notice">';
        echo '<p><strong>' . esc_html__('WindPress is not used by the active Picostrap theme.', 'livecanvas-forge-ai') . '</strong></p>';
        echo '<p>' . esc_html__('Picostrap uses Bootstrap and Sass. WindPress is needed for Picowind, Tailwind, or DaisyUI projects, so you can deactivate it on this site.', 'livecanvas-forge-ai') . '</p>';
        $this->render_windpress_deactivate_form('plugins', false);
        echo '</div>';
    }

    public function handle_deactivate_redundant_windpress_post(): void {
        if (!current_user_can('activate_plugins')) {
            wp_die(esc_html__('You do not have permission to deactivate plugins.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_deactivate_redundant_windpress');

        $return_to = sanitize_key((string) ($_POST['return_to'] ?? 'dashboard'));
        $snapshot = $this->environment->get_snapshot();
        if (!$this->should_recommend_windpress_deactivation($snapshot)) {
            LCFA_Settings::set_notice(__('WindPress was not changed because the active framework no longer requires this recommendation.', 'livecanvas-forge-ai'), 'error');
            $this->redirect_after_windpress_action($return_to, 'unchanged');
        }

        $plugin_file = (string) ($snapshot['windpress_plugin_file'] ?? '');
        if ($plugin_file === '') {
            LCFA_Settings::set_notice(__('WindPress could not be located, so no plugin was changed.', 'livecanvas-forge-ai'), 'error');
            $this->redirect_after_windpress_action($return_to, 'failed');
        }

        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        $network_wide = is_multisite() && function_exists('is_plugin_active_for_network') && is_plugin_active_for_network($plugin_file);
        if ($network_wide && !current_user_can('manage_network_plugins')) {
            LCFA_Settings::set_notice(__('WindPress is network-active. A network administrator must deactivate it.', 'livecanvas-forge-ai'), 'error');
            $this->redirect_after_windpress_action($return_to, 'failed');
        }

        deactivate_plugins($plugin_file, false, $network_wide);
        $still_active = is_plugin_active($plugin_file)
            || ($network_wide && function_exists('is_plugin_active_for_network') && is_plugin_active_for_network($plugin_file));

        if ($still_active) {
            LCFA_Settings::set_notice(__('WordPress could not deactivate WindPress. Review plugin or network permissions.', 'livecanvas-forge-ai'), 'error');
            $this->redirect_after_windpress_action($return_to, 'failed');
        }

        if (method_exists($this->environment, 'refresh_plugin_caches')) {
            $this->environment->refresh_plugin_caches();
        }

        LCFA_Settings::set_notice(__('WindPress deactivated. Picostrap remains active and continues to use Bootstrap and Sass.', 'livecanvas-forge-ai'), 'success');
        $this->redirect_after_windpress_action($return_to, 'deactivated');
    }

    public function handle_theme_library_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You do not have permission to manage the Theme Library.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_theme_library');

        $operation = sanitize_key((string) ($_POST['operation'] ?? ''));
        $slug = sanitize_key((string) ($_POST['slug'] ?? ''));
        $force = !empty($_POST['force']);
        $audit_id = sanitize_key((string) ($_POST['audit_id'] ?? ''));
        $result = [
            'ok'      => false,
            'message' => __('Unknown Theme Library action.', 'livecanvas-forge-ai'),
        ];

        if ($operation === 'install_framework') {
            $framework = $this->normalize_supported_framework((string) ($_POST['framework'] ?? ''));
            if ($framework === '') {
                $result = [
                    'ok'      => false,
                    'message' => __('Unsupported Theme Library framework.', 'livecanvas-forge-ai'),
                ];
            } else {
                $install_result = $this->installer->apply_framework($framework);
                if (is_wp_error($install_result)) {
                    $result = [
                        'ok'      => false,
                        'message' => $install_result->get_error_message(),
                    ];
                } else {
                    $result = [
                        'ok'      => true,
                        'message' => sprintf(
                            /* translators: %s: framework name. */
                            __('%s is installed and ready for Theme Library imports.', 'livecanvas-forge-ai'),
                            $this->get_framework_display_name($framework)
                        ),
                    ];
                }
            }
        } elseif ($operation === 'rollback') {
            $result = $this->theme_library_rollback->rollback($audit_id, false);
        } elseif ($operation === 'build') {
            $result = $this->theme_library_importer->build($slug);
        } else {
            $theme = $this->theme_library_catalog->get_theme($slug, $force);
            if (empty($theme['ok'])) {
                $result = $theme;
            } elseif ($operation === 'preview') {
                $result = $this->theme_library_installer->preview($theme['theme']);
                if (!empty($result['ok'])) {
                    $this->remember_theme_library_preview($slug, $theme['theme'], $result);
                }
            } elseif ($operation === 'install') {
                $result = $this->theme_library_installer->install($theme['theme']);
            } elseif ($operation === 'import') {
                $result = $this->theme_library_importer->import($theme['theme'], $force);
            }
        }

        $message = (string) ($result['message'] ?? '');
        if ($message === '') {
            $message = !empty($result['ok'])
                ? __('Theme Library action completed.', 'livecanvas-forge-ai')
                : __('Theme Library action failed.', 'livecanvas-forge-ai');
        }

        if (!empty($result['ok']) && $operation === 'preview') {
            $theme_name = is_array($result['theme'] ?? null) ? (string) ($result['theme']['name'] ?? $slug) : $slug;
            $message = sprintf(
                /* translators: 1: theme name, 2: checksum. */
                __('Preview passed for %1$s. ZIP, checksum, manifest, Picowind child theme header, content files, and media references are valid. Checksum: %2$s', 'livecanvas-forge-ai'),
                $theme_name,
                substr((string) ($result['checksum'] ?? ''), 0, 12)
            );
        }

        $import_completed = !empty($result['ok'])
            && $operation === 'import'
            && in_array((string) ($result['status'] ?? 'ready'), ['ready', 'build_required', 'build_failed'], true);
        if ($import_completed) {
            $message = sprintf(
                /* translators: 1: page ID, 2: header ID, 3: footer ID. */
                __('Starter data imported. Homepage #%1$d, header #%2$d, footer #%3$d.', 'livecanvas-forge-ai'),
                (int) ($result['homepage_id'] ?? 0),
                (int) ($result['header_id'] ?? 0),
                (int) ($result['footer_id'] ?? 0)
            );
        }

        if (!empty($result['import_audit_id'])) {
            $message .= ' ' . sprintf(
                /* translators: %s: import audit ID. */
                __('Import audit ID: %s', 'livecanvas-forge-ai'),
                sanitize_key((string) $result['import_audit_id'])
            );
        }

        LCFA_Settings::set_notice($message, !empty($result['ok']) ? 'success' : 'error');
        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=theme-library'));
        exit;
    }

    public function register_menus(): void {
        $parent_slug = $this->environment->get_livecanvas_menu_slug();
        $admin_capability = 'manage_options';

        if ($parent_slug) {
            add_submenu_page(
                $parent_slug,
                __('AI Bridge', 'livecanvas-forge-ai'),
                __('AI Bridge', 'livecanvas-forge-ai'),
                $admin_capability,
                'lcfa-dashboard',
                [$this, 'render_dashboard_page']
            );

            return;
        }

        add_menu_page(
            __('LiveCanvas AI Bridge', 'livecanvas-forge-ai'),
            __('AI Bridge', 'livecanvas-forge-ai'),
            $admin_capability,
            'lcfa-dashboard',
            [$this, 'render_dashboard_page'],
            'dashicons-superhero-alt',
            59
        );

    }

    public function enqueue_assets(string $hook_suffix): void {
        if (strpos($hook_suffix, 'lcfa-') === false) {
            return;
        }

        wp_enqueue_style(
            'lcfa-prism',
            LCFA_URL . 'assets/vendor/prism/prism-tomorrow.min.css',
            [],
            '1.29.0'
        );

        wp_enqueue_style(
            'lcfa-admin',
            LCFA_URL . 'assets/admin.css',
            ['lcfa-prism'],
            LCFA_VERSION
        );

        wp_enqueue_style(
            'lcfa-admin-v2',
            LCFA_URL . 'assets/admin-v2.css',
            ['lcfa-admin'],
            LCFA_VERSION
        );

        wp_enqueue_script(
            'lcfa-prism-core',
            LCFA_URL . 'assets/vendor/prism/prism-core.min.js',
            [],
            '1.29.0',
            true
        );

        wp_enqueue_script(
            'lcfa-prism-markup',
            LCFA_URL . 'assets/vendor/prism/prism-markup.min.js',
            ['lcfa-prism-core'],
            '1.29.0',
            true
        );

        wp_enqueue_script(
            'lcfa-prism-clike',
            LCFA_URL . 'assets/vendor/prism/prism-clike.min.js',
            ['lcfa-prism-core'],
            '1.29.0',
            true
        );

        wp_enqueue_script(
            'lcfa-prism-javascript',
            LCFA_URL . 'assets/vendor/prism/prism-javascript.min.js',
            ['lcfa-prism-clike'],
            '1.29.0',
            true
        );

        wp_enqueue_script(
            'lcfa-prism-bash',
            LCFA_URL . 'assets/vendor/prism/prism-bash.min.js',
            ['lcfa-prism-core'],
            '1.29.0',
            true
        );

        wp_enqueue_script(
            'lcfa-prism-json',
            LCFA_URL . 'assets/vendor/prism/prism-json.min.js',
            ['lcfa-prism-javascript'],
            '1.29.0',
            true
        );

        wp_enqueue_script(
            'lcfa-admin-script',
            LCFA_URL . 'assets/admin.js',
            ['lcfa-prism-markup', 'lcfa-prism-bash', 'lcfa-prism-json'],
            LCFA_VERSION,
            true
        );

        wp_enqueue_script(
            'lcfa-studio-app',
            LCFA_URL . 'assets/studio-app.js',
            ['wp-element', 'wp-api-fetch'],
            LCFA_VERSION,
            true
        );

        wp_localize_script('lcfa-admin-script', 'lcfaAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'restUrl' => rest_url('lcfa/v1/'),
            'restNonce' => wp_create_nonce('wp_rest'),
            'studioEndpoint' => rest_url('lcfa/v1/studio'),
            'connectionsSecondaryAction' => 'lcfa_connections_secondary',
            'connectionsSecondaryNonce' => wp_create_nonce('lcfa_connections_secondary'),
            'labels' => [
                'loading' => __('Loading connection details…', 'livecanvas-forge-ai'),
                'loadFailed' => __('Failed to load connection details. Refresh the page or try again in a moment.', 'livecanvas-forge-ai'),
                'studioNoAbilities' => __('No abilities match the current filters.', 'livecanvas-forge-ai'),
                'studioNoRuns' => __('No runs match the current filters.', 'livecanvas-forge-ai'),
            ],
        ]);

        wp_localize_script('lcfa-studio-app', 'lcfaStudio', [
            'endpoint' => rest_url('lcfa/v1/studio'),
            'nonce'    => wp_create_nonce('wp_rest'),
            'links'    => [
                'connections' => admin_url('admin.php?page=lcfa-dashboard&tab=connections'),
                'command'     => admin_url('admin.php?page=lcfa-dashboard&tab=command'),
            ],
            'labels'   => [
                'loading' => __('Loading AI Studio…', 'livecanvas-forge-ai'),
                'loadFailed' => __('AI Studio app could not load. The PHP fallback remains available below.', 'livecanvas-forge-ai'),
                'retry' => __('Retry', 'livecanvas-forge-ai'),
                'emptyAbilities' => __('No abilities match the current filters.', 'livecanvas-forge-ai'),
                'emptyRuns' => __('No runs match the current filters.', 'livecanvas-forge-ai'),
            ],
        ]);
    }

    public function maybe_redirect_after_activation(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        if (!get_option(LCFA_Settings::REDIRECT_OPTION_KEY)) {
            return;
        }

        delete_option(LCFA_Settings::REDIRECT_OPTION_KEY);

        if (wp_doing_ajax() || isset($_GET['activate-multi'])) {
            return;
        }

        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=setup'));
        exit;
    }

    public function handle_connections_secondary_ajax(): void {
        if (!current_user_can('manage_options')) {
            wp_send_json_error([
                'message' => __('Insufficient permissions.', 'livecanvas-forge-ai'),
            ], 403);
        }

        check_ajax_referer('lcfa_connections_secondary', 'nonce');

        $settings         = LCFA_Settings::get();
        $connections      = LCFA_Settings::get_connections();
        $preferred_client = $this->normalize_connection_client((string) ($connections['preferred_client'] ?: ($settings['ai_tool'] ?: 'codex')));
        $workspace_root   = (string) ($connections['workspace_root'] ?? '');
        $mcp_status       = $this->context_builder->get_mcp_status();
        $mcp_bootstrap    = $this->context_builder->get_bootstrap_payload();
        $remote_status    = $this->remote_client->get_status();
        $preferred_bootstrap = $mcp_bootstrap['clients'][$preferred_client] ?? ($mcp_bootstrap['clients']['codex'] ?? ['command' => '', 'env' => []]);
        $command_example  = wp_json_encode([
            'action'  => 'site_audit',
            'dry_run' => true,
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

        ob_start();
        $this->render_remote_companion_card($remote_status);
        $remote_html = (string) ob_get_clean();

        ob_start();
        $this->render_advanced_connection_settings(
            $connections,
            $preferred_client,
            $mcp_status,
            $preferred_bootstrap,
            $this->build_common_bootstrap_block($mcp_bootstrap),
            $command_example,
            $workspace_root
        );
        $advanced_html = (string) ob_get_clean();

        ob_start();
        $this->render_ability_diagnostics_card($this->get_ability_diagnostics_for_admin());
        $diagnostics_html = (string) ob_get_clean();

        wp_send_json_success([
            'panels' => [
                'remote'      => $remote_html,
                'advanced'    => $advanced_html,
                'diagnostics' => $diagnostics_html,
            ],
        ]);
    }

    public function render_editor_bridge_styles(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        $asset_root    = defined('LCFA_DIR') ? LCFA_DIR : dirname(__DIR__) . '/';
        $asset_version = rawurlencode((string) LCFA_VERSION . '-' . (string) max(
            file_exists($asset_root . 'assets/editor-chat.css') ? (int) filemtime($asset_root . 'assets/editor-chat.css') : 0,
            file_exists($asset_root . 'assets/editor-chat.js') ? (int) filemtime($asset_root . 'assets/editor-chat.js') : 0
        ));
        $css_url       = add_query_arg(['ver' => $asset_version], LCFA_URL . 'assets/editor-chat.css');
        $js_url        = add_query_arg(['ver' => $asset_version], LCFA_URL . 'assets/editor-chat.js');

        echo '<link rel="stylesheet" id="lcfa-editor-chat-css" href="' . esc_url($css_url) . '">';
        echo '<script id="lcfa-editor-chat-js" src="' . esc_url($js_url) . '" defer></script>';
    }

    public function render_editor_bridge(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        global $post;

        if (!$post instanceof WP_Post) {
            return;
        }

        $snapshot = $this->environment->get_snapshot();
        $context = $this->get_command_context_for_post($post);
        $actions = $this->get_editor_bridge_actions($post, $context);
        $thread_summaries = array_slice(LCFA_Settings::get_thread_summaries(), 0, 8);
        $current_thread_id = LCFA_Settings::normalize_thread_id((string) ($_GET['thread_id'] ?? 'default'));
        $thread_payloads = [];
        $current_thread_messages = [];

        foreach ($thread_summaries as $thread_summary) {
            if (!is_array($thread_summary)) {
                continue;
            }

            $thread_id = LCFA_Settings::normalize_thread_id((string) ($thread_summary['id'] ?? 'default'));
            $thread = LCFA_Settings::get_thread($thread_id);
            $thread_messages = array_map(function ($message) use ($thread_id) {
                return is_array($message)
                    ? LCFA_Thread_Message_Actions::decorate_message($message, [
                        'thread_id' => $thread_id,
                        'command_url_builder' => [$this, 'get_command_url'],
                    ])
                    : $message;
            }, array_slice((array) ($thread['messages'] ?? []), -8));

            $thread_payloads[$thread_id] = [
                'id'       => $thread_id,
                'title'    => (string) ($thread_summary['title'] ?? $thread_id),
                'state'    => $this->get_editor_initial_conversation_state($thread_messages),
                'messages' => $thread_messages,
            ];

            if ($thread_id === $current_thread_id) {
                $current_thread_messages = $thread_messages;
            }
        }

        if ($current_thread_messages === []) {
            $current_thread = LCFA_Settings::get_thread($current_thread_id);
            $current_thread_messages = array_map(function ($message) use ($current_thread_id) {
                return is_array($message)
                    ? LCFA_Thread_Message_Actions::decorate_message($message, [
                        'thread_id' => $current_thread_id,
                        'command_url_builder' => [$this, 'get_command_url'],
                    ])
                    : $message;
            }, array_slice((array) ($current_thread['messages'] ?? []), -8));
            $thread_payloads[$current_thread_id] = [
                'id'       => $current_thread_id,
                'title'    => $current_thread_id,
                'state'    => $this->get_editor_initial_conversation_state($current_thread_messages),
                'messages' => $current_thread_messages,
            ];
        }

        $initial_conversation_state = $this->get_editor_initial_conversation_state($current_thread_messages);
        $initial_conversation_label = $this->get_editor_conversation_state_label($initial_conversation_state);
        $remote_status              = $this->remote_client->get_status();
        $connections                = LCFA_Settings::get_connections();
        $connected_client           = sanitize_key((string) ($connections['preferred_client'] ?? ''));
        $connection_state           = (($connections['connection_status'] ?? '') === 'ready') ? 'connected' : 'disconnected';
        $connection_icon_client     = $connected_client !== '' ? $connected_client : 'generic';
        $agent_processor            = $connected_client === 'generic' ? 'generic_mcp' : ($connected_client !== '' ? $connected_client . '_mcp' : 'forge_local_rules');
        $default_action             = !empty($context['action']) ? (string) $context['action'] : 'site_audit';
        $codex_runtime_defaults     = LCFA_Settings::sanitize_codex_options([
            'model'            => $connections['codex_model'] ?? '',
            'speed'            => $connections['codex_speed'] ?? '',
            'reasoning_effort' => $connections['codex_reasoning_effort'] ?? '',
            'sandbox'          => $connections['codex_sandbox'] ?? '',
        ]);
        $command_base_url           = $this->get_command_url([
            'post_id'   => $post->ID,
            'thread_id' => $current_thread_id,
        ]);
        $editor_config = [
            'restEndpoint' => rest_url('lcfa/v1/chat/send'),
            'threadEndpoint' => rest_url('lcfa/v1/chat/thread'),
            'agentRequestEndpoint' => rest_url('lcfa/v1/agent/request'),
            'commandEndpoint' => rest_url('lcfa/v1/command'),
            'commandExecutionEndpoint' => rest_url('lcfa/v1/command/execution'),
            'restNonce'    => wp_create_nonce('wp_rest'),
            'commandBaseUrl' => $command_base_url,
            'agent'        => [
                'client'       => $connected_client,
                'state'        => $connection_state,
                'enabled'      => $connection_state === 'connected' && $connected_client !== '',
                'processor'    => $agent_processor,
                'displayLabel' => $connected_client !== '' ? ucfirst(str_replace(['-', '_'], ' ', $connected_client)) : __('AI Bridge', 'livecanvas-forge-ai'),
            ],
            'codex'       => [
                'enabled'   => $connected_client === 'codex',
                'defaults'  => $codex_runtime_defaults,
                'models'    => LCFA_Settings::get_codex_model_options(),
                'speed'     => LCFA_Settings::get_codex_speed_options(),
                'reasoning' => LCFA_Settings::get_codex_reasoning_effort_options(),
                'sandbox'   => LCFA_Settings::get_codex_sandbox_options(),
            ],
            'postId'       => (int) $post->ID,
            'targetId'     => (int) ($context['target_id'] ?? 0),
            'variant'      => (string) ($context['variant'] ?? '1'),
            'defaultAction'=> $default_action,
            'threadId'     => $current_thread_id,
            'threads'      => $thread_payloads,
            'threadSummaries' => array_values($thread_summaries),
            'labels'       => [
                'requestRequired' => __('Write a request first so AI Bridge can suggest an action.', 'livecanvas-forge-ai'),
                'analysisFailed'  => __('The request analysis failed.', 'livecanvas-forge-ai'),
                'whySuggested'    => __('Why this was suggested', 'livecanvas-forge-ai'),
                'warnings'        => __('Warnings', 'livecanvas-forge-ai'),
                'recommendedWorkflow' => __('Recommended workflow', 'livecanvas-forge-ai'),
                'recommendedPreflight' => __('Recommended preflight payload', 'livecanvas-forge-ai'),
                'openDeck'        => __('Open suggested payload in Command Deck', 'livecanvas-forge-ai'),
                'previewSuggestion' => __('Preview', 'livecanvas-forge-ai'),
                'previewing'      => __('Preparing preview...', 'livecanvas-forge-ai'),
                'applySuggestion' => __('Apply', 'livecanvas-forge-ai'),
                'applying'        => __('Applying change...', 'livecanvas-forge-ai'),
                'applyFailed'     => __('The inline execution failed.', 'livecanvas-forge-ai'),
                'idleState'       => __('Ready for a new request.', 'livecanvas-forge-ai'),
                'thinkingState'   => __('Sending request...', 'livecanvas-forge-ai'),
                'suggestedState'  => __('Request prepared.', 'livecanvas-forge-ai'),
                'previewedState'  => __('Preview ready. Review the support details below.', 'livecanvas-forge-ai'),
                'appliedState'    => __('Change applied inline.', 'livecanvas-forge-ai'),
                'failedState'     => __('The current request failed. Review the support details below.', 'livecanvas-forge-ai'),
                'queuedState'     => __('Queued for inline execution.', 'livecanvas-forge-ai'),
                'runningState'    => __('Running inline execution...', 'livecanvas-forge-ai'),
                'agentQueuedState' => __('Waiting for the connected coding agent...', 'livecanvas-forge-ai'),
                'agentRunningState' => __('The coding agent is processing this request...', 'livecanvas-forge-ai'),
                'agentTimeoutState' => __('Request queued. Keep the coding agent open, process the AI Bridge frontend queue, then this panel will update.', 'livecanvas-forge-ai'),
                'creatingThread'  => __('Creating thread...', 'livecanvas-forge-ai'),
                'duplicatingThread' => __('Duplicating thread...', 'livecanvas-forge-ai'),
                'renamingThread'  => __('Renaming thread...', 'livecanvas-forge-ai'),
                'clearingThread'  => __('Clearing thread...', 'livecanvas-forge-ai'),
                'deletingThread'  => __('Deleting thread...', 'livecanvas-forge-ai'),
                'renameThreadPrompt' => __('Rename the current thread', 'livecanvas-forge-ai'),
                'confirmClearThread' => __('Clear all messages from the current thread?', 'livecanvas-forge-ai'),
                'confirmDeleteThread' => __('Delete the current thread and switch back to the default one?', 'livecanvas-forge-ai'),
                'newThreadLabel'  => __('New thread', 'livecanvas-forge-ai'),
                'duplicateThreadLabel' => __('Duplicate current', 'livecanvas-forge-ai'),
                'renameThreadLabel' => __('Rename current', 'livecanvas-forge-ai'),
                'clearThreadLabel' => __('Clear current', 'livecanvas-forge-ai'),
                'deleteThreadLabel' => __('Delete current', 'livecanvas-forge-ai'),
                'viewPage'        => __('View page', 'livecanvas-forge-ai'),
                'editPage'        => __('Edit page', 'livecanvas-forge-ai'),
                'openTemplate'    => __('Open template', 'livecanvas-forge-ai'),
                'openThemeFile'   => __('Open theme file', 'livecanvas-forge-ai'),
                'openThemeTemplate' => __('Open theme template', 'livecanvas-forge-ai'),
                'openBackup'      => __('Open backup', 'livecanvas-forge-ai'),
                'analyzeSuggestion' => __('Send', 'livecanvas-forge-ai'),
                'analyzing'       => __('Sending...', 'livecanvas-forge-ai'),
                'attachScreenshot' => __('Upload image', 'livecanvas-forge-ai'),
                'clearScreenshot' => __('Remove image', 'livecanvas-forge-ai'),
                'screenshotReady' => __('Image ready for this request.', 'livecanvas-forge-ai'),
                'dropScreenshotTitle' => __('Upload image', 'livecanvas-forge-ai'),
                'dropScreenshotHint' => __('Add a reference screenshot if needed.', 'livecanvas-forge-ai'),
                'diffPreview'     => __('Diff preview', 'livecanvas-forge-ai'),
                'currentMarkup'   => __('Current markup', 'livecanvas-forge-ai'),
                'proposedMarkup'  => __('Proposed markup', 'livecanvas-forge-ai'),
            ],
        ];

        echo '<div class="lcfa-editor-shell" data-lcfa-editor-shell>';
        echo '<button type="button" class="lcfa-editor-launcher" data-lcfa-editor-open>';
        echo $this->get_icon_svg('stars');
        echo '<span class="lcfa-editor-launcher__label">' . esc_html__('AI Bridge', 'livecanvas-forge-ai') . '</span>';
        echo '</button>';
        echo '<aside class="lcfa-editor-drawer" aria-hidden="true">';
        echo '<div class="lcfa-editor-bridge__head">';
        echo '<div>';
        echo '<span class="lcfa-editor-bridge__eyebrow">' . esc_html__('AI Bridge', 'livecanvas-forge-ai') . '</span>';
        echo '<p class="lcfa-editor-bridge__title">' . esc_html(sprintf(__('You are in: %s', 'livecanvas-forge-ai'), get_the_title($post->ID) ?: __('Untitled', 'livecanvas-forge-ai'))) . '</p>';
        echo '<p class="lcfa-editor-bridge__target-line" data-lcfa-editor-target-summary>' . esc_html($this->get_editor_target_summary($post, $context)) . '</p>';
        echo '<div class="lcfa-editor-bridge__connection" data-state="' . esc_attr($connection_state) . '">';
        echo '<span class="lcfa-editor-bridge__connection-media">' . $this->get_agent_icon_markup($connection_icon_client, $this->get_client_fallback_icon($connection_icon_client), 'lcfa-agent-icon lcfa-agent-icon--editor-status') . '</span>';
        echo '<span class="lcfa-editor-bridge__connection-copy">' . esc_html($this->get_editor_connection_status_label($connected_client, $connection_state)) . '</span>';
        echo '</div>';
        echo '<div class="lcfa-editor-bridge__connection" data-state="' . esc_attr($connection_state === 'connected' ? 'connected' : 'local') . '">';
        echo '<span class="lcfa-editor-bridge__connection-media">' . $this->get_icon_svg('stars') . '</span>';
        echo '<span class="lcfa-editor-bridge__connection-copy">' . esc_html($connection_state === 'connected' ? sprintf(__('Frontend prompts: %s MCP', 'livecanvas-forge-ai'), ucfirst(str_replace(['-', '_'], ' ', $connected_client))) : __('Frontend prompts: Bridge local fallback', 'livecanvas-forge-ai')) . '</span>';
        echo '</div>';
        echo '</div>';
        echo '<div class="lcfa-editor-bridge__head-actions">';
        echo '<a class="lcfa-editor-bridge__head-link is-icon-only" href="' . esc_url($command_base_url) . '" target="_blank" rel="noreferrer noopener" aria-label="' . esc_attr__('Open Command Deck', 'livecanvas-forge-ai') . '" title="' . esc_attr__('Open Command Deck', 'livecanvas-forge-ai') . '" data-lcfa-editor-open-deck>';
        echo $this->get_icon_svg('command');
        echo '</a>';
        echo '<button type="button" class="lcfa-editor-bridge__close" data-lcfa-editor-close aria-label="' . esc_attr__('Close AI Bridge panel', 'livecanvas-forge-ai') . '">' . $this->get_icon_svg('power') . '</button>';
        echo '</div>';
        echo '</div>';
        if ($connected_client === 'codex') {
            echo '<div class="lcfa-editor-bridge__runtime-top">';
            echo '<div class="lcfa-editor-bridge__codex-runtime">';
            echo '<div class="lcfa-editor-bridge__row lcfa-editor-bridge__runtime-primary">';
            echo '<label class="lcfa-editor-bridge__field">';
            echo '<span>' . esc_html__('Model', 'livecanvas-forge-ai') . '</span>';
            echo '<select data-lcfa-editor-codex-model>';
            foreach (LCFA_Settings::get_codex_model_options() as $value => $label) {
                echo '<option value="' . esc_attr((string) $value) . '"' . selected((string) $value, $codex_runtime_defaults['model'], false) . '>' . esc_html((string) $label) . '</option>';
            }
            echo '</select>';
            echo '</label>';
            echo '<label class="lcfa-editor-bridge__field">';
            echo '<span>' . esc_html__('Intelligence', 'livecanvas-forge-ai') . '</span>';
            echo '<select data-lcfa-editor-codex-reasoning>';
            foreach (LCFA_Settings::get_codex_reasoning_effort_options() as $value => $label) {
                echo '<option value="' . esc_attr((string) $value) . '"' . selected((string) $value, $codex_runtime_defaults['reasoning_effort'], false) . '>' . esc_html((string) $label) . '</option>';
            }
            echo '</select>';
            echo '</label>';
            echo '</div>';
            echo '<details class="lcfa-editor-bridge__runtime-details">';
            echo '<summary>' . esc_html__('Runtime options', 'livecanvas-forge-ai') . '</summary>';
            echo '<div class="lcfa-editor-bridge__row lcfa-editor-bridge__runtime-advanced">';
            echo '<label class="lcfa-editor-bridge__field">';
            echo '<span>' . esc_html__('Speed', 'livecanvas-forge-ai') . '</span>';
            echo '<select data-lcfa-editor-codex-speed>';
            foreach (LCFA_Settings::get_codex_speed_options() as $value => $label) {
                echo '<option value="' . esc_attr((string) $value) . '"' . selected((string) $value, $codex_runtime_defaults['speed'], false) . '>' . esc_html((string) $label) . '</option>';
            }
            echo '</select>';
            echo '</label>';
            echo '<label class="lcfa-editor-bridge__field">';
            echo '<span>' . esc_html__('Sandbox', 'livecanvas-forge-ai') . '</span>';
            echo '<select data-lcfa-editor-codex-sandbox>';
            foreach (LCFA_Settings::get_codex_sandbox_options() as $value => $label) {
                echo '<option value="' . esc_attr((string) $value) . '"' . selected((string) $value, $codex_runtime_defaults['sandbox'], false) . '>' . esc_html((string) $label) . '</option>';
            }
            echo '</select>';
            echo '</label>';
            echo '</div>';
            echo '</details>';
            echo '</div>';
            echo '</div>';
        }
        echo '<div class="lcfa-editor-bridge__section">';
        echo '<div class="lcfa-editor-bridge__label">' . esc_html__('Request', 'livecanvas-forge-ai') . '</div>';
        echo '<p class="lcfa-editor-bridge__helper">' . esc_html($connection_state === 'connected' ? sprintf(__('Describe the change you want on this page. AI Bridge sends it to %s through MCP and updates this LiveCanvas page when the agent completes it.', 'livecanvas-forge-ai'), ucfirst(str_replace(['-', '_'], ' ', $connected_client))) : __('Describe the change you want on this page. AI Bridge sends it and runs it inline on the current page.', 'livecanvas-forge-ai')) . '</p>';
        echo '<div class="lcfa-editor-bridge__controls" data-lcfa-editor-composer>';
        echo '<textarea data-lcfa-editor-prompt placeholder="' . esc_attr__('Example: refresh this header with a simpler navigation and keep the current logo.', 'livecanvas-forge-ai') . '"></textarea>';
        echo '<div class="lcfa-editor-bridge__attachment-row">';
        echo '<input type="file" accept="image/*" hidden data-lcfa-editor-attachment>';
        echo '<button type="button" class="lcfa-editor-bridge__button is-neutral is-upload" data-lcfa-editor-attachment-trigger>';
        echo $this->get_icon_svg('image');
        echo '<span data-lcfa-editor-button-label>' . esc_html__('Upload image', 'livecanvas-forge-ai') . '</span>';
        echo '</button>';
        echo '<button type="button" class="lcfa-editor-bridge__button is-neutral" hidden data-lcfa-editor-attachment-clear>';
        echo $this->get_icon_svg('x-circle');
        echo '<span data-lcfa-editor-button-label>' . esc_html__('Remove image', 'livecanvas-forge-ai') . '</span>';
        echo '</button>';
        echo '</div>';
        echo '<div class="lcfa-editor-bridge__attachment-preview-card" hidden data-lcfa-editor-attachment-preview>';
        echo '<img class="lcfa-editor-bridge__attachment-preview-image" data-lcfa-editor-attachment-preview-image alt="" hidden>';
        echo '<div class="lcfa-editor-bridge__attachment-preview-copy">';
        echo '<span class="lcfa-editor-bridge__attachment-meta" data-lcfa-editor-attachment-preview-meta></span>';
        echo '</div>';
        echo '</div>';
        echo '<div class="lcfa-editor-bridge__actions">';
        echo '<button type="button" class="lcfa-editor-bridge__button is-primary is-step-primary" data-lcfa-editor-analyze disabled>';
        echo $this->get_icon_svg('stars');
        echo '<span data-lcfa-editor-button-label>' . esc_html__('Send', 'livecanvas-forge-ai') . '</span>';
        echo '</button>';
        echo '</div>';
        echo '<p class="lcfa-editor-bridge__action-note">' . esc_html($connection_state === 'connected' ? __('Send queues the prompt for the connected coding agent. The drawer waits for the MCP result, then refreshes the LiveCanvas editor.', 'livecanvas-forge-ai') : __('Send analyzes the request and executes the change immediately on this page.', 'livecanvas-forge-ai')) . '</p>';
        echo '</div>';
        echo '</div>';
        echo '<div class="lcfa-editor-bridge__section">';
        echo '<div class="lcfa-editor-bridge__label">' . esc_html__('Conversation', 'livecanvas-forge-ai') . '</div>';
        echo '<div class="lcfa-editor-bridge__thread-bar">';
        echo '<span class="lcfa-editor-bridge__thread-status" data-lcfa-editor-status data-state="' . esc_attr($initial_conversation_state) . '">' . esc_html($initial_conversation_label) . '</span>';
        echo '</div>';
        echo '<div class="lcfa-editor-thread-log" data-lcfa-editor-thread-log>';
        foreach ($current_thread_messages as $message) {
            if (!is_array($message)) {
                continue;
            }

            if (($message['role'] ?? '') === 'suggestion_result') {
                continue;
            }

            $this->render_editor_bridge_thread_message($message);
        }
        echo '</div>';
        echo '<p class="lcfa-editor-thread-empty"' . ($current_thread_messages ? ' hidden' : '') . ' data-lcfa-editor-thread-empty>' . esc_html__('No messages yet. Send a request to start this thread.', 'livecanvas-forge-ai') . '</p>';
        echo '</div>';
        echo '<details class="lcfa-editor-bridge__details" data-lcfa-editor-session-details>';
        echo '<summary>' . esc_html__('Session settings', 'livecanvas-forge-ai') . '</summary>';
        echo '<div class="lcfa-editor-bridge__details-body">';
        echo '<div class="lcfa-editor-bridge__row">';
        echo '<label class="lcfa-editor-bridge__field">';
        echo '<span>' . esc_html__('Thread', 'livecanvas-forge-ai') . '</span>';
        echo '<select data-lcfa-editor-thread>';
        foreach ($thread_summaries as $thread_summary) {
            if (!is_array($thread_summary)) {
                continue;
            }

            $thread_id = (string) ($thread_summary['id'] ?? 'default');
            echo '<option value="' . esc_attr($thread_id) . '"' . selected($thread_id, $current_thread_id, false) . '>' . esc_html((string) ($thread_summary['title'] ?? $thread_id)) . '</option>';
        }
        echo '</select>';
        echo '</label>';
        echo '<label class="lcfa-editor-bridge__field">';
        echo '<span>' . esc_html__('Execution target', 'livecanvas-forge-ai') . '</span>';
        echo '<select data-lcfa-editor-target>';
        echo '<option value="local">' . esc_html__('Local site', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="remote"' . (!empty($remote_status['configured']) ? '' : ' disabled') . '>' . esc_html__('Remote site', 'livecanvas-forge-ai') . '</option>';
        echo '</select>';
        echo '</label>';
        echo '</div>';
        echo '<div class="lcfa-editor-bridge__actions is-thread-tools">';
        echo '<button type="button" class="lcfa-editor-bridge__button is-neutral" data-lcfa-editor-thread-create>';
        echo $this->get_icon_svg('plus');
        echo '<span>' . esc_html__('New thread', 'livecanvas-forge-ai') . '</span>';
        echo '</button>';
        echo '<button type="button" class="lcfa-editor-bridge__button is-neutral" data-lcfa-editor-thread-duplicate>';
        echo $this->get_icon_svg('copy');
        echo '<span>' . esc_html__('Duplicate current', 'livecanvas-forge-ai') . '</span>';
        echo '</button>';
        echo '<button type="button" class="lcfa-editor-bridge__button is-neutral" data-lcfa-editor-thread-rename>';
        echo $this->get_icon_svg('file-earmark');
        echo '<span>' . esc_html__('Rename current', 'livecanvas-forge-ai') . '</span>';
        echo '</button>';
        echo '<button type="button" class="lcfa-editor-bridge__button is-neutral" data-lcfa-editor-thread-clear>';
        echo $this->get_icon_svg('trash');
        echo '<span>' . esc_html__('Clear current', 'livecanvas-forge-ai') . '</span>';
        echo '</button>';
        echo '<button type="button" class="lcfa-editor-bridge__button is-neutral" data-lcfa-editor-thread-delete>';
        echo $this->get_icon_svg('x-circle');
        echo '<span>' . esc_html__('Delete current', 'livecanvas-forge-ai') . '</span>';
        echo '</button>';
        echo '</div>';
        echo '</div>';
        echo '</details>';
        echo '<details class="lcfa-editor-bridge__details" data-lcfa-editor-quick-actions>';
        echo '<summary>' . esc_html__('Quick actions', 'livecanvas-forge-ai') . '</summary>';
        echo '<div class="lcfa-editor-bridge__details-body">';
        echo '<div class="lcfa-editor-bridge__actions">';
        foreach ($actions as $action) {
            echo '<a class="lcfa-editor-bridge__button is-' . esc_attr($action['tone']) . '" href="' . esc_url($action['url']) . '" target="_blank" rel="noreferrer noopener">';
            echo $this->get_icon_svg($action['icon']);
            echo '<span>' . esc_html($action['label']) . '</span>';
            echo '</a>';
        }
        echo '</div>';
        echo '</div>';
        echo '</details>';
        echo '<details class="lcfa-editor-bridge__details is-support" data-lcfa-editor-support-details>';
        echo '<summary>' . esc_html__('Support details', 'livecanvas-forge-ai') . '</summary>';
        echo '<div class="lcfa-editor-bridge__details-body">';
        echo '<div class="lcfa-editor-bridge__result" data-lcfa-editor-result aria-live="polite">';
        echo '<div class="lcfa-editor-bridge__status" data-lcfa-editor-result-summary></div>';
        echo '<div class="lcfa-editor-bridge__result-meta" data-lcfa-editor-result-meta></div>';
        echo '<div data-lcfa-editor-result-reasons-wrap hidden><div class="lcfa-editor-bridge__label">' . esc_html__('Why this was suggested', 'livecanvas-forge-ai') . '</div><ul class="lcfa-editor-bridge__list" data-lcfa-editor-result-reasons></ul></div>';
        echo '<div data-lcfa-editor-result-warnings-wrap hidden><div class="lcfa-editor-bridge__label">' . esc_html__('Warnings', 'livecanvas-forge-ai') . '</div><ul class="lcfa-editor-bridge__list" data-lcfa-editor-result-warnings></ul></div>';
        echo '<div data-lcfa-editor-result-workflow-wrap hidden><div class="lcfa-editor-bridge__label">' . esc_html__('Recommended workflow', 'livecanvas-forge-ai') . '</div><ol class="lcfa-editor-bridge__list" data-lcfa-editor-result-workflow></ol></div>';
        echo '<div data-lcfa-editor-result-preflight-wrap hidden><div class="lcfa-editor-bridge__label">' . esc_html__('Recommended preflight payload', 'livecanvas-forge-ai') . '</div><pre class="lcfa-editor-bridge__code" data-lcfa-editor-result-preflight></pre></div>';
        echo '<div data-lcfa-editor-result-diff-wrap hidden><div class="lcfa-editor-bridge__label">' . esc_html__('Diff preview', 'livecanvas-forge-ai') . '</div><div class="lcfa-editor-bridge__diff" data-lcfa-editor-result-diff></div></div>';
        echo '<div class="lcfa-editor-bridge__support-grid">';
        echo '<div data-lcfa-editor-result-existing-wrap hidden><div class="lcfa-editor-bridge__label">' . esc_html__('Current markup', 'livecanvas-forge-ai') . '</div><pre class="lcfa-editor-bridge__code" data-lcfa-editor-result-existing></pre></div>';
        echo '<div data-lcfa-editor-result-proposed-wrap hidden><div class="lcfa-editor-bridge__label">' . esc_html__('Proposed markup', 'livecanvas-forge-ai') . '</div><pre class="lcfa-editor-bridge__code" data-lcfa-editor-result-proposed></pre></div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</details>';
        echo '</aside>';
        echo '</div>';
        echo '<script type="application/json" data-lcfa-editor-config>' . wp_json_encode($editor_config, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>';
    }

    private function is_forge_dashboard_request(): bool {
        return sanitize_key((string) ($_GET['page'] ?? '')) === 'lcfa-dashboard';
    }

    public function handle_setup_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_setup');

        $step     = max(1, absint($_POST['step'] ?? 1));
        $settings = LCFA_Settings::get();

        switch ($step) {
            case 1:
                if (!empty($_POST['activate_livecanvas'])) {
                    $activation_result = $this->installer->activate_livecanvas();

                    if (is_wp_error($activation_result)) {
                        LCFA_Settings::set_notice($activation_result->get_error_message(), 'error');
                    } else {
                        LCFA_Settings::set_notice(__('LiveCanvas activated successfully.', 'livecanvas-forge-ai'));
                    }
                }

                $snapshot = $this->environment->get_snapshot();
                $preflight_ready = $this->is_preflight_ready($snapshot);

                if (!$preflight_ready && empty($_POST['activate_livecanvas'])) {
                    LCFA_Settings::set_notice($this->get_preflight_blocking_message($snapshot), 'error');
                }

                $settings['last_completed_step'] = $preflight_ready ? max(1, (int) $settings['last_completed_step']) : 0;
                LCFA_Settings::update($settings);
                $this->redirect_to_step($preflight_ready ? 2 : 1);
                break;

            case 2:
                $framework = sanitize_key($_POST['framework'] ?? '');
                $snapshot = $this->environment->get_snapshot();
                $connections = LCFA_Settings::get_connections();
                $previous_framework = $this->normalize_supported_framework((string) ($settings['framework'] ?: ($snapshot['detected_framework'] ?? '')));

                if (!$this->environment->is_livecanvas_active()) {
                    LCFA_Settings::set_notice(__('Complete the LiveCanvas preflight first.', 'livecanvas-forge-ai'), 'error');
                    $this->redirect_to_step(1);
                }

                $result = $this->installer->apply_framework($framework);

                if (is_wp_error($result)) {
                    LCFA_Settings::set_notice($result->get_error_message(), 'error');
                    $this->redirect_to_step(2);
                }

                LCFA_Settings::patch([
                    'framework'           => $framework,
                    'last_completed_step' => max(2, (int) $settings['last_completed_step']),
                ]);

                if ($previous_framework !== '' && $previous_framework !== $framework && $this->has_verified_connection($connections)) {
                    LCFA_Settings::update_connections(array_merge($connections, [
                        'framework_change_pending'  => true,
                        'framework_change_previous' => $previous_framework,
                        'framework_change_next'     => $framework,
                    ]));

                    LCFA_Settings::set_notice(
                        sprintf(
                            __('Framework confirmed: %1$s. Active theme: %2$s. A verified %3$s connection already exists, so choose in Connections whether to keep it or regenerate it for the new stack.', 'livecanvas-forge-ai'),
                            $this->get_framework_display_name($framework),
                            $result['theme_stylesheet'],
                            ucfirst(str_replace('-', ' ', $this->normalize_connection_client((string) ($connections['preferred_client'] ?: ($settings['ai_tool'] ?: 'codex')))))
                        )
                    );
                } else {
                    LCFA_Settings::update_connections($this->clear_framework_change_connection_decision($connections));
                    LCFA_Settings::set_notice(
                        sprintf(
                            __('Framework confirmed: %1$s. Active theme: %2$s.', 'livecanvas-forge-ai'),
                            $this->get_framework_display_name($framework),
                            $result['theme_stylesheet']
                        )
                    );
                }

                $this->redirect_to_step(3);
                break;

            case 3:
                $site_mode = sanitize_key($_POST['site_mode'] ?? '');

                if (!in_array($site_mode, ['local', 'remote', 'hybrid'], true)) {
                    LCFA_Settings::set_notice(__('Select a valid site profile.', 'livecanvas-forge-ai'), 'error');
                    $this->redirect_to_step(3);
                }

                LCFA_Settings::patch([
                    'site_mode'           => $site_mode,
                    'last_completed_step' => max(3, (int) $settings['last_completed_step']),
                ]);

                LCFA_Settings::set_notice(__('Site profile saved.', 'livecanvas-forge-ai'));
                $this->redirect_to_step(4);
                break;

            case 4:
                $ai_tool = sanitize_key($_POST['ai_tool'] ?? '');

                if (!in_array($ai_tool, ['codex', 'opencode', 'claude', 'cursor', 'other'], true)) {
                    LCFA_Settings::set_notice(__('Select a valid AI Coding Agent.', 'livecanvas-forge-ai'), 'error');
                    $this->redirect_to_step(4);
                }

                LCFA_Settings::patch([
                    'ai_tool'             => $ai_tool,
                    'last_completed_step' => max(4, (int) $settings['last_completed_step']),
                ]);
                LCFA_Settings::update_connections(array_merge(LCFA_Settings::get_connections(), [
                    'preferred_client' => $ai_tool === 'other' ? 'generic' : $ai_tool,
                ]));

                LCFA_Settings::set_notice(__('AI Coding Agent saved.', 'livecanvas-forge-ai'));
                $this->redirect_to_step(5);
                break;

            case 5:
                LCFA_Settings::patch([
                    'permission_profile'  => 'advanced_templates',
                    'allow_file_fallback' => true,
                    'last_completed_step' => max(5, (int) $settings['last_completed_step']),
                ]);

                LCFA_Settings::set_notice(__('Full access enabled.', 'livecanvas-forge-ai'));
                $this->redirect_to_step(6);
                break;

            case 20:
                $snapshot = $this->environment->get_snapshot();
                if (!$this->is_preflight_ready($snapshot)) {
                    LCFA_Settings::set_notice($this->get_preflight_blocking_message($snapshot), 'error');
                    $this->redirect_to_step(1);
                }

                $framework = $this->normalize_supported_framework((string) ($_POST['framework'] ?? ''));
                $site_mode = sanitize_key((string) ($_POST['site_mode'] ?? ''));
                $ai_tool = sanitize_key((string) ($_POST['ai_tool'] ?? ''));

                if ($framework === '') {
                    LCFA_Settings::set_notice(__('Choose Picostrap or Picowind.', 'livecanvas-forge-ai'), 'error');
                    $this->redirect_to_step(2);
                }

                if (!in_array($site_mode, ['local', 'remote', 'hybrid'], true)) {
                    LCFA_Settings::set_notice(__('Choose where this WordPress site runs.', 'livecanvas-forge-ai'), 'error');
                    $this->redirect_to_step(2);
                }

                if (!in_array($ai_tool, ['codex', 'opencode', 'claude', 'cursor', 'other'], true)) {
                    LCFA_Settings::set_notice(__('Choose a coding agent.', 'livecanvas-forge-ai'), 'error');
                    $this->redirect_to_step(2);
                }

                $connections = LCFA_Settings::get_connections();
                $previous_framework = $this->normalize_supported_framework((string) ($settings['framework'] ?: ($snapshot['detected_framework'] ?? '')));
                $framework_result = $this->installer->apply_framework($framework);
                if (is_wp_error($framework_result)) {
                    LCFA_Settings::set_notice($framework_result->get_error_message(), 'error');
                    $this->redirect_to_step(2);
                }

                $full_access = !empty($_POST['enable_full_access']);
                LCFA_Settings::patch([
                    'framework'           => $framework,
                    'site_mode'           => $site_mode,
                    'ai_tool'             => $ai_tool,
                    'permission_profile'  => $full_access ? 'advanced_templates' : 'draft_preview',
                    'allow_file_fallback' => $full_access,
                    'last_completed_step' => max(5, (int) ($settings['last_completed_step'] ?? 0)),
                ]);

                $connections = array_merge($connections, [
                    'preferred_client' => $ai_tool === 'other' ? 'generic' : $ai_tool,
                    'connection_mode'  => $site_mode === 'remote' || $site_mode === 'hybrid' ? 'remote' : 'local',
                ]);

                if ($previous_framework !== '' && $previous_framework !== $framework && $this->has_verified_connection($connections)) {
                    $connections = array_merge($connections, [
                        'framework_change_pending'  => true,
                        'framework_change_previous' => $previous_framework,
                        'framework_change_next'     => $framework,
                    ]);
                } else {
                    $connections = $this->clear_framework_change_connection_decision($connections);
                }
                LCFA_Settings::update_connections($connections);

                LCFA_Settings::set_notice(__('Project profile saved. Next: connect your coding agent.', 'livecanvas-forge-ai'));
                $this->redirect_to_step(3);
                break;

            case 6:
                LCFA_Settings::patch([
                    'completed'           => true,
                    'last_completed_step' => 6,
                ]);

                LCFA_Settings::set_notice(__('Bridge Setup is complete. You can now move into the operational dashboard.', 'livecanvas-forge-ai'));
                wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=' . $this->get_post_setup_redirect_tab()));
                exit;

            default:
                $this->redirect_to_step(1);
        }
    }

    public function handle_connections_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_connections');

        $current_connections = LCFA_Settings::get_connections();
        $has_wizard_step = array_key_exists('connection_current_step', $_POST);
        $current_step = sanitize_key((string) ($_POST['connection_current_step'] ?? ($current_connections['connection_current_step'] ?? 'choose_client')));
        $advance_step = $has_wizard_step && empty($_POST['rotate_mcp_token']);
        $connections = LCFA_Settings::sanitize_connections(array_merge($current_connections, $_POST, [
            'connection_mode'             => sanitize_key($_POST['connection_mode'] ?? ''),
            'connection_status'           => '',
            'connection_last_verified_at' => '',
            'connection_last_error'       => '',
            'connection_current_step'     => $current_step,
        ]));
        $next_step = $advance_step ? $this->connection_onboarding->next_step($current_step, $connections) : $current_step;
        $connections['connection_current_step'] = $next_step;

        LCFA_Settings::update_connections($connections);

        if (isset($_POST['lcfa_update_channel'])) {
            $update_channel = sanitize_key((string) $_POST['lcfa_update_channel']);
            update_option('lcfa_update_channel', in_array($update_channel, ['stable', 'beta'], true) ? $update_channel : 'stable', false);
            delete_transient('lcfa_livecanvas_update_release');
            delete_transient('lcfa_livecanvas_update_release_beta');
        }

        if (!empty($_POST['rotate_mcp_token'])) {
            LCFA_Settings::rotate_mcp_token();
        }

        $preferred_client = sanitize_key($_POST['preferred_client'] ?? '');
        if (in_array($preferred_client, ['codex', 'opencode', 'claude', 'claude-code', 'cursor', 'other', 'generic'], true)) {
            LCFA_Settings::patch([
                'ai_tool' => in_array($preferred_client, ['generic', 'other'], true)
                    ? 'other'
                    : ($preferred_client === 'claude-code' ? 'claude' : $preferred_client),
            ]);
        }

        LCFA_Settings::set_notice(!empty($_POST['rotate_mcp_token']) ? __('Connection settings saved and MCP token rotated.', 'livecanvas-forge-ai') : __('Connection settings saved.', 'livecanvas-forge-ai'));

        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
        exit;
    }

    public function handle_connection_test_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_test_connections');

        $mode = sanitize_key((string) ($_POST['connection_mode'] ?? ''));
        if ($mode === 'local' && method_exists('LCFA_Settings', 'sync_local_workspace_root')) {
            LCFA_Settings::sync_local_workspace_root(true);
        }

        $result = $this->connection_tester->run_checks([
            'mode' => in_array($mode, ['local', 'remote'], true) ? $mode : 'all',
        ]);

        $connections = LCFA_Settings::get_connections();
        if (in_array($mode, ['local', 'remote'], true)) {
        $connections['connection_mode'] = $mode;
        }
        $connections['connection_last_verified_at'] = (string) ($result['checked_at'] ?? '');
        $connections['connection_status'] = !empty($result['ok']) ? 'ready' : 'needs_attention';
        $connections['connection_last_error'] = !empty($result['ok']) ? '' : (string) ($result['summary'] ?? '');
        $connections['connection_current_step'] = !empty($result['ok']) ? 'ready' : 'smoke_test';
        if (!empty($result['ok']) && $this->is_codex_local_connection($connections) && class_exists('LCFA_Codex_Config_Manager', false)) {
            $connections['connection_last_bundle_hash'] = (string) $this->get_codex_config_manager()->get_expected_config($connections)['hash'];
        }
        LCFA_Settings::update_connections($connections);

        LCFA_Settings::set_connection_test_result($result);
        LCFA_Settings::set_notice(
            (string) ($result['summary'] ?? __('Connection checks completed.', 'livecanvas-forge-ai')),
            !empty($result['ok']) ? 'success' : 'error'
        );

        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
        exit;
    }

    public function handle_install_client_bundle_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_install_client_bundle');

        $bundle = $this->build_selected_connection_bundle($_POST);
        $target = $bundle['workspace_files'][0] ?? null;
        $workspace_root = (string) ($bundle['workspace_root'] ?? '');
        $workspace_write_state = LCFA_Workspace_Access::inspect($workspace_root);

        if (!is_array($target) || empty($target['path'])) {
            LCFA_Settings::set_notice(__('No writable workspace artifact was generated for this client.', 'livecanvas-forge-ai'), 'error');
            wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
            exit;
        }

        if (empty($workspace_write_state['available'])) {
            LCFA_Settings::set_notice($this->get_workspace_write_notice($workspace_write_state), 'error');
            wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
            exit;
        }

        $this->write_connection_artifact(
            (string) $target['path'],
            (string) ($target['content'] ?? ''),
            $workspace_root,
            !empty($_POST['create_backup'])
        );

        $connections = LCFA_Settings::get_connections();
        $connections['preferred_client'] = (string) $bundle['client'];
        $connections['claude_connection_target'] = (string) ($bundle['claude_connection_target'] ?? $connections['claude_connection_target']);
        $connections['connection_mode'] = (string) $bundle['mode'];
        $connections['workspace_root'] = sanitize_text_field($workspace_root !== '' ? $workspace_root : (string) $connections['workspace_root']);
        $connections['connection_last_bundle_hash'] = $this->get_connection_bundle_hash($bundle, (string) ($target['content'] ?? ''), $connections);
        $connections['connection_current_step'] = 'smoke_test';
        LCFA_Settings::update_connections($connections);

        LCFA_Settings::set_notice(__('Client bundle written to the local workspace.', 'livecanvas-forge-ai'));
        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
        exit;
    }

    public function handle_download_client_bundle_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_download_client_bundle');

        $bundle = $this->build_selected_connection_bundle($_REQUEST);
        $file = $bundle['download_files'][0] ?? null;

        if (!is_array($file)) {
            wp_die(esc_html__('No bundle is available for download.', 'livecanvas-forge-ai'));
        }

        $connections = LCFA_Settings::get_connections();
        $connections['preferred_client'] = (string) ($bundle['client'] ?? $connections['preferred_client']);
        $connections['claude_connection_target'] = (string) ($bundle['claude_connection_target'] ?? $connections['claude_connection_target']);
        $connections['connection_mode'] = (string) ($bundle['mode'] ?? $connections['connection_mode']);
        $connections['workspace_root'] = sanitize_text_field((string) ($bundle['workspace_root'] ?? $connections['workspace_root']));
        $connections['connection_last_bundle_hash'] = $this->get_connection_bundle_hash($bundle, (string) ($file['content'] ?? ''), $connections);
        $connections['connection_current_step'] = 'smoke_test';
        LCFA_Settings::update_connections($connections);

        nocache_headers();
        header('Content-Type: ' . ((string) ($file['mime'] ?? 'text/plain')) . '; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . sanitize_file_name((string) ($file['name'] ?? 'bundle.txt')) . '"');
        echo (string) ($file['content'] ?? '');
        exit;
    }

    public function handle_repair_codex_connection_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_repair_codex_connection');

        $repair_action = sanitize_key((string) ($_POST['codex_repair_action'] ?? ''));
        $stored_connections = LCFA_Settings::get_connections();
        $requested_mode = $this->normalize_connection_mode((string) ($_POST['connection_mode'] ?? ($stored_connections['connection_mode'] ?: 'remote')));
        $connections = $requested_mode === 'local' && method_exists('LCFA_Settings', 'sync_local_workspace_root')
            ? LCFA_Settings::sync_local_workspace_root(true)
            : $stored_connections;
        $connections['preferred_client'] = 'codex';
        $connections['connection_mode'] = $requested_mode;
        if ($requested_mode === 'local' && empty($connections['codex_config_scope'])) {
            $connections['codex_config_scope'] = 'project';
        }

        if (($repair_action === 'connect_codex' || $repair_action === 'sync_codex') && $requested_mode === 'remote') {
            $remote_prerequisites = $this->get_remote_codex_prerequisites($connections, $this->remote_client->get_status());
            if (empty($remote_prerequisites['ready'])) {
                $connections['connection_status'] = '';
                $connections['connection_last_verified_at'] = '';
                $connections['connection_last_error'] = __('Confirm the target site URL before connecting Codex securely.', 'livecanvas-forge-ai');
                $connections['connection_current_step'] = 'confirm_details';
                LCFA_Settings::update_connections($connections);
                LCFA_Settings::set_notice($connections['connection_last_error'], 'error');
                wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
                exit;
            }

            $bundle = $this->build_selected_connection_bundle([
                'preferred_client' => 'codex',
                'connection_mode'  => 'remote',
                'workspace_root'   => '',
            ]);
            $fingerprint_source = (string) ($bundle['shortcut_command'] ?? ($bundle['command_string'] ?? ''));
            $connections['connection_last_bundle_hash'] = $this->get_connection_bundle_hash($bundle, $fingerprint_source, $connections);
            $connections['connection_strategy'] = sanitize_key((string) ($bundle['connection_strategy'] ?? 'ai-bridge-session'));
            $connections['connection_status'] = '';
            $connections['connection_last_verified_at'] = '';
            $oauth_direct = $connections['connection_strategy'] === 'oauth-direct';
            $connections['connection_last_error'] = $oauth_direct
                ? __('Direct OAuth setup generated. Restart Codex, authorize this project in WordPress, then call get_connection_handoff.', 'livecanvas-forge-ai')
                : __('Secure Codex setup generated. Restart Codex, call get_connection_handoff, approve the pairing request, then run the smoke test.', 'livecanvas-forge-ai');
            $connections['connection_current_step'] = 'smoke_test';
            LCFA_Settings::update_connections($connections);
            LCFA_Settings::set_notice($oauth_direct
                ? __('Direct OAuth setup is ready. Copy the prompt, restart Codex, complete OAuth login, then call the handoff tool.', 'livecanvas-forge-ai')
                : __('Secure Codex setup is ready. Copy the prompt, restart or reload Codex, approve pairing, then run the smoke test.', 'livecanvas-forge-ai'));
            wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
            exit;
        }

        if (!class_exists('LCFA_Codex_Config_Manager', false)) {
            LCFA_Settings::set_notice(__('Codex config manager is not available in this runtime.', 'livecanvas-forge-ai'), 'error');
            wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
            exit;
        }
        $manager = $this->get_codex_config_manager();

        if ($repair_action === 'sync_wp') {
            $connections['connection_current_step'] = 'generate_bundle';
            $connections['connection_status'] = '';
            $connections['connection_last_error'] = '';
            LCFA_Settings::update_connections($connections);
            LCFA_Settings::set_notice(__('WordPress connection settings synced to the current local site path.', 'livecanvas-forge-ai'));
            wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
            exit;
        }

        if ($repair_action === 'connect_codex' || $repair_action === 'sync_codex') {
            $sync = $manager->sync($connections);
            $expected = $manager->get_expected_config($connections);
            if (!empty($sync['ok'])) {
                $connections['connection_last_bundle_hash'] = (string) $expected['hash'];
                $connections['connection_status'] = '';
                $connections['connection_last_verified_at'] = '';
                $connections['connection_last_error'] = __('Codex config updated. Restart Codex or reload the MCP server before testing.', 'livecanvas-forge-ai');
                $connections['connection_current_step'] = 'smoke_test';
                LCFA_Settings::update_connections($connections);
                LCFA_Settings::set_notice($repair_action === 'connect_codex' ? __('Codex config updated. Restart Codex or reload the MCP server before testing.', 'livecanvas-forge-ai') : (string) ($sync['message'] ?? __('Codex config updated.', 'livecanvas-forge-ai')));
            } else {
                LCFA_Settings::set_notice((string) ($sync['message'] ?? __('Codex config could not be updated.', 'livecanvas-forge-ai')), 'error');
            }
            wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
            exit;
        }

        if ($repair_action === 'smoke') {
            if ($requested_mode === 'remote') {
                $result = $this->connection_tester->run_checks(['mode' => 'remote']);
                $connections['connection_last_verified_at'] = (string) ($result['checked_at'] ?? current_time('mysql', true));
                $connections['connection_status'] = !empty($result['ok']) ? 'ready' : 'needs_attention';
                $connections['connection_last_error'] = !empty($result['ok']) ? '' : (string) ($result['summary'] ?? '');
                $connections['connection_current_step'] = !empty($result['ok']) ? 'ready' : 'smoke_test';
                if (!empty($result['ok'])) {
                    $bundle = $this->build_selected_connection_bundle([
                        'preferred_client' => 'codex',
                        'connection_mode'  => 'remote',
                        'workspace_root'   => '',
                    ]);
                    $connections['connection_last_bundle_hash'] = $this->get_connection_bundle_hash($bundle, (string) ($bundle['shortcut_command'] ?? ($bundle['command_string'] ?? '')), $connections);
                }
                LCFA_Settings::update_connections($connections);
                LCFA_Settings::set_connection_test_result($result);
                LCFA_Settings::set_notice(
                    (string) ($result['summary'] ?? __('Connection checks completed.', 'livecanvas-forge-ai')),
                    !empty($result['ok']) ? 'success' : 'error'
                );
                wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
                exit;
            }

            $smoke = $manager->run_smoke_test($connections);
            $checked_at = current_time('mysql', true);
            $result = [
                'ok'         => !empty($smoke['ok']),
                'checked_at' => $checked_at,
                'summary'    => (string) ($smoke['message'] ?? __('Codex MCP smoke test completed.', 'livecanvas-forge-ai')),
                'checks'     => [
                    'codex_mcp_smoke' => [
                        'label'   => __('Codex MCP smoke test', 'livecanvas-forge-ai'),
                        'ok'      => !empty($smoke['ok']),
                        'skipped' => false,
                        'message' => (string) ($smoke['message'] ?? ''),
                        'details' => is_array($smoke['checks'] ?? null) ? $smoke['checks'] : [],
                    ],
                ],
            ];
            $connections['connection_status'] = !empty($smoke['ok']) ? 'ready' : 'needs_attention';
            $connections['connection_last_error'] = !empty($smoke['ok']) ? '' : (string) ($smoke['message'] ?? '');
            $connections['connection_current_step'] = !empty($smoke['ok']) ? 'ready' : 'smoke_test';
            if (!empty($smoke['ok'])) {
                $connections['connection_last_verified_at'] = $checked_at;
                $connections['connection_last_bundle_hash'] = (string) ($smoke['expected']['hash'] ?? $manager->get_expected_config($connections)['hash']);
            } else {
                $connections['connection_last_verified_at'] = '';
            }
            LCFA_Settings::update_connections($connections);
            LCFA_Settings::set_connection_test_result($result);
            LCFA_Settings::set_notice($result['summary'], !empty($result['ok']) ? 'success' : 'error');
            wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
            exit;
        }

        LCFA_Settings::set_notice(__('Choose a Codex repair action.', 'livecanvas-forge-ai'), 'error');
        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
        exit;
    }

    public function handle_install_mcp_adapter_post(): void {
        if (!current_user_can('manage_options') || !current_user_can('install_plugins')) {
            wp_die(esc_html__('You cannot install plugins on this site.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_install_mcp_adapter');
        $result = $this->installer->ensure_mcp_adapter_active();
        if (is_wp_error($result)) {
            LCFA_Settings::set_notice($result->get_error_message(), 'error');
        } else {
            LCFA_Settings::set_notice(__('WordPress MCP Adapter is installed and active. Direct OAuth is now available.', 'livecanvas-forge-ai'));
        }

        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
        exit;
    }

    public function handle_run_connection_diagnostics_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_run_connection_diagnostics');
        if (!$this->connection_diagnostics instanceof LCFA_Connection_Diagnostics) {
            wp_die(esc_html__('Connection diagnostics are unavailable.', 'livecanvas-forge-ai'));
        }

        $result = $this->connection_diagnostics->run();
        LCFA_Settings::set_notice(
            (string) ($result['summary'] ?? __('Connection diagnostics completed.', 'livecanvas-forge-ai')),
            !empty($result['ok']) ? 'success' : 'error'
        );

        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections#lcfa-connection-diagnostics'));
        exit;
    }

    public function handle_reconfigure_connection_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_reconfigure_connection');

        $connections = $this->get_reconfigured_connections(LCFA_Settings::get_connections());
        LCFA_Settings::update_connections($connections);

        LCFA_Settings::set_notice(__('Choose a coding agent to generate a fresh client bundle.', 'livecanvas-forge-ai'));
        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
        exit;
    }

    public function handle_mcp_pairing_approve_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_mcp_pairing_approve');

        if (!class_exists('LCFA_MCP_Session_Manager', false)) {
            LCFA_Settings::set_notice(__('AI Bridge session manager is not available.', 'livecanvas-forge-ai'), 'error');
            wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
            exit;
        }

        $result = LCFA_MCP_Session_Manager::approve_pairing(sanitize_key((string) ($_POST['pairing_id'] ?? '')));
        $connections = LCFA_Settings::get_connections();
        $connections['preferred_client'] = $this->normalize_connection_client((string) ($result['client'] ?? 'codex'));
        $connections['connection_mode'] = 'remote';
        $connections['connection_status'] = '';
        $connections['connection_current_step'] = 'smoke_test';
        $connections['connection_last_error'] = (string) ($result['message'] ?? __('Pairing approval failed.', 'livecanvas-forge-ai'));
        LCFA_Settings::update_connections($connections);

        LCFA_Settings::set_notice(
            (string) ($result['message'] ?? __('Pairing request processed.', 'livecanvas-forge-ai')),
            !empty($result['ok']) ? 'success' : 'error'
        );
        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
        exit;
    }

    public function handle_mcp_session_revoke_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_mcp_session_revoke');

        if (!class_exists('LCFA_MCP_Session_Manager', false)) {
            LCFA_Settings::set_notice(__('AI Bridge session manager is not available.', 'livecanvas-forge-ai'), 'error');
            wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
            exit;
        }

        $result = LCFA_MCP_Session_Manager::revoke_session(sanitize_key((string) ($_POST['session_id'] ?? '')));
        LCFA_Settings::set_notice(
            (string) ($result['message'] ?? __('Session request processed.', 'livecanvas-forge-ai')),
            !empty($result['ok']) ? 'success' : 'error'
        );
        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
        exit;
    }

    public function handle_framework_change_connection_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_framework_change_connection');

        $decision = sanitize_key((string) ($_POST['framework_connection_decision'] ?? ''));
        $connections = LCFA_Settings::get_connections();

        if (!$this->has_framework_change_connection_decision($connections)) {
            LCFA_Settings::set_notice(__('There is no framework change decision waiting right now.', 'livecanvas-forge-ai'), 'error');
            wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
            exit;
        }

        $client_label = ucfirst(str_replace('-', ' ', $this->normalize_connection_client((string) ($connections['preferred_client'] ?: 'codex'))));
        $next_framework_label = $this->get_framework_display_name((string) ($connections['framework_change_next'] ?? ''));

        if ($decision === 'keep') {
            LCFA_Settings::update_connections($this->clear_framework_change_connection_decision($connections));
            LCFA_Settings::set_notice(
                sprintf(
                    __('Kept the verified %1$s connection. You can keep working on the %2$s stack without regenerating the client bundle.', 'livecanvas-forge-ai'),
                    $client_label,
                    $next_framework_label
                )
            );
        } elseif ($decision === 'regenerate') {
            LCFA_Settings::update_connections($this->get_framework_regenerated_connections($connections));
            LCFA_Settings::set_notice(
                sprintf(
                    __('Generate a fresh %1$s client bundle for the %2$s stack, then rerun the smoke test.', 'livecanvas-forge-ai'),
                    $client_label,
                    $next_framework_label
                )
            );
        } else {
            LCFA_Settings::set_notice(__('Choose whether to keep the current connection or generate a new one.', 'livecanvas-forge-ai'), 'error');
        }

        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
        exit;
    }

    private function build_selected_connection_bundle(array $request): array {
        $settings      = LCFA_Settings::get();
        $connections   = LCFA_Settings::get_connections();
        $client_key    = $this->normalize_connection_client((string) ($request['preferred_client'] ?? ($connections['preferred_client'] ?: ($settings['ai_tool'] ?: 'codex'))));
        $default_mode  = $client_key === 'codex' ? 'remote' : 'local';
        $mode          = $this->normalize_connection_mode((string) ($request['connection_mode'] ?? ($connections['connection_mode'] ?: $default_mode)));
        $claude_connection_target = $this->normalize_claude_connection_target((string) ($request['claude_connection_target'] ?? ($connections['claude_connection_target'] ?? '')));
        $workspace_root = trim((string) ($request['workspace_root'] ?? $connections['workspace_root']));

        if ($mode === 'local') {
            $snapshot      = $this->environment->get_snapshot();
            $mcp_bootstrap = $this->get_lightweight_bootstrap_payload($connections, $snapshot);
            $client_payload = is_array($mcp_bootstrap['clients'][$client_key] ?? null)
                ? $mcp_bootstrap['clients'][$client_key]
                : (is_array($mcp_bootstrap['clients']['codex'] ?? null) ? $mcp_bootstrap['clients']['codex'] : ['command' => '', 'env' => []]);

            return $this->connection_onboarding->build_bundle([
                'client'                    => $client_key,
                'claude_connection_target'  => $claude_connection_target,
                'mode'                      => $mode,
                'workspace_root'            => $workspace_root,
                'common'                    => is_array($mcp_bootstrap['common'] ?? null) ? $mcp_bootstrap['common'] : [],
                'client_payload' => [
                    'command' => (string) ($client_payload['command'] ?? ''),
                    'env'     => (array) ($client_payload['env'] ?? []),
                ],
            ]);
        }

        $mcp_bootstrap = $this->context_builder->get_bootstrap_payload();
        $remote_status = $this->remote_client->get_status();
        $common = is_array($mcp_bootstrap['common'] ?? null) ? $mcp_bootstrap['common'] : [];
        $client_payload = is_array($mcp_bootstrap['clients'][$client_key] ?? null)
            ? $mcp_bootstrap['clients'][$client_key]
            : (is_array($mcp_bootstrap['clients']['codex'] ?? null) ? $mcp_bootstrap['clients']['codex'] : ['command' => '', 'env' => []]);

        if ($mode === 'remote') {
            $remote_agent_payload = $this->build_remote_agent_mcp_payload($client_key, $connections, $remote_status);
            $client_payload = $remote_agent_payload['client_payload'];
            $common = array_merge($common, $remote_agent_payload['common']);
        }

        return $this->connection_onboarding->build_bundle([
            'client'                    => $client_key,
            'claude_connection_target'  => $claude_connection_target,
            'mode'                      => $mode,
            'workspace_root'            => $workspace_root,
            'common'                    => $common,
            'client_payload' => [
                'command' => (string) ($client_payload['command'] ?? ''),
                'env'     => (array) ($client_payload['env'] ?? []),
            ],
        ]);
    }

    private function build_remote_codex_mcp_adapter_payload(array $connections, array $remote_status): array {
        return $this->build_remote_agent_mcp_payload('codex', $connections, $remote_status);
    }

    private function build_remote_agent_mcp_payload(string $client_key, array $connections, array $remote_status): array {
        $client_key = $this->normalize_connection_client($client_key);
        $remote_site_url = trim((string) ($connections['remote_site_url'] ?? ''));
        if ($remote_site_url === '' && function_exists('home_url')) {
            $remote_site_url = home_url('/');
        }
        $remote_site_url = $remote_site_url !== '' ? rtrim($remote_site_url, '/') . '/' : '';
        $mcp_adapter_url = $this->get_remote_mcp_adapter_url($remote_site_url, $remote_status);
        $project_label = trim((string) ($connections['remote_project_label'] ?? ''));
        if ($project_label === '' && $remote_site_url !== '') {
            $project_label = (string) parse_url($remote_site_url, PHP_URL_HOST);
        }
        if ($project_label === '') {
            $project_label = sprintf(__('%s project', 'livecanvas-forge-ai'), $this->get_connection_client_label($client_key));
        }
        $snapshot = isset($this->environment) ? $this->environment->get_snapshot() : [];
        $adapter_status = is_array($snapshot['mcp_adapter'] ?? null) ? $snapshot['mcp_adapter'] : [];
        $oauth_status = class_exists('LCFA_OAuth_Server', false)
            ? (new LCFA_OAuth_Server())->get_status($adapter_status)
            : ['available' => false, 'strategy' => 'ai-bridge-session'];
        $current_site_url = function_exists('home_url') ? rtrim(home_url('/'), '/') . '/' : '';
        $targets_current_site = $remote_site_url !== ''
            && $current_site_url !== ''
            && class_exists('LCFA_Settings', false)
            && method_exists('LCFA_Settings', 'site_urls_match')
            && LCFA_Settings::site_urls_match($remote_site_url, $current_site_url);
        $site_fingerprint = class_exists('LCFA_Settings', false) && method_exists('LCFA_Settings', 'get_site_fingerprint')
            ? LCFA_Settings::get_site_fingerprint()
            : '';

        if ($client_key === 'codex' && !empty($oauth_status['available']) && $targets_current_site) {
            $direct_mcp_url = esc_url_raw((string) ($oauth_status['resource_url'] ?? ''));

            return [
                'client_payload' => [
                    'url' => $direct_mcp_url,
                    'command' => '',
                    'env' => [],
                ],
                'common' => [
                    'connection_strategy' => 'oauth-direct',
                    'remote_site_url' => $remote_site_url,
                    'mcp_adapter_url' => $direct_mcp_url,
                    'mcp_url' => $direct_mcp_url,
                    'oauth_resource' => $direct_mcp_url,
                    'site_fingerprint' => $site_fingerprint,
                    'mcp_adapter_available' => true,
                    'oauth_status' => $oauth_status,
                ],
            ];
        }

        $power_state = $this->get_power_mode()->get_state($connections, $snapshot);
        $pairing_scopes = !empty($power_state['enabled'])
            ? 'read,preview,write,media,theme_files,debug,cache,seo'
            : 'read,preview';
        $env = array_values(array_filter([
            $remote_site_url !== '' ? 'LCFA_SITE_URL=' . $remote_site_url : '',
            'LCFA_SITE_FINGERPRINT=' . $site_fingerprint,
            'LCFA_PROJECT_LABEL=' . $project_label,
            'LCFA_AGENT=' . $client_key,
            'LCFA_PAIRING_SCOPES=' . $pairing_scopes,
        ]));

        $mcp_package_spec = defined('LCFA_MCP_PACKAGE_SPEC')
            ? (string) LCFA_MCP_PACKAGE_SPEC
            : '@livecanvas/ai-bridge-mcp@0.2.0-beta.3';

        return [
            'client_payload' => [
                'command' => 'npx -y ' . $mcp_package_spec,
                'env'     => $env,
            ],
            'common' => [
                'connection_strategy' => 'ai-bridge-session',
                'remote_site_url'     => $remote_site_url,
                'mcp_adapter_url'     => $mcp_adapter_url,
                'mcp_adapter_available' => $mcp_adapter_url !== '',
                'mcp_proxy_package'   => $mcp_package_spec,
                'mcp_proxy_log_file'  => '',
                'agent'               => $client_key,
                'site_fingerprint'    => $site_fingerprint,
                'oauth_status'        => $oauth_status,
            ],
        ];
    }

    private function get_connection_client_label(string $client_key): string {
        $labels = [
            'codex'    => 'Codex',
            'opencode' => 'OpenCode',
            'claude'   => 'Claude',
            'cursor'   => 'Cursor',
            'generic'  => __('Coding agent', 'livecanvas-forge-ai'),
        ];

        return (string) ($labels[$client_key] ?? $labels['generic']);
    }

    private function get_remote_mcp_adapter_url(string $remote_site_url, array $remote_status): string {
        if ($remote_site_url === '') {
            return '';
        }

        return trailingslashit(untrailingslashit($remote_site_url)) . 'wp-json/lcfa/v1/';
    }

    private function normalize_connection_client(string $client): string {
        $client = $this->sanitize_key_compat($client);

        if ($client === 'other') {
            return 'generic';
        }

        if ($client === 'claude-code') {
            return 'claude';
        }

        return in_array($client, ['codex', 'opencode', 'claude', 'cursor', 'generic'], true)
            ? $client
            : 'codex';
    }

    private function normalize_connection_mode(string $mode): string {
        return $mode === 'remote' ? 'remote' : 'local';
    }

    private function get_direct_agent_onboarding(): LCFA_Direct_Agent_Onboarding {
        if (!$this->direct_agent_onboarding instanceof LCFA_Direct_Agent_Onboarding) {
            $this->direct_agent_onboarding = new LCFA_Direct_Agent_Onboarding();
        }

        return $this->direct_agent_onboarding;
    }

    private function get_power_mode(): LCFA_Power_Mode {
        if (!$this->power_mode instanceof LCFA_Power_Mode) {
            $this->power_mode = new LCFA_Power_Mode();
        }

        return $this->power_mode;
    }

    private function get_codex_config_manager() {
        return new LCFA_Codex_Config_Manager();
    }

    private function is_codex_local_connection(array $connections): bool {
        return $this->normalize_connection_client((string) ($connections['preferred_client'] ?? '')) === 'codex'
            && $this->normalize_connection_mode((string) ($connections['connection_mode'] ?? 'local')) === 'local';
    }

    private function get_connection_bundle_hash(array $bundle, string $content, array $connections): string {
        if ((string) ($bundle['client'] ?? '') === 'codex' && (string) ($bundle['mode'] ?? '') === 'local' && class_exists('LCFA_Codex_Config_Manager', false)) {
            $connections['workspace_root'] = (string) ($bundle['workspace_root'] ?? ($connections['workspace_root'] ?? ''));

            return (string) $this->get_codex_config_manager()->get_expected_config($connections)['hash'];
        }

        return md5($content);
    }

    private function normalize_claude_connection_target(string $target): string {
        $target = $this->sanitize_key_compat($target);

        return in_array($target, ['desktop_app', 'cli'], true) ? $target : '';
    }

    private function get_lightweight_bootstrap_payload(array $connections, array $snapshot): array {
        $site_url = trailingslashit(home_url('/'));
        $rest_base = trailingslashit(rest_url('lcfa/v1/'));
        $mcp_endpoint = LCFA_Settings::get_mcp_endpoint();
        $mcp_token = (string) ($connections['mcp_token'] ?? '');
        $wp_root = defined('ABSPATH') && is_string(ABSPATH) ? untrailingslashit((string) ABSPATH) : '';
        $site_fingerprint = method_exists('LCFA_Settings', 'get_site_fingerprint') ? LCFA_Settings::get_site_fingerprint() : '';
        $filesystem_mode = ($snapshot['site_mode'] ?? 'local') === 'local' ? 'local-theme-access' : 'remote-rest-primary';
        $local_mcp_command = 'node wp-content/plugins/livecanvas-forge-ai/mcp/bin/livecanvas-forge-mcp.js';
        $is_secure_remote = $filesystem_mode !== 'local-theme-access';
        $mcp_package_spec = defined('LCFA_MCP_PACKAGE_SPEC')
            ? (string) LCFA_MCP_PACKAGE_SPEC
            : '@livecanvas/ai-bridge-mcp@0.2.0-beta.3';
        $remote_mcp_command = 'npx -y ' . $mcp_package_spec;
        $project_host = (string) parse_url($site_url, PHP_URL_HOST);
        $secure_remote_environment = static function (string $client) use ($site_url, $site_fingerprint, $project_host): array {
            return [
                'LCFA_AGENT=' . $client,
                'LCFA_PROJECT_LABEL=' . ($project_host !== '' ? $project_host : 'WordPress site'),
                'LCFA_SITE_FINGERPRINT=' . $site_fingerprint,
                'LCFA_SITE_URL=' . $site_url,
                'LCFA_PAIRING_SCOPES=read,preview',
            ];
        };
        $common = [
            'site_url'       => $site_url,
            'rest_base'      => $rest_base,
            'site_fingerprint' => $site_fingerprint,
            'mcp_endpoint'   => $mcp_endpoint,
            'mcp_token'      => $is_secure_remote ? '' : $mcp_token,
            'wp_root'        => $wp_root,
            'framework'      => (string) ($snapshot['detected_framework'] ?? 'unknown'),
            'theme'          => (string) ($snapshot['current_theme_stylesheet'] ?? ''),
            'transport'      => (string) ($connections['transport'] ?? 'rest'),
            'filesystem_mode'=> $filesystem_mode,
        ];
        $filesystem_env = $filesystem_mode === 'local-theme-access' && $wp_root !== ''
            ? ['LCFA_WP_ROOT=' . $wp_root]
            : [];

        $bootstrap = [
            'common' => $common,
            'clients' => [
                'codex' => [
                    'label'   => 'Codex',
                    'command' => $is_secure_remote ? $remote_mcp_command : (string) ($connections['mcp_server_command'] ?: ($local_mcp_command . ' --transport=stdio')),
                    'env'     => $is_secure_remote ? $secure_remote_environment('codex') : array_merge([
                        'LCFA_SITE_URL=' . $site_url,
                        'LCFA_REST_BASE=' . $rest_base,
                        'LCFA_SITE_FINGERPRINT=' . $site_fingerprint,
                        'LCFA_MCP_ENDPOINT=' . $mcp_endpoint,
                        'LCFA_MCP_TOKEN=' . $mcp_token,
                    ], $filesystem_env),
                ],
                'opencode' => [
                    'label'   => 'OpenCode',
                    'command' => $is_secure_remote ? $remote_mcp_command : (string) ($connections['mcp_server_command'] ?: ($local_mcp_command . ' --transport=stdio --agent=opencode')),
                    'env'     => $is_secure_remote ? $secure_remote_environment('opencode') : array_merge([
                        'LCFA_REST_BASE=' . $rest_base,
                        'LCFA_SITE_FINGERPRINT=' . $site_fingerprint,
                        'LCFA_MCP_TOKEN=' . $mcp_token,
                    ], $filesystem_env),
                ],
                'claude' => [
                    'label'   => 'Claude',
                    'command' => $is_secure_remote ? $remote_mcp_command : (string) ($connections['mcp_server_command'] ?: ($local_mcp_command . ' --transport=stdio --agent=claude')),
                    'env'     => $is_secure_remote ? $secure_remote_environment('claude') : array_merge([
                        'LCFA_REST_BASE=' . $rest_base,
                        'LCFA_SITE_FINGERPRINT=' . $site_fingerprint,
                        'LCFA_MCP_ENDPOINT=' . $mcp_endpoint,
                        'LCFA_MCP_TOKEN=' . $mcp_token,
                    ], $filesystem_env),
                ],
                'cursor' => [
                    'label'   => 'Cursor',
                    'command' => $is_secure_remote ? $remote_mcp_command : (string) ($connections['mcp_server_command'] ?: ($local_mcp_command . ' --transport=stdio --agent=cursor')),
                    'env'     => $is_secure_remote ? $secure_remote_environment('cursor') : array_merge([
                        'LCFA_REST_BASE=' . $rest_base,
                        'LCFA_SITE_FINGERPRINT=' . $site_fingerprint,
                        'LCFA_MCP_TOKEN=' . $mcp_token,
                    ], $filesystem_env),
                ],
            ],
        ];

        $bootstrap['clients']['claude-code'] = $bootstrap['clients']['claude'];

        return $bootstrap;
    }

    private function get_deferred_mcp_status(array $snapshot): array {
        return [
            'enabled'         => true,
            'endpoint'        => LCFA_Settings::get_mcp_endpoint(),
            'rest_base'       => trailingslashit(rest_url('lcfa/v1/')),
            'filesystem_mode' => ($snapshot['site_mode'] ?? 'local') === 'local' ? 'local-theme-access' : 'remote-rest-primary',
            'local_bridge'    => [
                'deferred' => true,
            ],
        ];
    }

    private function build_common_bootstrap_block(array $mcp_bootstrap): string {
        $common = is_array($mcp_bootstrap['common'] ?? null) ? $mcp_bootstrap['common'] : [];
        $environment = array_values(array_filter([
            !empty($common['site_url']) ? 'LCFA_SITE_URL=' . (string) $common['site_url'] : '',
            !empty($common['rest_base']) ? 'LCFA_REST_BASE=' . (string) $common['rest_base'] : '',
            !empty($common['site_fingerprint']) ? 'LCFA_SITE_FINGERPRINT=' . (string) $common['site_fingerprint'] : '',
            !empty($common['mcp_endpoint']) ? 'LCFA_MCP_ENDPOINT=' . (string) $common['mcp_endpoint'] : '',
            !empty($common['mcp_token']) ? 'LCFA_MCP_TOKEN=' . (string) $common['mcp_token'] : '',
            !empty($common['framework']) ? 'LCFA_FRAMEWORK=' . (string) $common['framework'] : '',
            !empty($common['theme']) ? 'LCFA_THEME=' . (string) $common['theme'] : '',
        ]));

        if (($common['filesystem_mode'] ?? '') === 'local-theme-access' && !empty($common['wp_root'])) {
            $environment[] = 'LCFA_WP_ROOT=' . (string) $common['wp_root'];
        }

        return implode("\n", $environment);
    }

    private function write_connection_artifact(string $path, string $content, string $workspace_root, bool $create_backup = false): void {
        $workspace_root = untrailingslashit($workspace_root);
        $normalized_path = wp_normalize_path($path);
        $normalized_root = $workspace_root !== '' ? wp_normalize_path($workspace_root) : '';
        $workspace_state = LCFA_Workspace_Access::inspect($workspace_root);

        if ($normalized_root === '' || strpos($normalized_path, $normalized_root . '/') !== 0) {
            wp_die(esc_html__('The bundle can only be written inside the configured local workspace root.', 'livecanvas-forge-ai'));
        }

        if (empty($workspace_state['available'])) {
            wp_die(esc_html($this->get_workspace_write_notice($workspace_state)));
        }

        $directory = dirname($path);
        if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
            wp_die(esc_html__('Failed to create the bundle directory.', 'livecanvas-forge-ai'));
        }

        if ($create_backup && file_exists($path)) {
            $backup_path = $path . '.' . gmdate('YmdHis') . '.bak';
            if (!copy($path, $backup_path)) {
                wp_die(esc_html__('Failed to create the requested backup file.', 'livecanvas-forge-ai'));
            }
        }

        if (file_put_contents($path, $content) === false) {
            wp_die(esc_html__('Failed to write the generated bundle file.', 'livecanvas-forge-ai'));
        }
    }

    public function handle_reset_setup_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_reset_setup');

        LCFA_Settings::reset_setup_state();
        LCFA_Settings::set_notice(__('AI Bridge state reset. Setup and connection status were cleared, a new MCP token was generated, and existing workspace files were left untouched.', 'livecanvas-forge-ai'), 'success');

        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=setup&step=1'));
        exit;
    }

    public function handle_project_brief_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_project_brief');

        $previous_hash = LCFA_Settings::get_project_brief_hash();
        LCFA_Settings::update_project_brief($_POST);
        $current_hash = LCFA_Settings::get_project_brief_hash();

        if ($previous_hash !== $current_hash) {
            LCFA_Settings::clear_genesis_plan();
            LCFA_Settings::clear_genesis_progress();
            LCFA_Settings::set_notice(__('Project brief updated. Regenerate the build plan to refresh task suggestions.', 'livecanvas-forge-ai'));
        } else {
            LCFA_Settings::set_notice(__('Project brief updated.', 'livecanvas-forge-ai'));
        }

        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=genesis'));
        exit;
    }

    public function handle_generate_plan_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_generate_plan');

        $plan = $this->genesis_planner->generate();
        LCFA_Settings::update_genesis_plan($plan);
        LCFA_Settings::clear_genesis_progress();
        LCFA_Settings::set_notice(__('Build plan generated.', 'livecanvas-forge-ai'));

        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=genesis'));
        exit;
    }

    public function handle_genesis_execute_post(): void {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_genesis_execute');

        $execution_mode = sanitize_key((string) ($_POST['execution_mode'] ?? ''));
        $task_id        = sanitize_key((string) ($_POST['task_id'] ?? ''));
        $thread_id      = LCFA_Settings::normalize_thread_id((string) ($_POST['thread_id'] ?? 'default'));
        $execution_target = sanitize_key((string) ($_POST['execution_target'] ?? 'local'));

        if (!in_array($execution_target, ['local', 'remote'], true)) {
            $execution_target = 'local';
        }

        $result = null;

        switch ($execution_mode) {
            case 'preview_next':
                $result = $this->get_genesis_executor()->execute_next([
                    'dry_run'          => true,
                    'execution_target' => $execution_target,
                    'thread_id'        => $thread_id,
                    'request_context'  => [
                        'thread_id' => $thread_id,
                    ],
                ]);
                break;

            case 'apply_next':
                $result = $this->get_genesis_executor()->execute_next([
                    'dry_run'          => false,
                    'execution_target' => $execution_target,
                    'thread_id'        => $thread_id,
                    'request_context'  => [
                        'thread_id' => $thread_id,
                    ],
                ]);
                break;

            case 'preview_task':
                if ($task_id === '') {
                    LCFA_Settings::set_notice(__('Choose a valid Genesis task before previewing it.', 'livecanvas-forge-ai'), 'error');
                    wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=genesis'));
                    exit;
                }

                $result = $this->get_genesis_executor()->execute_task($task_id, [
                    'dry_run'          => true,
                    'execution_target' => $execution_target,
                    'thread_id'        => $thread_id,
                    'request_context'  => [
                        'thread_id' => $thread_id,
                    ],
                ]);
                break;

            case 'apply_task':
            case 'retry_task':
            case 'acknowledge_task':
                if ($task_id === '') {
                    LCFA_Settings::set_notice(__('Choose a valid Genesis task before applying it.', 'livecanvas-forge-ai'), 'error');
                    wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=genesis'));
                    exit;
                }

                $result = $this->get_genesis_executor()->execute_task($task_id, [
                    'dry_run'          => false,
                    'execution_target' => $execution_target,
                    'thread_id'        => $thread_id,
                    'request_context'  => [
                        'thread_id' => $thread_id,
                    ],
                ]);
                break;
        }

        if (!is_array($result)) {
            LCFA_Settings::set_notice(__('Choose a valid Genesis execution action.', 'livecanvas-forge-ai'), 'error');
            wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=genesis'));
            exit;
        }

        if (!empty($result['ok'])) {
            $notice = trim((string) ($result['message'] ?? ''));

            if ($notice === '') {
                $notice = __('Genesis task executed.', 'livecanvas-forge-ai');
            }

            LCFA_Settings::set_notice($notice, 'success');
        } else {
            LCFA_Settings::set_notice((string) ($result['message'] ?? __('The Genesis task could not be executed.', 'livecanvas-forge-ai')), 'error');
        }

        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=genesis'));
        exit;
    }

    public function handle_create_thread_post(): void {
        if (!current_user_can('edit_pages')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_create_thread');

        $title  = sanitize_text_field((string) ($_POST['thread_title'] ?? ''));
        $thread = LCFA_Settings::create_thread($title);

        LCFA_Settings::set_notice(__('Command thread created.', 'livecanvas-forge-ai'));

        wp_safe_redirect($this->get_command_url([
            'thread_id' => (string) ($thread['id'] ?? 'default'),
        ]));
        exit;
    }

    public function handle_command_post(): void {
        if (!current_user_can('edit_pages')) {
            wp_die(esc_html__('Insufficient permissions.', 'livecanvas-forge-ai'));
        }

        check_admin_referer('lcfa_command');

        $request_payload = $this->get_command_request_payload($_POST);
        $request_payload = $this->add_payload_provenance($request_payload, $this->get_payload_provenance($request_payload, 'admin_command_deck', 'forge_local_rules'));
        $thread_id       = LCFA_Settings::normalize_thread_id((string) ($request_payload['thread_id'] ?? 'default'));
        $thread_operation = sanitize_key((string) ($request_payload['thread_operation'] ?? ''));
        $thread_title    = sanitize_text_field((string) ($request_payload['thread_title'] ?? ''));
        $genesis_task_id = sanitize_key((string) ($request_payload['genesis_task_id'] ?? ''));
        $user_prompt     = sanitize_textarea_field((string) ($request_payload['user_prompt'] ?? ''));

        if ($thread_operation !== '') {
            $default_thread_id = LCFA_Settings::normalize_thread_id('default');
            $redirect_thread_id = $thread_id;

            switch ($thread_operation) {
                case 'create':
                    $thread = LCFA_Settings::create_thread($thread_title);
                    $redirect_thread_id = LCFA_Settings::normalize_thread_id((string) ($thread['id'] ?? $default_thread_id));
                    LCFA_Settings::set_notice(__('Command thread created.', 'livecanvas-forge-ai'));
                    break;

                case 'duplicate':
                    $thread = LCFA_Settings::duplicate_thread($thread_id, $thread_title);
                    $redirect_thread_id = LCFA_Settings::normalize_thread_id((string) ($thread['id'] ?? $default_thread_id));
                    LCFA_Settings::set_notice(__('Command thread duplicated.', 'livecanvas-forge-ai'));
                    break;

                case 'rename':
                    if ($thread_title === '') {
                        LCFA_Settings::set_notice(__('Thread rename requires a title.', 'livecanvas-forge-ai'), 'error');
                    } else {
                        LCFA_Settings::rename_thread($thread_id, $thread_title);
                        LCFA_Settings::set_notice(__('Command thread renamed.', 'livecanvas-forge-ai'));
                    }
                    break;

                case 'clear':
                    LCFA_Settings::clear_thread($thread_id);
                    LCFA_Settings::set_notice(__('Command thread cleared.', 'livecanvas-forge-ai'));
                    break;

                case 'delete':
                    if ($thread_id === $default_thread_id) {
                        LCFA_Settings::set_notice(__('The default thread cannot be deleted.', 'livecanvas-forge-ai'), 'error');
                    } else {
                        LCFA_Settings::delete_thread($thread_id);
                        $redirect_thread_id = $default_thread_id;
                        LCFA_Settings::set_notice(__('Command thread deleted.', 'livecanvas-forge-ai'));
                    }
                    break;
            }

            $redirect_args = [
                'thread_id' => $redirect_thread_id,
            ];

            if ($genesis_task_id !== '') {
                $redirect_args['genesis_task_id'] = $genesis_task_id;
            }

            if (!empty($request_payload['context_post_id'])) {
                $redirect_args['post_id'] = absint($request_payload['context_post_id']);
            }

            if ($user_prompt !== '') {
                $redirect_args['user_prompt'] = $user_prompt;
            }

            wp_safe_redirect($this->get_command_url($redirect_args));
            exit;
        }

        if (!empty($request_payload['analyze_request'])) {
            if ($user_prompt !== '') {
                LCFA_Settings::append_thread_message($thread_id, $this->build_thread_request_message($user_prompt, $request_payload, $genesis_task_id));
            }

            $suggestion = $this->prompt_suggester->suggest($request_payload);
            $suggestion['provenance'] = $this->get_payload_provenance($request_payload, 'admin_command_deck', 'forge_local_rules');
            LCFA_Settings::set_command_suggestion($suggestion);
            LCFA_Settings::append_thread_message($thread_id, $this->build_thread_suggestion_message($suggestion, $request_payload, $thread_id));

            if (!empty($suggestion['ok'])) {
                LCFA_Settings::set_notice(__('Request analyzed. Suggested action prepared in the Command Deck.', 'livecanvas-forge-ai'));
            } else {
                LCFA_Settings::set_notice((string) ($suggestion['message'] ?? __('The plugin could not infer a safe action from the current request.', 'livecanvas-forge-ai')), 'error');
            }

            $redirect_args = [
                'thread_id'   => $thread_id,
                'user_prompt' => $user_prompt,
            ];

            if ($genesis_task_id !== '') {
                $redirect_args['genesis_task_id'] = $genesis_task_id;
            }

            if (!empty($request_payload['context_post_id'])) {
                $redirect_args['post_id'] = absint($request_payload['context_post_id']);
            }

            if (!empty($suggestion['ok']) && is_array($suggestion['suggested_payload'] ?? null)) {
                $redirect_args = array_merge($redirect_args, $this->build_command_redirect_args((array) $suggestion['suggested_payload']));
            }

            wp_safe_redirect($this->get_command_url($redirect_args));
            exit;
        }

        if ($user_prompt !== '') {
            LCFA_Settings::append_thread_message($thread_id, $this->build_thread_request_message($user_prompt, $request_payload, $genesis_task_id));
        }

        $result = $this->command_deck->execute($request_payload);
        LCFA_Settings::set_command_result($result);
        LCFA_Settings::append_thread_message($thread_id, $this->build_thread_result_message($result, $request_payload));

        if ($genesis_task_id !== '') {
            LCFA_Settings::update_genesis_task_progress($genesis_task_id, [
                'status'       => !empty($result['ok']) ? (($result['mode'] ?? '') === 'preview' ? 'previewed' : 'applied') : 'failed',
                'updated_at'   => current_time('mysql', true),
                'thread_id'    => $thread_id,
                'action'       => (string) ($result['action'] ?? sanitize_key((string) ($request_payload['action'] ?? ''))),
                'mode'         => (string) ($result['mode'] ?? (!empty($request_payload['dry_run']) ? 'preview' : 'apply')),
                'ok'           => !empty($result['ok']),
                'message'      => (string) ($result['message'] ?? ''),
                'target_type'  => (string) ($result['target_type'] ?? ''),
                'target_id'    => (int) ($result['target_id'] ?? 0),
                'target_title' => (string) ($result['target_title'] ?? ''),
            ]);
        }

        if (!empty($result['ok'])) {
            $notice = $result['mode'] === 'preview'
                ? __('Command preview prepared.', 'livecanvas-forge-ai')
                : ($result['message'] ?: __('Command applied.', 'livecanvas-forge-ai'));

            LCFA_Settings::set_notice($notice, 'success');
        } else {
            LCFA_Settings::set_notice($result['message'] ?: __('The command failed.', 'livecanvas-forge-ai'), 'error');
        }

        $redirect_args = [
            'thread_id' => $thread_id,
        ];

        if ($genesis_task_id !== '') {
            $redirect_args['genesis_task_id'] = $genesis_task_id;
        }

        if (!empty($request_payload['context_post_id'])) {
            $redirect_args['post_id'] = absint($request_payload['context_post_id']);
        }

        if ($user_prompt !== '') {
            $redirect_args['user_prompt'] = $user_prompt;
        }

        wp_safe_redirect($this->get_command_url($redirect_args));
        exit;
    }

    private function get_command_request_payload(array $source): array {
        $payload = $source;

        if (!empty($source['command_payload_json']) && is_string($source['command_payload_json'])) {
            $decoded = json_decode(wp_unslash((string) $source['command_payload_json']), true);

            if (is_array($decoded)) {
                $payload = array_merge($payload, $decoded);
            }
        }

        if (!empty($source['command_payload']) && is_array($source['command_payload'])) {
            $payload = array_merge($payload, (array) $source['command_payload']);
        }

        $payload = $this->merge_command_payload_from_content_json($payload);

        return $payload;
    }

    private function merge_command_payload_from_content_json(array $payload): array {
        if (empty($payload['content']) || !is_string($payload['content'])) {
            return $payload;
        }

        $content = trim((string) wp_unslash($payload['content']));

        if ($content === '' || $content[0] !== '{' || substr($content, -1) !== '}') {
            return $payload;
        }

        $decoded = json_decode($content, true);

        if (!is_array($decoded) || json_last_error() !== JSON_ERROR_NONE) {
            return $payload;
        }

        return array_merge($payload, $decoded);
    }

    private function get_payload_provenance(array $payload, string $default_origin = 'admin_command_deck', string $default_processed_by = 'forge_local_rules'): array {
        $origin = sanitize_key((string) ($payload['_lcfa_origin'] ?? $payload['origin'] ?? $default_origin));
        $transport = sanitize_key((string) ($payload['_lcfa_transport'] ?? $payload['transport'] ?? ($origin === 'mcp_agent' ? 'mcp_stdio' : 'browser_rest')));
        $agent = sanitize_key((string) ($payload['_lcfa_agent'] ?? $payload['agent'] ?? ($origin === 'mcp_agent' ? 'codex' : 'forge')));
        $processed_by = sanitize_key((string) ($payload['_lcfa_processed_by'] ?? $payload['processed_by'] ?? $default_processed_by));

        $allowed_origins = ['frontend_bridge', 'admin_command_deck', 'mcp_agent', 'remote_companion', 'api'];
        $allowed_transports = ['browser_rest', 'mcp_stdio', 'mcp_bridge', 'remote_rest', 'api'];
        $allowed_agents = ['forge', 'codex', 'opencode', 'claude', 'cursor', 'generic'];
        $allowed_processors = ['forge_local_rules', 'codex_mcp', 'opencode_mcp', 'claude_mcp', 'cursor_mcp', 'generic_mcp', 'remote_companion'];

        if (!in_array($origin, $allowed_origins, true)) {
            $origin = $default_origin;
        }

        if (!in_array($transport, $allowed_transports, true)) {
            $transport = $origin === 'mcp_agent' ? 'mcp_stdio' : 'browser_rest';
        }

        if (!in_array($agent, $allowed_agents, true)) {
            $agent = $origin === 'mcp_agent' ? 'codex' : 'forge';
        }

        if (!in_array($processed_by, $allowed_processors, true)) {
            $processed_by = $default_processed_by;
        }

        return [
            'origin'       => $origin,
            'transport'    => $transport,
            'agent'        => $agent,
            'processed_by' => $processed_by,
        ];
    }

    private function add_payload_provenance(array $payload, array $provenance): array {
        foreach ($provenance as $key => $value) {
            $payload['_lcfa_' . $key] = $value;
        }

        return $payload;
    }

    private function build_thread_request_message(string $user_prompt, array $payload, string $genesis_task_id = ''): array {
        $provenance = $this->get_payload_provenance($payload, 'admin_command_deck', 'forge_local_rules');

        return [
            'role'    => 'user',
            'label'   => __('Request', 'livecanvas-forge-ai'),
            'content' => $user_prompt,
            'meta'    => [
                'action'           => sanitize_key((string) ($payload['action'] ?? '')),
                'execution_target' => sanitize_key((string) ($payload['execution_target'] ?? 'local')),
                'dry_run'          => !empty($payload['dry_run']),
                'genesis_task_id'  => $genesis_task_id,
            ] + $provenance,
        ];
    }

    private function build_thread_suggestion_message(array $suggestion, array $request_payload, string $thread_id): array {
        $suggested_payload = is_array($suggestion['suggested_payload'] ?? null) ? $suggestion['suggested_payload'] : [];
        $summary           = (string) ($suggestion['summary'] ?? $suggestion['message'] ?? '');
        $provenance        = $this->get_payload_provenance(is_array($suggestion['provenance'] ?? null) ? (array) $suggestion['provenance'] : $request_payload, 'admin_command_deck', 'forge_local_rules');

        return [
            'role'    => 'suggestion_result',
            'label'   => !empty($suggestion['ok']) ? __('Suggestion ready', 'livecanvas-forge-ai') : __('Suggestion failed', 'livecanvas-forge-ai'),
            'content' => $summary !== '' ? $summary : __('No suggestion summary available.', 'livecanvas-forge-ai'),
            'meta'    => [
                'ok'               => !empty($suggestion['ok']),
                'action'           => sanitize_key((string) ($suggested_payload['action'] ?? '')),
                'execution_target' => sanitize_key((string) ($suggested_payload['execution_target'] ?? '')),
                'confidence'       => sanitize_text_field((string) ($suggestion['confidence'] ?? '')),
                'warnings'         => array_map('sanitize_text_field', (array) ($suggestion['warnings'] ?? [])),
                'reasons'          => array_map('sanitize_text_field', (array) ($suggestion['reasons'] ?? [])),
            ] + $provenance,
            'actions' => LCFA_Thread_Message_Actions::build_suggestion_actions($suggested_payload, $request_payload, [
                'thread_id'          => LCFA_Settings::normalize_thread_id($thread_id),
                'command_url_builder' => [$this, 'get_command_url'],
            ]),
        ];
    }

    public function render_setup_page(): void {
        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=setup&step=' . max(1, absint($_GET['step'] ?? 1))));
        exit;
    }

    private function get_default_dashboard_tab(array $settings): string {
        return !empty($settings['completed']) ? 'connections' : 'setup';
    }

    private function get_post_setup_redirect_tab(): string {
        return 'connections';
    }

    private function get_reconfigured_connections(array $connections): array {
        $connections = $this->clear_framework_change_connection_decision($connections);
        $connections['preferred_client'] = '';
        $connections['connection_status'] = '';
        $connections['connection_last_verified_at'] = '';
        $connections['connection_last_error'] = '';
        $connections['connection_current_step'] = 'choose_client';

        return $connections;
    }

    private function get_framework_regenerated_connections(array $connections): array {
        $connections = $this->clear_framework_change_connection_decision($connections);
        $connections['connection_status'] = '';
        $connections['connection_last_verified_at'] = '';
        $connections['connection_last_error'] = '';
        $connections['connection_last_bundle_hash'] = '';
        $connections['connection_current_step'] = $this->get_framework_regeneration_step($connections);

        return $connections;
    }

    private function clear_framework_change_connection_decision(array $connections): array {
        $connections['framework_change_pending'] = false;
        $connections['framework_change_previous'] = '';
        $connections['framework_change_next'] = '';

        return $connections;
    }

    private function has_verified_connection(array $connections): bool {
        return (string) ($connections['connection_status'] ?? '') === 'ready'
            && trim((string) ($connections['connection_last_verified_at'] ?? '')) !== ''
            && trim((string) ($connections['preferred_client'] ?? '')) !== '';
    }

    private function has_framework_change_connection_decision(array $connections): bool {
        return !empty($connections['framework_change_pending'])
            && $this->has_verified_connection($connections)
            && $this->normalize_supported_framework((string) ($connections['framework_change_previous'] ?? '')) !== ''
            && $this->normalize_supported_framework((string) ($connections['framework_change_next'] ?? '')) !== '';
    }

    private function get_framework_regeneration_step(array $connections): string {
        $raw_preferred_client = $this->sanitize_key_compat((string) ($connections['preferred_client'] ?? ''));
        $preferred_client = $raw_preferred_client === 'other' ? 'generic' : $this->normalize_connection_client($raw_preferred_client);
        $claude_connection_target = $this->normalize_claude_connection_target((string) ($connections['claude_connection_target'] ?? ''));
        $raw_connection_mode = $this->sanitize_key_compat((string) ($connections['connection_mode'] ?? ''));

        if ($raw_preferred_client === '') {
            return 'choose_client';
        }

        if ($preferred_client === 'claude' && $claude_connection_target === '') {
            return 'choose_claude_target';
        }

        if (!in_array($raw_connection_mode, ['local', 'remote'], true)) {
            return 'choose_mode';
        }

        return 'confirm_details';
    }

    private function get_dashboard_hero_content(string $tab): array {
        $hero = [
            'setup' => [
                'title'    => __('Get Started', 'livecanvas-forge-ai'),
                'subtitle' => __('Check the LiveCanvas stack, confirm this project, then connect a coding agent.', 'livecanvas-forge-ai'),
            ],
            'genesis' => [
                'title'    => __('Build Plan', 'livecanvas-forge-ai'),
                'subtitle' => __('Describe the site once and turn it into a reusable sequence of pages and implementation tasks.', 'livecanvas-forge-ai'),
            ],
            'connections' => [
                'title'    => __('Connect a Coding Agent', 'livecanvas-forge-ai'),
                'subtitle' => __('Follow the highlighted action, verify the target site, and finish with a smoke test.', 'livecanvas-forge-ai'),
            ],
            'studio' => [
                'title'    => __('Abilities & Runs', 'livecanvas-forge-ai'),
                'subtitle' => __('Inspect available tools, write exposure, readiness, and recent audited activity.', 'livecanvas-forge-ai'),
            ],
            'theme-library' => [
                'title'    => __('Theme Library', 'livecanvas-forge-ai'),
                'subtitle' => __('Preview, install, and import validated LiveCanvas starter themes.', 'livecanvas-forge-ai'),
            ],
            'command' => [
                'title'    => __('Command Deck', 'livecanvas-forge-ai'),
                'subtitle' => __('Preview or apply a specific operation from WordPress with audit and rollback support.', 'livecanvas-forge-ai'),
            ],
        ];

        return $hero[$tab] ?? $hero['connections'];
    }

    public function render_dashboard_page(): void {
        if (!current_user_can('manage_options')) {
            return;
        }

        $settings = LCFA_Settings::get();
        $snapshot = $this->environment->get_snapshot();
        $notice   = LCFA_Settings::consume_notice();
        $tab      = sanitize_key($_GET['tab'] ?? $this->get_default_dashboard_tab($settings));

        if (!in_array($tab, ['setup', 'genesis', 'connections', 'studio', 'theme-library', 'command'], true)) {
            $tab = $this->get_default_dashboard_tab($settings);
        }

        echo '<div class="wrap lcfa-admin">';
        $this->render_page_header($tab, $snapshot, $settings);

        $this->render_notice($notice);
        $this->render_internal_tabs($tab, $settings);
        $this->render_ai_bridge_update_notice($snapshot);
        $this->render_windpress_framework_advisory($snapshot);

        if (!$settings['completed'] && $tab !== 'setup') {
            echo '<div class="notice notice-warning"><p>';
            echo esc_html__('Bridge Setup is not complete yet. Finish the setup flow before using the operational dashboard.', 'livecanvas-forge-ai');
            echo ' <a href="' . esc_url(admin_url('admin.php?page=lcfa-dashboard&tab=setup')) . '">' . esc_html__('Open Bridge Setup', 'livecanvas-forge-ai') . '</a>';
            echo '</p></div>';
        }

        switch ($tab) {
            case 'setup':
                $this->render_setup_tab($settings, $snapshot);
                break;

            case 'connections':
                $this->render_connections_tab($settings, $snapshot);
                break;

            case 'studio':
                $this->render_studio_tab($settings, $snapshot);
                break;

            case 'theme-library':
                $this->render_theme_library_tab($settings, $snapshot);
                break;

            case 'command':
                $this->render_command_tab($settings, $snapshot);
                break;

            case 'genesis':
            default:
                $brief      = LCFA_Settings::get_project_brief();
                $plan       = LCFA_Settings::get_genesis_plan();
                $progress   = LCFA_Settings::get_genesis_progress();
                $brief_hash = LCFA_Settings::get_project_brief_hash($brief);
                $summary    = $this->inventory->get_summary();
                $this->render_genesis_tab($settings, $snapshot, $brief, $summary, $plan, $progress, $brief_hash);
                break;
        }

        echo '</div>';
        echo '</details>';
    }

    private function render_ai_bridge_update_notice(array $snapshot): void {
        $updates = is_array($snapshot['ai_bridge_updates'] ?? null) ? $snapshot['ai_bridge_updates'] : [];
        if (empty($updates)) {
            return;
        }

        if (empty($updates['eligible'])) {
            echo '<div class="notice notice-warning inline lcfa-update-notice"><p>';
            echo '<strong>' . esc_html__('AI Bridge auto updates are paused.', 'livecanvas-forge-ai') . '</strong> ';
            echo esc_html__('Auto updates require an active LiveCanvas license. Activate LiveCanvas to receive AI Bridge releases through the native WordPress update screen.', 'livecanvas-forge-ai');
            echo '</p></div>';

            return;
        }

        if (!empty($updates['update_available'])) {
            $source = sanitize_key((string) ($updates['source'] ?? ''));
            $source_label = $source === 'github_release'
                ? __('GitHub release fallback', 'livecanvas-forge-ai')
                : __('LiveCanvas update endpoint', 'livecanvas-forge-ai');
            echo '<div class="notice notice-info inline lcfa-update-notice"><p>';
            echo '<strong>' . esc_html__('AI Bridge update available.', 'livecanvas-forge-ai') . '</strong> ';
            echo esc_html(sprintf(
                /* translators: %s: update source label. */
                __('Open the WordPress Plugins screen to install the latest licensed LiveCanvas release. Source: %s.', 'livecanvas-forge-ai'),
                $source_label
            ));
            echo '</p></div>';
        }
    }

    private function render_windpress_framework_advisory(array $snapshot): void {
        if (!$this->should_recommend_windpress_deactivation($snapshot)) {
            return;
        }

        echo '<section class="lcfa-runtime-advisory" aria-labelledby="lcfa-windpress-advisory-title">';
        echo '<span class="lcfa-runtime-advisory__icon" aria-hidden="true">' . $this->get_icon_svg('wind') . '</span>';
        echo '<div class="lcfa-runtime-advisory__copy">';
        echo '<h2 id="lcfa-windpress-advisory-title">' . esc_html__('WindPress is not used by Picostrap', 'livecanvas-forge-ai') . '</h2>';
        echo '<p>' . esc_html__('The active theme uses Bootstrap and Sass. WindPress is only required for Picowind, Tailwind, or DaisyUI projects, so deactivating it keeps this site on one clear frontend stack.', 'livecanvas-forge-ai') . '</p>';
        echo '<span>' . esc_html__('No theme or content files will be changed. AI Bridge will activate WindPress again if you switch to Picowind.', 'livecanvas-forge-ai') . '</span>';
        echo '</div>';
        $this->render_windpress_deactivate_form('dashboard', true);
        echo '</section>';
    }

    private function render_windpress_deactivate_form(string $return_to, bool $with_icon): void {
        echo '<form class="lcfa-runtime-advisory__action" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('lcfa_deactivate_redundant_windpress');
        echo '<input type="hidden" name="action" value="lcfa_deactivate_redundant_windpress">';
        echo '<input type="hidden" name="return_to" value="' . esc_attr($return_to) . '">';
        echo '<button type="submit" class="button button-secondary' . ($with_icon ? ' lcfa-button-with-icon' : '') . '">';
        if ($with_icon) {
            echo $this->get_icon_svg('power');
        }
        echo esc_html__('Deactivate WindPress', 'livecanvas-forge-ai');
        echo '</button>';
        echo '</form>';
    }

    private function should_recommend_windpress_deactivation(array $snapshot): bool {
        $compatibility = is_array($snapshot['windpress_compatibility'] ?? null)
            ? $snapshot['windpress_compatibility']
            : [];

        if (!empty($compatibility)) {
            return (string) ($compatibility['status'] ?? '') === 'deactivation_recommended';
        }

        return (string) ($snapshot['detected_framework'] ?? '') === 'picostrap'
            && !empty($snapshot['windpress_active']);
    }

    private function redirect_after_windpress_action(string $return_to, string $outcome): void {
        if ($return_to === 'plugins') {
            wp_safe_redirect(add_query_arg('lcfa_windpress', sanitize_key($outcome), admin_url('plugins.php')));
            exit;
        }

        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard'));
        exit;
    }

    public function render_connections_page(): void {
        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=connections'));
        exit;
    }

    public function render_command_page(): void {
        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=command'));
        exit;
    }

    private function render_internal_tabs(string $current_tab, array $settings): void {
        $tabs = [];
        if (empty($settings['completed'])) {
            $tabs['setup'] = ['label' => __('Get Started', 'livecanvas-forge-ai'), 'icon' => 'shield-check'];
        }
        $tabs['connections'] = ['label' => __('Connect', 'livecanvas-forge-ai'), 'icon' => 'plug'];
        $tabs['genesis'] = ['label' => __('Build Plan', 'livecanvas-forge-ai'), 'icon' => 'stars'];
        $tabs['theme-library'] = ['label' => __('Themes', 'livecanvas-forge-ai'), 'icon' => 'window-stack'];

        $advanced_tabs = [
            'studio' => ['label' => __('Abilities & Runs', 'livecanvas-forge-ai'), 'icon' => 'sparkles'],
            'command' => ['label' => __('Command Deck', 'livecanvas-forge-ai'), 'icon' => 'command'],
        ];
        if (!empty($settings['completed'])) {
            $advanced_tabs['setup'] = ['label' => __('Setup Settings', 'livecanvas-forge-ai'), 'icon' => 'shield-check'];
        }
        $advanced_open = isset($advanced_tabs[$current_tab]);

        echo '<div class="lcfa-tabbar">';
        echo '<nav class="lcfa-tabs" aria-label="' . esc_attr__('AI Bridge sections', 'livecanvas-forge-ai') . '">';
        foreach ($tabs as $tab => $data) {
            $classes = 'lcfa-tab' . ($tab === $current_tab ? ' is-current' : '');
            $url     = admin_url('admin.php?page=lcfa-dashboard&tab=' . $tab);
            echo '<a class="' . esc_attr($classes) . '" href="' . esc_url($url) . '">';
            echo '<span class="lcfa-step-icon-wrap">' . $this->get_icon_svg($data['icon']) . '</span>';
            echo '<span>' . esc_html($data['label']) . '</span>';
            echo '</a>';
        }
        echo '</nav>';
        echo '<details class="lcfa-advanced-nav"' . ($advanced_open ? ' open' : '') . '>';
        echo '<summary>' . $this->get_icon_svg('sliders') . '<span>' . esc_html__('Advanced', 'livecanvas-forge-ai') . '</span></summary>';
        echo '<nav class="lcfa-advanced-nav__links" aria-label="' . esc_attr__('Advanced AI Bridge sections', 'livecanvas-forge-ai') . '">';
        foreach ($advanced_tabs as $tab => $data) {
            $classes = 'lcfa-advanced-nav__link' . ($tab === $current_tab ? ' is-current' : '');
            $url = admin_url('admin.php?page=lcfa-dashboard&tab=' . $tab);
            echo '<a class="' . esc_attr($classes) . '" href="' . esc_url($url) . '">';
            echo '<span class="lcfa-step-icon-wrap">' . $this->get_icon_svg($data['icon']) . '</span>';
            echo '<span>' . esc_html($data['label']) . '</span>';
            echo '</a>';
        }
        echo '</nav>';
        echo '</details>';
        echo '</div>';
    }

    private function render_setup_tab(array $settings, array $snapshot): void {
        $requested_step = max(1, absint($_GET['step'] ?? (!empty($settings['completed']) ? 2 : 1)));
        $step = $requested_step > 3
            ? ((int) ($settings['last_completed_step'] ?? 0) >= 5 ? 3 : 2)
            : $requested_step;

        if ($step > 1 && !$this->is_preflight_ready($snapshot)) {
            $step = 1;
        }

        echo '<div class="lcfa-main">';
        $this->render_streamlined_setup_nav($step, $settings, $snapshot);

        switch ($step) {
            case 1:
                $this->render_preflight_step($snapshot);
                break;
            case 2:
                $this->render_streamlined_profile_step($settings, $snapshot);
                break;
            case 3:
            default:
                $this->render_streamlined_finish_step($settings, $snapshot);
                break;
        }

        $this->render_setup_reset_panel();

        echo '</div>';
    }

    private function render_theme_library_tab(array $settings, array $snapshot): void {
        $catalog = $this->theme_library_catalog->get_catalog(!empty($_GET['refresh_catalog']));
        $imports = LCFA_Theme_Library_Importer::get_imports();
        $rollback_history = $this->get_theme_library_rollback_history($imports);

        echo '<div class="lcfa-main">';

        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('layers');
        echo '<div><h2>' . esc_html__('Theme Library', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Browse LiveCanvas child themes by framework, then preview, install, and import their deterministic starter data. These actions are admin-only and are not exposed to MCP clients.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<div class="lcfa-chip-row lcfa-theme-library-status">';
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Framework: %s', 'livecanvas-forge-ai'), (string) ($snapshot['detected_framework'] ?? 'unknown'))) . '</span>';
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Theme: %s', 'livecanvas-forge-ai'), (string) ($snapshot['current_theme_stylesheet'] ?? 'unknown'))) . '</span>';
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('PHP: %s', 'livecanvas-forge-ai'), PHP_VERSION)) . '</span>';
        echo '</div>';
        echo '<div class="lcfa-theme-library-steps" aria-label="' . esc_attr__('Theme import flow', 'livecanvas-forge-ai') . '">';
        echo '<span><b>1</b>' . esc_html__('Preview package', 'livecanvas-forge-ai') . '</span>';
        echo '<span><b>2</b>' . esc_html__('Install child theme', 'livecanvas-forge-ai') . '</span>';
        echo '<span><b>3</b>' . esc_html__('Import starter data', 'livecanvas-forge-ai') . '</span>';
        echo '<span><b>4</b>' . esc_html__('Verify compiled CSS', 'livecanvas-forge-ai') . '</span>';
        echo '</div>';
        echo '<details class="lcfa-technical-details lcfa-theme-library-source">';
        echo '<summary>' . esc_html__('Catalog source', 'livecanvas-forge-ai') . '</summary>';
        echo '<div class="lcfa-technical-details__body">';
        echo '<p><code>' . esc_html($this->theme_library_catalog->get_catalog_url()) . '</code></p>';
        echo '<a class="button" href="' . esc_url(admin_url('admin.php?page=lcfa-dashboard&tab=theme-library&refresh_catalog=1')) . '">' . esc_html__('Refresh catalog', 'livecanvas-forge-ai') . '</a>';
        echo '</div>';
        echo '</details>';
        echo '</section>';

        if (empty($catalog['ok'])) {
            echo '<section class="lcfa-card">';
            echo '<h2>' . esc_html__('Catalog unavailable', 'livecanvas-forge-ai') . '</h2>';
            echo '<p>' . esc_html((string) ($catalog['message'] ?? __('Theme Library catalog could not be loaded.', 'livecanvas-forge-ai'))) . '</p>';
            echo '</section>';
            echo '</div>';
            return;
        }

        if (!empty($catalog['errors'])) {
            echo '<section class="lcfa-card">';
            echo '<h2>' . esc_html__('Catalog warnings', 'livecanvas-forge-ai') . '</h2>';
            echo '<ul>';
            foreach ((array) $catalog['errors'] as $error) {
                echo '<li>' . esc_html((string) $error) . '</li>';
            }
            echo '</ul>';
            echo '</section>';
        }

        echo '<section class="lcfa-card lcfa-card--theme-library" data-lcfa-theme-library>';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('layers');
        echo '<div><h2>' . esc_html__('Available child themes', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Filter by Picowind or Picostrap before choosing a theme. Every card identifies its CSS and UI stack.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        $themes = (array) ($catalog['themes'] ?? []);
        $needs_build_capability = false;
        foreach ($imports as $stored_import) {
            if (is_array($stored_import) && in_array((string) ($stored_import['status'] ?? ''), ['build_required', 'build_failed'], true)) {
                $needs_build_capability = true;
                break;
            }
        }
        $build_capability = $needs_build_capability
            ? $this->theme_library_importer->get_build_capability()
            : [
                'build_available' => false,
                'message'         => __('CSS build status is checked after starter data creates a pending build.', 'livecanvas-forge-ai'),
            ];
        if (!$themes) {
            echo '<p>' . esc_html__('No valid themes are currently available in the catalog.', 'livecanvas-forge-ai') . '</p>';
        } else {
            $categories = [];
            $framework_counts = [
                'picowind'  => 0,
                'picostrap' => 0,
            ];
            foreach ($themes as $theme) {
                if (!is_array($theme)) {
                    continue;
                }

                $category = sanitize_text_field((string) ($theme['category'] ?? ''));
                $category_key = sanitize_key($category);
                if ($category !== '' && $category_key !== '') {
                    if (!isset($categories[$category_key])) {
                        $categories[$category_key] = [
                            'label' => $category,
                            'count' => 0,
                        ];
                    }
                    $categories[$category_key]['count']++;
                }

                $theme_framework = $this->get_theme_library_framework($theme);
                if (isset($framework_counts[$theme_framework])) {
                    $framework_counts[$theme_framework]++;
                }
            }

            echo '<div class="lcfa-theme-library-toolbar">';
            echo '<div class="lcfa-theme-library-toolbar__title"><span>' . esc_html__('Theme catalog', 'livecanvas-forge-ai') . '</span>';
            echo '<strong data-lcfa-theme-results data-singular="' . esc_attr__('%d theme shown', 'livecanvas-forge-ai') . '" data-plural="' . esc_attr__('%d themes shown', 'livecanvas-forge-ai') . '" aria-live="polite">' . esc_html(sprintf(_n('%d theme shown', '%d themes shown', count($themes), 'livecanvas-forge-ai'), count($themes))) . '</strong>';
            echo '</div>';
            echo '<div class="lcfa-theme-library-filter-groups">';
            echo '<div class="lcfa-theme-library-filter-group">';
            echo '<span id="lcfa-theme-framework-filter-label" class="lcfa-theme-library-filter-label">' . esc_html__('Framework', 'livecanvas-forge-ai') . '</span>';
            echo '<div class="lcfa-theme-library-filterbar lcfa-theme-library-filterbar--framework" role="group" aria-labelledby="lcfa-theme-framework-filter-label">';
            echo '<button class="lcfa-theme-filter is-active" type="button" data-lcfa-theme-framework-filter="all" aria-pressed="true"><span>' . esc_html__('All', 'livecanvas-forge-ai') . '</span><small>' . esc_html((string) count($themes)) . '</small></button>';
            foreach (['picowind', 'picostrap'] as $filter_framework) {
                echo '<button class="lcfa-theme-filter lcfa-theme-filter--' . esc_attr($filter_framework) . '" type="button" data-lcfa-theme-framework-filter="' . esc_attr($filter_framework) . '" aria-pressed="false">';
                echo '<span>' . esc_html($this->get_theme_library_framework_label($filter_framework)) . '</span><small>' . esc_html((string) $framework_counts[$filter_framework]) . '</small>';
                echo '</button>';
            }
            echo '</div>';
            echo '</div>';
            if ($categories) {
                echo '<div class="lcfa-theme-library-filter-group">';
                echo '<span id="lcfa-theme-category-filter-label" class="lcfa-theme-library-filter-label">' . esc_html__('Theme type', 'livecanvas-forge-ai') . '</span>';
                echo '<div class="lcfa-theme-library-filterbar lcfa-theme-library-filterbar--category" role="group" aria-labelledby="lcfa-theme-category-filter-label">';
                echo '<button class="lcfa-theme-filter is-active" type="button" data-lcfa-theme-category-filter="all" aria-pressed="true"><span>' . esc_html__('All', 'livecanvas-forge-ai') . '</span><small>' . esc_html((string) count($themes)) . '</small></button>';
                foreach ($categories as $category_key => $category) {
                    echo '<button class="lcfa-theme-filter" type="button" data-lcfa-theme-category-filter="' . esc_attr($category_key) . '" aria-pressed="false"><span>' . esc_html((string) $category['label']) . '</span><small>' . esc_html((string) $category['count']) . '</small></button>';
                }
                echo '</div>';
                echo '</div>';
            }
            echo '</div>';
            echo '</div>';

            echo '<div class="lcfa-theme-library-empty" data-lcfa-theme-empty hidden>';
            echo '<strong>' . esc_html__('No themes match these filters.', 'livecanvas-forge-ai') . '</strong>';
            echo '<span>' . esc_html__('Choose another framework or theme type to continue.', 'livecanvas-forge-ai') . '</span>';
            echo '</div>';

            echo '<div class="lcfa-grid lcfa-grid--cards">';
            foreach ($themes as $theme) {
                if (!is_array($theme)) {
                    continue;
                }

                $slug = sanitize_key((string) ($theme['slug'] ?? ''));
                $import = $imports[$slug] ?? [];
                $name = (string) ($theme['name'] ?? $slug);
                $version = (string) ($theme['version'] ?? '');
                $category = (string) ($theme['category'] ?? '');
                $has_screenshot = !empty($theme['screenshot']);
                $framework = $this->get_theme_library_framework($theme);
                $framework_profile = $this->get_theme_library_framework_profile($theme);
                $parent_installed = $this->theme_library_framework_is_ready($framework, $snapshot);
                $framework_prerequisites = $this->installer->get_framework_prerequisites($framework);
                $theme_prerequisites = $this->theme_library_installer->get_prerequisites($theme);
                $runtime_ready = !empty($framework_prerequisites['ready']) && !empty($theme_prerequisites['ready']);
                $parent_ready = $parent_installed && $runtime_ready;
                $windpress_ready = $framework !== 'picowind' || (!empty($snapshot['windpress_installed']) && !empty($snapshot['windpress_active']));
                $installed_stylesheet = $this->find_theme_library_child_stylesheet($theme);
                $child_installed = $installed_stylesheet !== '';
                $active_stylesheet = sanitize_key((string) ($snapshot['current_theme_stylesheet'] ?? ''));
                $child_active = $child_installed && sanitize_key($installed_stylesheet) === $active_stylesheet;
                $import_status = (string) ($import['status'] ?? '');
                $is_imported = !empty($import) && in_array($import_status, ['ready', 'imported', 'build_required', 'build_failed'], true);
                $build_ready = $framework !== 'picowind' || in_array($import_status, ['ready', 'imported'], true);
                $build_pending = $framework === 'picowind' && in_array($import_status, ['build_required', 'build_failed'], true);
                $preview_ready = $this->theme_library_preview_is_current($theme);
                echo '<article class="lcfa-theme-card" data-lcfa-theme-card data-lcfa-theme-framework="' . esc_attr($framework) . '" data-lcfa-theme-category="' . esc_attr(sanitize_key($category)) . '">';
                if ($has_screenshot) {
                    echo '<figure class="lcfa-theme-card__media">';
                    echo '<img src="' . esc_url((string) $theme['screenshot']) . '" alt="">';
                    $this->render_theme_library_framework_identity($framework_profile, true);
                    echo '<figcaption class="lcfa-theme-card__overlay">';
                    echo '<span><strong>' . esc_html($name) . '</strong><small>' . esc_html(sprintf(__('Version %s', 'livecanvas-forge-ai'), $version)) . '</small></span>';
                    if ($category !== '') {
                        echo '<em>' . esc_html($category) . '</em>';
                    }
                    echo '</figcaption>';
                    echo '</figure>';
                }
                echo '<div class="lcfa-theme-card__body">';
                if (!$has_screenshot) {
                    $this->render_theme_library_framework_identity($framework_profile, false);
                }
                if (!$has_screenshot || !empty($import['audit_id'])) {
                    echo '<div class="lcfa-theme-card__meta-row">';
                    if (!$has_screenshot) {
                        echo '<h3>' . esc_html($name) . '</h3>';
                    }
                    if (!empty($import['audit_id'])) {
                        echo '<code class="lcfa-theme-card__audit">' . esc_html((string) $import['audit_id']) . '</code>';
                    }
                    echo '</div>';
                }
                if (!empty($theme['description'])) {
                    echo '<p class="lcfa-theme-card__description">' . esc_html((string) $theme['description']) . '</p>';
                }
                $this->render_theme_library_stack_badges($theme);
                echo '<div class="lcfa-theme-card__readiness">';
                $this->render_theme_library_check(__('PHP runtime', 'livecanvas-forge-ai'), $runtime_ready, $runtime_ready
                    ? sprintf(__('PHP %s is compatible', 'livecanvas-forge-ai'), (string) ($theme_prerequisites['current_php'] ?? PHP_VERSION))
                    : sprintf(
                        __('PHP %1$s installed; PHP %2$s required', 'livecanvas-forge-ai'),
                        (string) ($theme_prerequisites['current_php'] ?? PHP_VERSION),
                        (string) ($theme_prerequisites['required_php'] ?? '')
                    ));
                $this->render_theme_library_check(__('Parent theme', 'livecanvas-forge-ai'), $parent_installed, $parent_installed ? __('Installed', 'livecanvas-forge-ai') : sprintf(__('Install %s first', 'livecanvas-forge-ai'), $this->get_theme_library_framework_label($framework)));
                if ($framework === 'picowind') {
                    $windpress_detail = $windpress_ready
                        ? __('Active', 'livecanvas-forge-ai')
                        : (!empty($snapshot['windpress_installed']) ? __('Installed but inactive', 'livecanvas-forge-ai') : __('Will be installed by Picowind during activation', 'livecanvas-forge-ai'));
                    $this->render_theme_library_check(__('WindPress runtime', 'livecanvas-forge-ai'), $windpress_ready, $windpress_detail);
                }
                $this->render_theme_library_check(__('Package preview', 'livecanvas-forge-ai'), $preview_ready, $preview_ready ? __('Validated for 30 minutes', 'livecanvas-forge-ai') : __('Required before first install', 'livecanvas-forge-ai'));
                $child_theme_detail = $child_installed
                    ? ($child_active
                        ? sprintf(__('%s (active)', 'livecanvas-forge-ai'), $installed_stylesheet)
                        : $installed_stylesheet)
                    : __('Not installed yet', 'livecanvas-forge-ai');
                $this->render_theme_library_check(__('Child theme', 'livecanvas-forge-ai'), $child_installed, $child_theme_detail);
                $this->render_theme_library_check(__('Starter data', 'livecanvas-forge-ai'), $is_imported, $is_imported ? __('Imported', 'livecanvas-forge-ai') : __('Not imported yet', 'livecanvas-forge-ai'));
                if ($framework === 'picowind') {
                    $build_detail = !$is_imported
                        ? __('Available after starter import', 'livecanvas-forge-ai')
                        : ($build_ready
                            ? __('Compiled cache verified', 'livecanvas-forge-ai')
                            : ($import_status === 'build_failed' ? __('Last build failed', 'livecanvas-forge-ai') : __('Build required', 'livecanvas-forge-ai')));
                    $this->render_theme_library_check(__('Tailwind CSS', 'livecanvas-forge-ai'), $build_ready, $build_detail);
                }
                echo '</div>';
                if (!$runtime_ready) {
                    echo '<div class="lcfa-theme-card__notice is-critical">';
                    echo '<strong>' . esc_html__('PHP upgrade required', 'livecanvas-forge-ai') . '</strong>';
                    echo '<span>' . esc_html((string) ($theme_prerequisites['message'] ?? __('Upgrade PHP before installing or activating this theme.', 'livecanvas-forge-ai'))) . '</span>';
                    echo '</div>';
                } elseif (!$parent_installed) {
                    echo '<div class="lcfa-theme-card__notice">';
                    echo '<strong>' . esc_html__('Required before install', 'livecanvas-forge-ai') . '</strong>';
                    echo '<span>' . esc_html(sprintf(__('This starter needs %s. Install the parent framework first, then install the child theme.', 'livecanvas-forge-ai'), $this->get_theme_library_framework_label($framework))) . '</span>';
                    echo '</div>';
                }
                echo '<div class="lcfa-chip-row lcfa-theme-card__chips">';
                echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Version %s', 'livecanvas-forge-ai'), (string) ($theme['version'] ?? ''))) . '</span>';
                if (!empty($theme['category'])) {
                    echo '<span class="lcfa-chip">' . esc_html((string) $theme['category']) . '</span>';
                }
                if ($import_status === 'failed') {
                    echo '<span class="lcfa-chip is-critical">' . esc_html__('Import failed', 'livecanvas-forge-ai') . '</span>';
                } elseif ($import_status === 'build_failed') {
                    echo '<span class="lcfa-chip is-critical">' . esc_html__('CSS build failed', 'livecanvas-forge-ai') . '</span>';
                } elseif ($import_status === 'build_required') {
                    echo '<span class="lcfa-chip">' . esc_html__('CSS build required', 'livecanvas-forge-ai') . '</span>';
                } elseif ($is_imported) {
                    echo '<span class="lcfa-chip is-positive">' . esc_html__('Ready', 'livecanvas-forge-ai') . '</span>';
                }
                echo '</div>';
                echo '<div class="lcfa-actions">';
                $this->render_theme_library_action_form($slug, 'preview', $preview_ready ? __('Revalidate package', 'livecanvas-forge-ai') : __('Preview package', 'livecanvas-forge-ai'), false);
                if (!$parent_installed) {
                    $this->render_theme_library_framework_form(
                        $framework,
                        sprintf(__('Install %s', 'livecanvas-forge-ai'), $this->get_theme_library_framework_label($framework)),
                        empty($framework_prerequisites['ready']),
                        empty($framework_prerequisites['ready']) ? (string) ($framework_prerequisites['message'] ?? '') : ''
                    );
                }
                $install_disabled = $child_active || !$parent_ready || (!$child_installed && !$preview_ready);
                if ($child_active) {
                    $install_disabled_reason = __('This child theme is already active.', 'livecanvas-forge-ai');
                } elseif (!$runtime_ready) {
                    $install_disabled_reason = (string) ($theme_prerequisites['message'] ?? __('Upgrade PHP before installing this theme.', 'livecanvas-forge-ai'));
                } elseif (!$parent_installed) {
                    $install_disabled_reason = __('Install the parent framework theme first.', 'livecanvas-forge-ai');
                } else {
                    $install_disabled_reason = __('Preview and validate the package before installing it.', 'livecanvas-forge-ai');
                }
                $install_label = $child_active
                    ? __('Current child theme', 'livecanvas-forge-ai')
                    : ($child_installed ? __('Activate child theme', 'livecanvas-forge-ai') : __('Install child theme', 'livecanvas-forge-ai'));
                $this->render_theme_library_action_form($slug, 'install', $install_label, false, $install_disabled, $install_disabled_reason);
                $import_disabled_reason = !$runtime_ready
                    ? (string) ($theme_prerequisites['message'] ?? __('Upgrade PHP before importing this theme.', 'livecanvas-forge-ai'))
                    : (!$parent_installed
                        ? __('Install the parent framework theme first.', 'livecanvas-forge-ai')
                        : __('Install the child theme before importing starter data.', 'livecanvas-forge-ai'));
                $this->render_theme_library_action_form($slug, 'import', $is_imported ? __('Re-import starter data', 'livecanvas-forge-ai') : __('Import starter data', 'livecanvas-forge-ai'), true, !$parent_ready || !$child_installed, $import_disabled_reason, $is_imported);
                if ($build_pending) {
                    $build_unavailable = empty($build_capability['build_available']);
                    $this->render_theme_library_action_form(
                        $slug,
                        'build',
                        $import_status === 'build_failed' ? __('Retry Tailwind build', 'livecanvas-forge-ai') : __('Build Tailwind CSS', 'livecanvas-forge-ai'),
                        false,
                        $build_unavailable,
                        $build_unavailable ? (string) ($build_capability['message'] ?? __('Local WindPress build is unavailable.', 'livecanvas-forge-ai')) : ''
                    );
                }
                echo '</div>';
                echo '</div>';
                echo '</article>';
            }
            echo '</div>';
        }
        echo '</section>';

        $rollback_rows = array_values($imports);
        foreach ($rollback_history as $history_row) {
            $rollback_rows[] = $history_row;
        }

        if ($rollback_rows) {
            echo '<section class="lcfa-card">';
            echo '<div class="lcfa-card-head">';
            echo $this->get_icon_svg('shuffle');
            echo '<div><h2>' . esc_html__('Imported themes and rollback', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Rollback restores the previous theme, homepage, imported content, media, menus, and stored options where possible.', 'livecanvas-forge-ai') . '</p></div>';
            echo '</div>';
            echo '<div class="lcfa-table-wrap"><table class="widefat striped"><thead><tr>';
            echo '<th>' . esc_html__('Theme', 'livecanvas-forge-ai') . '</th><th>' . esc_html__('Version', 'livecanvas-forge-ai') . '</th><th>' . esc_html__('Status', 'livecanvas-forge-ai') . '</th><th>' . esc_html__('Imported', 'livecanvas-forge-ai') . '</th><th>' . esc_html__('Audit', 'livecanvas-forge-ai') . '</th><th>' . esc_html__('Action', 'livecanvas-forge-ai') . '</th>';
            echo '</tr></thead><tbody>';
            foreach ($rollback_rows as $import) {
                if (!is_array($import)) {
                    continue;
                }
                $audit_id = sanitize_key((string) ($import['audit_id'] ?? ''));
                $rollback_record = $audit_id !== '' ? LCFA_Settings::get_rollback_record($audit_id) : [];
                $rollback_available = $audit_id !== ''
                    && is_array($rollback_record)
                    && empty($rollback_record['restored_at']);
                echo '<tr>';
                echo '<td>' . esc_html((string) ($import['slug'] ?? '')) . '</td>';
                echo '<td>' . esc_html((string) ($import['version'] ?? '')) . '</td>';
                echo '<td>' . esc_html((string) ($import['status'] ?? 'imported')) . '</td>';
                echo '<td>' . esc_html((string) ($import['imported_at'] ?? '')) . '</td>';
                echo '<td><code>' . esc_html($audit_id) . '</code></td>';
                echo '<td>';
                if (in_array((string) ($import['status'] ?? ''), ['build_required', 'build_failed'], true)) {
                    $this->render_theme_library_action_form((string) ($import['slug'] ?? ''), 'build', __('Build CSS', 'livecanvas-forge-ai'), false, empty($build_capability['build_available']), (string) ($build_capability['message'] ?? ''));
                }
                if ($rollback_available) {
                    $this->render_theme_library_rollback_form($audit_id);
                } else {
                    echo '<span class="lcfa-chip">' . esc_html__('Restored', 'livecanvas-forge-ai') . '</span>';
                }
                echo '</td>';
                echo '</tr>';
            }
            echo '</tbody></table></div>';
            echo '</section>';
        }

        echo '</div>';
    }

    private function get_theme_library_rollback_history(array $imports): array {
        $current_audits = [];
        foreach ($imports as $import) {
            if (is_array($import) && !empty($import['audit_id'])) {
                $current_audits[sanitize_key((string) $import['audit_id'])] = true;
            }
        }

        $history = [];
        foreach (array_reverse(LCFA_Settings::get_rollback_records(), true) as $audit_id => $record) {
            $audit_id = sanitize_key((string) $audit_id);
            if (
                $audit_id === ''
                || isset($current_audits[$audit_id])
                || !is_array($record)
                || (string) ($record['type'] ?? '') !== 'theme_library_import'
                || !empty($record['restored_at'])
            ) {
                continue;
            }

            $history[] = [
                'slug'        => sanitize_key((string) ($record['theme_slug'] ?? '')),
                'version'     => sanitize_text_field((string) ($record['theme_version'] ?? '')),
                'status'      => 'rollback_available',
                'imported_at' => sanitize_text_field((string) ($record['created_at'] ?? '')),
                'audit_id'    => $audit_id,
            ];
        }

        return $history;
    }

    private function render_theme_library_action_form(string $slug, string $operation, string $label, bool $confirm, bool $disabled = false, string $disabled_reason = '', bool $show_force = false): void {
        $form_class = 'lcfa-theme-action lcfa-theme-action--' . sanitize_html_class($operation);
        $button_class = 'button lcfa-theme-button lcfa-theme-button--' . sanitize_html_class($operation) . (in_array($operation, ['import', 'build'], true) ? ' button-primary' : '');
        echo '<form class="' . esc_attr($form_class) . '" method="post" action="' . esc_url(admin_url('admin-post.php')) . '"' . ($confirm ? ' onsubmit="return confirm(\'' . esc_js(__('This will write starter data to the site. Continue?', 'livecanvas-forge-ai')) . '\');"' : '') . '>';
        wp_nonce_field('lcfa_theme_library');
        echo '<input type="hidden" name="action" value="lcfa_theme_library">';
        echo '<input type="hidden" name="operation" value="' . esc_attr($operation) . '">';
        echo '<input type="hidden" name="slug" value="' . esc_attr($slug) . '">';
        if ($operation === 'import' && $show_force) {
            echo '<label class="lcfa-inline-check lcfa-theme-card__force"><input type="checkbox" name="force" value="1"> <span>' . esc_html__('Force update existing import', 'livecanvas-forge-ai') . '</span></label>';
        }
        echo '<button class="' . esc_attr($button_class) . '" type="submit"' . ($disabled ? ' disabled aria-disabled="true" title="' . esc_attr($disabled_reason) . '"' : '') . '>' . esc_html($label) . '</button>';
        echo '</form>';
    }

    private function remember_theme_library_preview(string $slug, array $theme, array $result): void {
        $key = $this->get_theme_library_preview_key($slug);
        $checksum = $this->normalize_theme_library_checksum((string) ($result['checksum'] ?? ($theme['checksum'] ?? '')));
        if ($key === '' || $checksum === '') {
            return;
        }

        set_transient($key, [
            'checksum' => $checksum,
            'version'  => sanitize_text_field((string) ($theme['version'] ?? '')),
        ], self::THEME_LIBRARY_PREVIEW_TTL);
    }

    private function theme_library_preview_is_current(array $theme): bool {
        $slug = sanitize_key((string) ($theme['slug'] ?? ''));
        $key = $this->get_theme_library_preview_key($slug);
        $expected_checksum = $this->normalize_theme_library_checksum((string) ($theme['checksum'] ?? ''));
        if ($key === '' || $expected_checksum === '') {
            return false;
        }

        $preview = get_transient($key);
        if (!is_array($preview)) {
            return false;
        }

        $preview_checksum = $this->normalize_theme_library_checksum((string) ($preview['checksum'] ?? ''));
        $preview_version = sanitize_text_field((string) ($preview['version'] ?? ''));
        $theme_version = sanitize_text_field((string) ($theme['version'] ?? ''));

        return $preview_checksum !== ''
            && hash_equals($expected_checksum, $preview_checksum)
            && $preview_version === $theme_version;
    }

    private function get_theme_library_preview_key(string $slug): string {
        $slug = sanitize_key($slug);
        $user_id = get_current_user_id();
        if ($slug === '' || $user_id <= 0) {
            return '';
        }

        return self::THEME_LIBRARY_PREVIEW_TRANSIENT_PREFIX . $user_id . '_' . $slug;
    }

    private function normalize_theme_library_checksum(string $checksum): string {
        $checksum = strtolower(trim($checksum));
        if (strpos($checksum, 'sha256:') === 0) {
            $checksum = substr($checksum, 7);
        }

        return preg_match('/^[a-f0-9]{64}$/', $checksum) ? $checksum : '';
    }

    private function render_theme_library_framework_form(string $framework, string $label, bool $disabled = false, string $disabled_reason = ''): void {
        $framework = $this->normalize_supported_framework($framework);
        if ($framework === '') {
            return;
        }

        echo '<form class="lcfa-theme-action lcfa-theme-action--framework" method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('lcfa_theme_library');
        echo '<input type="hidden" name="action" value="lcfa_theme_library">';
        echo '<input type="hidden" name="operation" value="install_framework">';
        echo '<input type="hidden" name="framework" value="' . esc_attr($framework) . '">';
        echo '<button class="button button-primary lcfa-theme-button lcfa-theme-button--framework" type="submit"' . ($disabled ? ' disabled aria-disabled="true" title="' . esc_attr($disabled_reason) . '"' : '') . '>' . esc_html($label) . '</button>';
        echo '</form>';
    }

    private function render_theme_library_stack_badges(array $theme): void {
        $badges = $this->get_theme_library_stack_badges($theme);
        if (!$badges) {
            return;
        }

        echo '<div class="lcfa-theme-stack-badges" aria-label="' . esc_attr__('Theme stack', 'livecanvas-forge-ai') . '">';
        foreach ($badges as $badge) {
            echo '<span class="' . esc_attr('lcfa-stack-badge lcfa-stack-badge--' . sanitize_html_class($badge['key'])) . '">';
            echo '<span class="lcfa-stack-badge__mark">' . esc_html($badge['mark']) . '</span>';
            echo '<span>' . esc_html($badge['label']) . '</span>';
            echo '</span>';
        }
        echo '</div>';
    }

    private function render_theme_library_framework_identity(array $profile, bool $overlay): void {
        $framework = sanitize_key((string) ($profile['key'] ?? ''));
        if ($framework === '') {
            return;
        }

        $classes = 'lcfa-theme-framework-identity lcfa-theme-framework-identity--' . sanitize_html_class($framework);
        if ($overlay) {
            $classes .= ' is-overlay';
        }

        echo '<span class="' . esc_attr($classes) . '">';
        echo '<span class="lcfa-theme-framework-identity__mark" aria-hidden="true">' . esc_html((string) ($profile['mark'] ?? '')) . '</span>';
        echo '<span class="lcfa-theme-framework-identity__copy">';
        echo '<strong>' . esc_html((string) ($profile['label'] ?? '')) . '</strong>';
        echo '<small>' . esc_html((string) ($profile['technology'] ?? '')) . '</small>';
        echo '</span>';
        echo '</span>';
    }

    private function render_theme_library_check(string $label, bool $ok, string $detail): void {
        echo '<span class="' . esc_attr('lcfa-theme-check' . ($ok ? ' is-ok' : ' is-pending')) . '">';
        echo '<strong>' . esc_html($label) . '</strong>';
        echo '<small>' . esc_html($detail) . '</small>';
        echo '</span>';
    }

    private function get_theme_library_stack_badges(array $theme): array {
        $framework = $this->get_theme_library_framework($theme);
        $css = sanitize_key((string) ($theme['css'] ?? ($theme['stack']['css'] ?? '')));
        $ui = sanitize_key((string) ($theme['ui'] ?? ($theme['stack']['ui'] ?? '')));
        $badges = [];

        if ($framework === 'picowind') {
            $badges[] = ['key' => 'picowind', 'mark' => 'PW', 'label' => __('Picowind', 'livecanvas-forge-ai')];
            $badges[] = ['key' => 'tailwind', 'mark' => 'TW', 'label' => __('Tailwind', 'livecanvas-forge-ai')];
            $badges[] = ['key' => 'daisyui', 'mark' => 'DU', 'label' => __('DaisyUI', 'livecanvas-forge-ai')];
        } elseif ($framework === 'picostrap') {
            $badges[] = ['key' => 'picostrap', 'mark' => 'PS', 'label' => __('Picostrap', 'livecanvas-forge-ai')];
            $badges[] = ['key' => 'bootstrap', 'mark' => 'B', 'label' => __('Bootstrap', 'livecanvas-forge-ai')];
        }

        if ($css !== '' && !in_array($css, wp_list_pluck($badges, 'key'), true)) {
            $badges[] = ['key' => $css, 'mark' => strtoupper(substr($css, 0, 2)), 'label' => ucfirst($css)];
        }

        if ($ui !== '' && !in_array($ui, wp_list_pluck($badges, 'key'), true)) {
            $badges[] = ['key' => $ui, 'mark' => strtoupper(substr($ui, 0, 2)), 'label' => ucfirst($ui)];
        }

        return $badges;
    }

    private function get_theme_library_framework_profile(array $theme): array {
        $framework = $this->get_theme_library_framework($theme);
        if ($framework === 'picostrap') {
            return [
                'key'        => 'picostrap',
                'mark'       => 'PS',
                'label'      => __('Picostrap', 'livecanvas-forge-ai'),
                'technology' => __('Bootstrap 5', 'livecanvas-forge-ai'),
            ];
        }

        return [
            'key'        => 'picowind',
            'mark'       => 'PW',
            'label'      => __('Picowind', 'livecanvas-forge-ai'),
            'technology' => __('Tailwind CSS + DaisyUI', 'livecanvas-forge-ai'),
        ];
    }

    private function get_theme_library_framework(array $theme): string {
        $framework = sanitize_key((string) ($theme['framework'] ?? ($theme['stack']['framework'] ?? '')));
        if ($framework === '') {
            $framework = 'picowind';
        }

        return $this->normalize_supported_framework($framework) ?: $framework;
    }

    private function get_theme_library_framework_label(string $framework): string {
        $framework = $this->normalize_supported_framework($framework);
        if ($framework === 'picowind') {
            return __('Picowind', 'livecanvas-forge-ai');
        }

        if ($framework === 'picostrap') {
            return __('Picostrap', 'livecanvas-forge-ai');
        }

        return __('required framework', 'livecanvas-forge-ai');
    }

    private function theme_library_framework_is_ready(string $framework, array $snapshot): bool {
        $framework = $this->normalize_supported_framework($framework);
        if ($framework === 'picowind') {
            return !empty($snapshot['picowind_candidates']) || wp_get_theme('picowind')->exists();
        }

        if ($framework === 'picostrap') {
            return !empty($snapshot['picostrap_candidates']) || wp_get_theme('picostrap5')->exists() || wp_get_theme('picostrap')->exists();
        }

        return false;
    }

    private function find_theme_library_child_stylesheet(array $theme): string {
        $expected_slug = sanitize_key((string) ($theme['slug'] ?? ''));
        $expected_name = sanitize_text_field((string) ($theme['name'] ?? ''));

        if ($expected_slug !== '' && wp_get_theme($expected_slug)->exists()) {
            return $expected_slug;
        }

        foreach (wp_get_themes() as $candidate_stylesheet => $candidate) {
            if (!$candidate->exists()) {
                continue;
            }

            $candidate_name = sanitize_text_field((string) $candidate->get('Name'));
            $candidate_key = sanitize_key((string) $candidate_stylesheet);
            if ($expected_name !== '' && strcasecmp($candidate_name, $expected_name) === 0) {
                return (string) $candidate_stylesheet;
            }

            if ($expected_slug !== '' && strpos($candidate_key, $expected_slug . '-') === 0) {
                return (string) $candidate_stylesheet;
            }
        }

        return '';
    }

    private function render_theme_library_rollback_form(string $audit_id): void {
        if ($audit_id === '') {
            return;
        }

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(\'' . esc_js(__('Rollback this Theme Library import?', 'livecanvas-forge-ai')) . '\');">';
        wp_nonce_field('lcfa_theme_library');
        echo '<input type="hidden" name="action" value="lcfa_theme_library">';
        echo '<input type="hidden" name="operation" value="rollback">';
        echo '<input type="hidden" name="audit_id" value="' . esc_attr($audit_id) . '">';
        echo '<button class="button" type="submit">' . esc_html__('Rollback', 'livecanvas-forge-ai') . '</button>';
        echo '</form>';
    }

    private function render_genesis_tab(array $settings, array $snapshot, array $brief, array $summary, array $plan, array $progress, string $brief_hash): void {
        $plan_pages      = is_array($plan['pages'] ?? null) ? $plan['pages'] : [];
        $plan_tasks      = is_array($plan['tasks'] ?? null) ? $plan['tasks'] : [];
        $plan_counts     = is_array($plan['counts'] ?? null) ? $plan['counts'] : [];
        $plan_stack      = is_array($plan['stack'] ?? null) ? $plan['stack'] : [];
        $progress_tasks  = is_array($progress['tasks'] ?? null) ? $progress['tasks'] : [];
        $execution_plan  = $this->get_genesis_executor()->get_execution_plan();
        $execution_counts = is_array($execution_plan['counts'] ?? null) ? $execution_plan['counts'] : [];
        $plan_available  = !empty($plan);
        $plan_stale      = $plan_available && (
            (string) ($plan['brief_hash'] ?? '') !== $brief_hash
            || (string) ($plan_stack['framework'] ?? '') !== (string) ($snapshot['detected_framework'] ?? '')
            || (string) ($plan_stack['theme'] ?? '') !== (string) ($snapshot['current_theme_stylesheet'] ?? '')
            || (string) ($plan_stack['site_mode'] ?? '') !== (string) ($snapshot['site_mode'] ?? '')
        );
        $next_task       = !$plan_stale && is_array($execution_plan['next_task'] ?? null)
            ? $execution_plan['next_task']
            : (!$plan_stale ? $this->get_next_genesis_task($plan_tasks, $progress_tasks) : null);

        echo '<div class="lcfa-main">';

        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('stars');
        echo '<div><h2>' . esc_html__('Project Brief', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Capture the persistent project context used to generate a reusable build plan after your coding agent connection is ready.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form">';
        wp_nonce_field('lcfa_project_brief');
        echo '<input type="hidden" name="action" value="lcfa_project_brief">';

        echo '<div class="lcfa-brief-grid">';
        echo '<label><span>' . esc_html__('Project mode', 'livecanvas-forge-ai') . '</span>';
        echo '<select name="project_mode">';
        echo '<option value="from_scratch"' . selected($brief['project_mode'], 'from_scratch', false) . '>' . esc_html__('Build from scratch', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="step_by_step"' . selected($brief['project_mode'], 'step_by_step', false) . '>' . esc_html__('Step-by-step evolution', 'livecanvas-forge-ai') . '</option>';
        echo '</select></label>';

        echo '<label><span>' . esc_html__('Brand name', 'livecanvas-forge-ai') . '</span><input type="text" name="brand_name" value="' . esc_attr($brief['brand_name']) . '"></label>';
        echo '<label><span>' . esc_html__('Sector', 'livecanvas-forge-ai') . '</span><input type="text" name="sector" value="' . esc_attr($brief['sector']) . '"></label>';
        echo '<label><span>' . esc_html__('Tone of voice', 'livecanvas-forge-ai') . '</span><input type="text" name="tone" value="' . esc_attr($brief['tone']) . '"></label>';

        echo '<label><span>' . esc_html__('Logo status', 'livecanvas-forge-ai') . '</span>';
        echo '<select name="logo_status">';
        echo '<option value="existing"' . selected($brief['logo_status'], 'existing', false) . '>' . esc_html__('Already available', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="to_generate"' . selected($brief['logo_status'], 'to_generate', false) . '>' . esc_html__('Needs generation', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="not_needed"' . selected($brief['logo_status'], 'not_needed', false) . '>' . esc_html__('Not required', 'livecanvas-forge-ai') . '</option>';
        echo '</select></label>';

        echo '<label class="lcfa-brief-grid__wide"><span>' . esc_html__('Required pages', 'livecanvas-forge-ai') . '</span><textarea name="required_pages" rows="3">' . esc_textarea($brief['required_pages']) . '</textarea></label>';
        echo '<label class="lcfa-brief-grid__wide"><span>' . esc_html__('Additional notes', 'livecanvas-forge-ai') . '</span><textarea name="notes" rows="4">' . esc_textarea($brief['notes']) . '</textarea></label>';
        echo '</div>';

        echo '<div class="lcfa-cta-row">';
        echo '<button class="button button-primary">' . esc_html__('Save Project Brief', 'livecanvas-forge-ai') . '</button>';
        echo '</div>';
        echo '</form>';
        echo '</section>';

        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('layers');
        echo '<div><h2>' . esc_html__('Build plan', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Turn the project brief into an actionable sequence of pages and tasks that can be loaded directly into the Command Deck.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<div class="lcfa-chip-row">';
        echo '<span class="lcfa-chip' . ($plan_available && !$plan_stale ? ' is-positive' : ($plan_stale ? ' is-negative' : '')) . '">' . esc_html($plan_available ? ($plan_stale ? __('Plan outdated', 'livecanvas-forge-ai') : __('Plan ready', 'livecanvas-forge-ai')) : __('No plan yet', 'livecanvas-forge-ai')) . '</span>';
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Project mode: %s', 'livecanvas-forge-ai'), (string) ($brief['project_mode'] ?: 'from_scratch'))) . '</span>';
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Framework: %s', 'livecanvas-forge-ai'), (string) ($snapshot['detected_framework'] ?: 'unknown'))) . '</span>';
        if ($plan_available && !empty($plan_counts['tasks'])) {
            echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Tasks: %d', 'livecanvas-forge-ai'), (int) $plan_counts['tasks'])) . '</span>';
        }
        if ($plan_available && !empty($plan_counts['pages'])) {
            echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Pages: %d', 'livecanvas-forge-ai'), (int) $plan_counts['pages'])) . '</span>';
        }
        if ($plan_available) {
            echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Pending: %d', 'livecanvas-forge-ai'), (int) ($execution_counts['pending'] ?? $this->count_genesis_tasks_by_status($progress_tasks, 'pending')))) . '</span>';
            echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Previewed: %d', 'livecanvas-forge-ai'), (int) ($execution_counts['previewed'] ?? $this->count_genesis_tasks_by_status($progress_tasks, 'previewed')))) . '</span>';
            echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Completed: %d', 'livecanvas-forge-ai'), (int) ($execution_counts['applied'] ?? $this->count_genesis_tasks_by_status($progress_tasks, 'applied')))) . '</span>';
            echo '<span class="lcfa-chip' . (((int) ($execution_counts['failed'] ?? $this->count_genesis_tasks_by_status($progress_tasks, 'failed'))) > 0 ? ' is-negative' : '') . '">' . esc_html(sprintf(__('Failed: %d', 'livecanvas-forge-ai'), (int) ($execution_counts['failed'] ?? $this->count_genesis_tasks_by_status($progress_tasks, 'failed')))) . '</span>';
        }
        echo '</div>';

        if ($plan_stale) {
            echo '<div class="notice notice-warning inline"><p>' . esc_html__('The project brief changed after the last plan generation. Regenerate the plan before using task deep-links.', 'livecanvas-forge-ai') . '</p></div>';
        } elseif (!$plan_available) {
            echo '<p>' . esc_html__('No build plan has been generated yet. Generate one from the current brief to get page suggestions and task deep-links.', 'livecanvas-forge-ai') . '</p>';
        } elseif (!empty($plan['generated_at'])) {
            echo '<p>' . esc_html(sprintf(__('Last generated at %s.', 'livecanvas-forge-ai'), get_date_from_gmt((string) $plan['generated_at'], get_option('date_format') . ' ' . get_option('time_format')))) . '</p>';
        }

        echo '<details class="lcfa-command-details" data-lcfa-command-thread-tools>';
        echo '<summary>' . esc_html__('Thread tools', 'livecanvas-forge-ai') . '</summary>';
        echo '<div class="lcfa-command-details__body">';
        echo '<div class="lcfa-cta-row">';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
        wp_nonce_field('lcfa_generate_plan');
        echo '<input type="hidden" name="action" value="lcfa_generate_plan">';
        echo '<button class="button button-primary" type="submit">' . esc_html($plan_available ? __('Regenerate build plan', 'livecanvas-forge-ai') : __('Generate build plan', 'livecanvas-forge-ai')) . '</button>';
        echo '</form>';
        if ($plan_available && !$plan_stale && is_array($next_task)) {
            echo $this->render_genesis_execute_form('preview_next', '', __('Preview next task', 'livecanvas-forge-ai'), false, 'button');
            echo $this->render_genesis_execute_form('apply_next', '', __('Apply next task', 'livecanvas-forge-ai'), false, 'button button-primary');
        }
        echo '<a class="button" href="' . esc_url(admin_url('admin.php?page=lcfa-dashboard&tab=command')) . '">' . esc_html__('Open Command Deck', 'livecanvas-forge-ai') . '</a>';
        echo '<a class="button" href="' . esc_url(admin_url('admin.php?page=lcfa-dashboard&tab=connections')) . '">' . esc_html__('Open Connections', 'livecanvas-forge-ai') . '</a>';
        echo '</div>';

        if ($plan_available && !$plan_stale && is_array($next_task)) {
            echo '<div class="lcfa-guide">';
            echo '<h3>' . esc_html__('Execution controls', 'livecanvas-forge-ai') . '</h3>';
            echo '<p>' . esc_html__('Use Genesis as the execution queue for the project brief. Preview first when you want to inspect output, or apply directly when the task is deterministic.', 'livecanvas-forge-ai') . '</p>';
            echo '<div class="lcfa-chip-row">';
            if (!empty($next_task['stage'])) {
                echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Next stage: %s', 'livecanvas-forge-ai'), (string) $next_task['stage'])) . '</span>';
            }
            echo '<span class="lcfa-chip is-positive">' . esc_html(sprintf(__('Next task: %s', 'livecanvas-forge-ai'), (string) ($next_task['label'] ?? __('Genesis task', 'livecanvas-forge-ai')))) . '</span>';
            echo '</div>';
            echo '</div>';
        }

        if ($plan_available) {
            $this->render_genesis_plan_panel($plan_pages, $plan_tasks, $progress_tasks);
        }
        echo '</section>';

        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('command');
        echo '<div><h2>' . esc_html__('Operations overview', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Once the brief is stored, use Connections and Command Deck from the same screen to execute the build progressively.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';
        echo '<ul class="lcfa-bullets">';
        echo '<li>' . esc_html(sprintf(__('Inventory ready: %1$d pages, %2$d headers, %3$d footers, %4$d dynamic templates.', 'livecanvas-forge-ai'), $summary['pages'], $summary['headers'], $summary['footers'], $summary['dynamic_templates'])) . '</li>';
        echo '<li>' . esc_html__('Execution model: preview first, diff when content changes, apply only when requested.', 'livecanvas-forge-ai') . '</li>';
        echo '<li>' . esc_html__('Use this brief as the persistent input for generating structure, copy, sections, and dynamic templates.', 'livecanvas-forge-ai') . '</li>';
        echo '</ul>';
        echo '</section>';

        echo '</div>';
    }

    private function render_genesis_plan_panel(array $pages, array $tasks, array $progress_tasks): void {
        if ($pages) {
            echo '<div class="lcfa-guide">';
            echo '<h3>' . esc_html__('Planned pages', 'livecanvas-forge-ai') . '</h3>';
            echo '<div class="lcfa-genesis-page-grid">';
            foreach ($pages as $page) {
                if (!is_array($page)) {
                    continue;
                }

                echo '<article class="lcfa-genesis-page-card">';
                echo '<div class="lcfa-chip-row">';
                if (!empty($page['kind'])) {
                    echo '<span class="lcfa-chip">' . esc_html((string) $page['kind']) . '</span>';
                }
                if (!empty($page['homepage'])) {
                    echo '<span class="lcfa-chip is-positive">' . esc_html__('Homepage', 'livecanvas-forge-ai') . '</span>';
                }
                echo '</div>';
                echo '<strong>' . esc_html((string) ($page['title'] ?? __('Untitled', 'livecanvas-forge-ai'))) . '</strong>';
                echo '<code>' . esc_html((string) ($page['slug'] ?? '')) . '</code>';
                echo '<p>' . esc_html((string) ($page['description'] ?? '')) . '</p>';
                echo '</article>';
            }
            echo '</div>';
            echo '</div>';
        }

        if (!$tasks) {
            return;
        }

        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('Suggested execution order', 'livecanvas-forge-ai') . '</h3>';
        echo '<div class="lcfa-genesis-task-list">';

        foreach ($tasks as $task) {
            if (!is_array($task)) {
                continue;
            }

            $payload = is_array($task['payload'] ?? null) ? $task['payload'] : [];
            $task_url = $this->get_genesis_task_command_url($task);
            $task_id = sanitize_key((string) ($task['id'] ?? ''));
            $task_progress = $task_id !== '' && isset($progress_tasks[$task_id]) && is_array($progress_tasks[$task_id]) ? $progress_tasks[$task_id] : [];
            $task_status = $this->get_genesis_task_status_label($task_progress);

            echo '<article class="lcfa-genesis-task">';
            echo '<div class="lcfa-history-copy">';
            echo '<strong>' . esc_html((string) ($task['label'] ?? __('Genesis task', 'livecanvas-forge-ai'))) . '</strong>';
            echo '<span>' . esc_html((string) ($task['description'] ?? '')) . '</span>';
            echo '</div>';
            echo '<div class="lcfa-chip-row">';
            if (!empty($task['stage'])) {
                echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Stage: %s', 'livecanvas-forge-ai'), (string) $task['stage'])) . '</span>';
            }
            if ($task_status['label'] !== '') {
                echo '<span class="lcfa-chip' . esc_attr($task_status['class']) . '">' . esc_html($task_status['label']) . '</span>';
            }
            if (!empty($payload['action'])) {
                echo '<span class="lcfa-chip is-positive">' . esc_html((string) $payload['action']) . '</span>';
            } else {
                echo '<span class="lcfa-chip">' . esc_html__('Advisory', 'livecanvas-forge-ai') . '</span>';
            }
            echo '</div>';
            if (!empty($task['user_prompt'])) {
                echo '<p class="lcfa-result-message">' . esc_html((string) $task['user_prompt']) . '</p>';
            }
            if (!empty($task_progress['message'])) {
                echo '<p class="lcfa-result-message">' . esc_html((string) $task_progress['message']) . '</p>';
            }
            echo '<div class="lcfa-cta-row">';
            if (!empty($payload['action'])) {
                echo $this->render_genesis_execute_form('preview_task', $task_id, __('Preview task', 'livecanvas-forge-ai'), true, 'button button-small');
                $apply_label = (($task_progress['status'] ?? '') === 'failed')
                    ? __('Retry task', 'livecanvas-forge-ai')
                    : __('Apply task', 'livecanvas-forge-ai');
                echo $this->render_genesis_execute_form(($task_progress['status'] ?? '') === 'failed' ? 'retry_task' : 'apply_task', $task_id, $apply_label, true, 'button button-small button-primary');
            } else {
                echo $this->render_genesis_execute_form('acknowledge_task', $task_id, __('Mark reviewed', 'livecanvas-forge-ai'), true, 'button button-small');
            }
            if ($task_url !== '') {
                echo '<a class="button button-small button-primary" href="' . esc_url($task_url) . '">' . esc_html__('Load in Command Deck', 'livecanvas-forge-ai') . '</a>';
            }
            echo '</div>';
            echo '</article>';
        }

        echo '</div>';
        echo '</div>';
        echo '</details>';
        echo '</details>';
    }

    private function get_genesis_task_command_url(array $task): string {
        $payload = is_array($task['payload'] ?? null) ? $task['payload'] : [];

        if (empty($payload['action'])) {
            return '';
        }

        $redirect_args = $this->build_command_redirect_args($payload);

        if (!empty($task['user_prompt'])) {
            $redirect_args['user_prompt'] = sanitize_textarea_field((string) $task['user_prompt']);
        }

        if (!empty($task['id'])) {
            $redirect_args['genesis_task_id'] = sanitize_key((string) $task['id']);
        }

        if (!isset($redirect_args['execution_target'])) {
            $redirect_args['execution_target'] = 'local';
        }

        return $this->get_command_url($redirect_args);
    }

    private function get_next_genesis_task(array $tasks, array $progress_tasks): ?array {
        foreach ($tasks as $task) {
            if (!is_array($task)) {
                continue;
            }

            $task_id = sanitize_key((string) ($task['id'] ?? ''));
            $status  = $task_id !== '' && !empty($progress_tasks[$task_id]['status'])
                ? (string) $progress_tasks[$task_id]['status']
                : 'pending';

            if ($status !== 'applied') {
                return $task;
            }
        }

        return null;
    }

    private function get_genesis_executor(): LCFA_Genesis_Executor {
        if (!$this->genesis_executor instanceof LCFA_Genesis_Executor) {
            $this->genesis_executor = new LCFA_Genesis_Executor($this->environment, $this->command_deck);
        }

        return $this->genesis_executor;
    }

    private function render_genesis_execute_form(string $execution_mode, string $task_id, string $label, bool $small = false, string $button_class = 'button'): string {
        $classes = trim($button_class);

        if ($small && strpos($classes, 'button-small') === false) {
            $classes .= ' button-small';
        }

        ob_start();
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
        wp_nonce_field('lcfa_genesis_execute');
        echo '<input type="hidden" name="action" value="lcfa_genesis_execute">';
        echo '<input type="hidden" name="execution_mode" value="' . esc_attr($execution_mode) . '">';
        echo '<input type="hidden" name="thread_id" value="default">';
        echo '<input type="hidden" name="execution_target" value="local">';
        if ($task_id !== '') {
            echo '<input type="hidden" name="task_id" value="' . esc_attr($task_id) . '">';
        }
        echo '<button class="' . esc_attr($classes) . '" type="submit">' . esc_html($label) . '</button>';
        echo '</form>';

        return (string) ob_get_clean();
    }

    private function count_genesis_tasks_by_status(array $progress_tasks, string $status): int {
        $count = 0;

        foreach ($progress_tasks as $task_progress) {
            if (!is_array($task_progress)) {
                continue;
            }

            if ((string) ($task_progress['status'] ?? '') === $status) {
                $count++;
            }
        }

        return $count;
    }

    private function get_genesis_task_status_label(array $progress): array {
        $status = (string) ($progress['status'] ?? 'pending');

        switch ($status) {
            case 'applied':
                return [
                    'label' => __('Applied', 'livecanvas-forge-ai'),
                    'class' => ' is-positive',
                ];
            case 'previewed':
                return [
                    'label' => __('Previewed', 'livecanvas-forge-ai'),
                    'class' => '',
                ];
            case 'failed':
                return [
                    'label' => __('Needs attention', 'livecanvas-forge-ai'),
                    'class' => ' is-negative',
                ];
            default:
                return [
                    'label' => __('Pending', 'livecanvas-forge-ai'),
                    'class' => '',
                ];
        }
    }

    private function render_connections_tab(array $settings, array $snapshot): void {
        $connections      = LCFA_Settings::get_connections();
        $stored_preferred_client = trim((string) ($connections['preferred_client'] ?? ''));
        $preferred_client = $this->normalize_connection_client($stored_preferred_client !== '' ? $stored_preferred_client : 'codex');
        $site_profile     = sanitize_key((string) (($settings['site_mode'] ?? '') ?: ($snapshot['site_mode'] ?? '')));
        $default_mode     = in_array($site_profile, ['remote', 'hybrid'], true)
            ? 'remote'
            : ($site_profile === 'local' ? 'local' : ($preferred_client === 'codex' ? 'remote' : 'local'));
        $stored_mode      = $this->normalize_connection_mode((string) ($connections['connection_mode'] ?? ''));
        $selected_mode    = $stored_mode !== '' ? $stored_mode : $default_mode;
        if ($stored_mode === 'local' && in_array($site_profile, ['remote', 'hybrid'], true)) {
            // The setup profile is the source of truth for the default target.
            $selected_mode = 'remote';
            $connections['connection_mode'] = 'remote';
            LCFA_Settings::update_connections($connections);
        }
        if ($selected_mode === 'local' && method_exists('LCFA_Settings', 'sync_local_workspace_root')) {
            $connections = LCFA_Settings::sync_local_workspace_root(true);
        }
        $show_codex_fast_path = $stored_preferred_client === '' || $preferred_client === 'codex';
        $connection_test  = LCFA_Settings::consume_connection_test_result();
        $is_local_mode    = $selected_mode === 'local';
        $remote_status    = $is_local_mode ? [] : $this->remote_client->get_status();
        $mcp_status       = $is_local_mode ? $this->get_deferred_mcp_status($snapshot) : $this->context_builder->get_mcp_status();
        $mcp_bootstrap    = $is_local_mode ? $this->get_lightweight_bootstrap_payload($connections, $snapshot) : $this->context_builder->get_bootstrap_payload();
        $bundle = $this->build_selected_connection_bundle([
            'preferred_client' => $preferred_client,
            'connection_mode'  => $selected_mode,
            'workspace_root'   => $connections['workspace_root'],
        ]);
        $codex_onboarding = $show_codex_fast_path
            ? $this->get_codex_onboarding_state($connections, $bundle, $selected_mode, $remote_status)
            : [];
        if ($show_codex_fast_path && !empty($codex_onboarding['should_invalidate_ready'])) {
            $connections['connection_status'] = 'needs_attention';
            $connections['connection_last_error'] = (string) ($codex_onboarding['message'] ?? __('Codex config is stale. Regenerate or sync the Codex MCP config.', 'livecanvas-forge-ai'));
            $connections['connection_current_step'] = 'smoke_test';
            LCFA_Settings::update_connections($connections);
            $codex_onboarding = $this->get_codex_onboarding_state($connections, $bundle, $selected_mode, $remote_status);
        }
        $onboarding_state = $this->connection_onboarding->derive_state($connections, [
            'local_ready'  => !empty($mcp_status['rest_base']),
            'remote_ready' => !empty($remote_status['available']),
        ]);
        if ($show_codex_fast_path) {
            $onboarding_state['status'] = (string) ($codex_onboarding['status'] ?? 'needs_setup');
            $onboarding_state['message'] = (string) ($codex_onboarding['message'] ?? '');
        }
        $workspace_write_state = LCFA_Workspace_Access::inspect((string) ($bundle['workspace_root'] ?? ''));
        $wizard_view = $this->connection_wizard_presenter->build([
            'state'            => $onboarding_state,
            'bundle'           => $bundle,
            'workspace_access' => $workspace_write_state,
        ]);

        echo '<div class="lcfa-main">';

        $this->render_connection_test_result($connection_test);
        if (!$show_codex_fast_path) {
            $this->render_connection_onboarding_hero($bundle, $onboarding_state, $mcp_status, $snapshot, $selected_mode);
        }

        if ($this->has_framework_change_connection_decision($connections)) {
            $this->render_connection_framework_change_decision_card(
                $connections,
                (string) ($connections['framework_change_previous'] ?? ''),
                (string) ($connections['framework_change_next'] ?? '')
            );
        } elseif ($show_codex_fast_path) {
            $this->render_codex_fast_path_panel($codex_onboarding, $bundle, $connections, $selected_mode, $workspace_write_state);
            $this->render_connection_support_panel($connections, $selected_mode, $snapshot);
        } elseif (($onboarding_state['status'] ?? 'not_connected') === 'ready') {
            $this->render_connection_ready_card($wizard_view, $bundle, $connections, $workspace_write_state);
        } else {
            $this->render_connection_wizard($wizard_view, $bundle, $connections, $preferred_client, $selected_mode, $mcp_bootstrap, $settings, $snapshot, $mcp_status, $onboarding_state, $workspace_write_state);
        }

        $this->render_connections_secondary_panels();

        echo '</div>';
    }

    private function render_connection_onboarding_hero(array $bundle, array $state, array $mcp_status, array $snapshot, string $selected_mode): void {
        $status = (string) ($state['status'] ?? 'not_connected');
        $status_label = ucfirst(str_replace('_', ' ', $status));
        $client_label = ucfirst(str_replace('-', ' ', (string) ($bundle['client'] ?? 'codex')));
        $status_tone = $status === 'ready' ? 'positive' : ($status === 'needs_attention' ? 'warning' : 'neutral');
        $status_icon = $status === 'ready' ? 'check-circle' : ($status === 'needs_attention' ? 'activity' : 'plug');
        $status_heading = $status === 'ready'
            ? __('Connection ready', 'livecanvas-forge-ai')
            : ($status === 'needs_attention'
                ? __('Connection needs attention', 'livecanvas-forge-ai')
                : __('Connection not verified', 'livecanvas-forge-ai'));

        echo '<section class="lcfa-card lcfa-onboarding-hero lcfa-connection-summary" aria-labelledby="lcfa-connection-summary-title">';
        echo '<div class="lcfa-connection-summary__main">';
        echo '<span class="lcfa-connection-summary__icon is-' . esc_attr($status_tone) . '">' . $this->get_icon_svg($status_icon) . '</span>';
        echo '<div>';
        echo '<h2 id="lcfa-connection-summary-title">' . esc_html($status_heading) . '</h2>';
        if (!empty($state['message'])) {
            echo '<p>' . esc_html((string) $state['message']) . '</p>';
        }
        echo '</div>';
        echo '</div>';
        echo '<dl class="lcfa-connection-summary__facts">';
        echo '<div><dt>' . esc_html__('Coding agent', 'livecanvas-forge-ai') . '</dt><dd>' . $this->get_agent_icon_markup((string) ($bundle['client'] ?? 'codex'), 'stars') . '<span>' . esc_html($client_label) . '</span></dd></div>';
        echo '<div><dt>' . esc_html__('Status', 'livecanvas-forge-ai') . '</dt><dd class="is-' . esc_attr($status_tone) . '"><span class="lcfa-status-dot" aria-hidden="true"></span><span>' . esc_html($status_label) . '</span></dd></div>';
        echo '</dl>';
        echo '</section>';
    }

    private function get_codex_onboarding_state(array $connections, array $bundle, string $selected_mode, array $remote_status): array {
        $mode = $this->normalize_connection_mode((string) ($bundle['mode'] ?? $selected_mode));
        $connection_status = sanitize_key((string) ($connections['connection_status'] ?? ''));
        $current_step = sanitize_key((string) ($connections['connection_current_step'] ?? ''));
        $last_verified = trim((string) ($connections['connection_last_verified_at'] ?? ''));
        $last_error = trim((string) ($connections['connection_last_error'] ?? ''));
        $status = 'needs_setup';
        $primary_action = 'sync_codex';
        $message = __('Connect Codex to this WordPress site.', 'livecanvas-forge-ai');
        $checks = [];
        $manual_fallback = [];
        $should_invalidate_ready = false;

        if ($mode === 'remote') {
            return $this->get_direct_agent_onboarding()->get_codex_direct_state($connections, $bundle, $remote_status);
        }

        if (!class_exists('LCFA_Codex_Config_Manager', false)) {
            return [
                'mode' => 'local',
                'status' => 'needs_setup',
                'primary_action' => 'none',
                'checks' => [
                    'wp_root_ok' => ['label' => __('WordPress root', 'livecanvas-forge-ai'), 'ok' => false, 'message' => __('Codex config manager is unavailable.', 'livecanvas-forge-ai')],
                    'mcp_script_ok' => ['label' => __('MCP script', 'livecanvas-forge-ai'), 'ok' => false, 'message' => __('Codex config manager is unavailable.', 'livecanvas-forge-ai')],
                    'codex_config_synced' => ['label' => __('Codex config', 'livecanvas-forge-ai'), 'ok' => false, 'message' => __('Codex config manager is unavailable.', 'livecanvas-forge-ai')],
                    'hash_matches' => ['label' => __('Fingerprint', 'livecanvas-forge-ai'), 'ok' => false, 'message' => __('Pending.', 'livecanvas-forge-ai')],
                    'restart_required' => ['label' => __('Restart/reload', 'livecanvas-forge-ai'), 'ok' => false, 'message' => __('Pending.', 'livecanvas-forge-ai')],
                    'smoke_passed' => ['label' => __('Smoke test', 'livecanvas-forge-ai'), 'ok' => false, 'message' => __('Pending.', 'livecanvas-forge-ai')],
                ],
                'message' => __('Codex config manager is not available in this runtime.', 'livecanvas-forge-ai'),
                'manual_fallback' => [],
                'last_smoke' => ['verified_at' => $last_verified, 'error' => $last_error],
                'should_invalidate_ready' => false,
            ];
        }

        $manager = $this->get_codex_config_manager();
        $expected = $manager->get_expected_config($connections);
        $inspection = $manager->inspect($connections);
        $stored_hash = trim((string) ($connections['connection_last_bundle_hash'] ?? ''));
        $hash_matches = $stored_hash !== '' && hash_equals((string) ($expected['hash'] ?? ''), $stored_hash);
        $synced = !empty($inspection['synced']);
        $config_scope = sanitize_key((string) ($expected['config_scope'] ?? 'project'));
        $config_path = (string) ($expected['config_path'] ?? '');
        $site_fingerprint = (string) ($expected['site_fingerprint'] ?? '');
        $script_path = (string) ($expected['script_path'] ?? '');
        $script_ok = $script_path !== '' && is_readable($script_path);
        $wp_root = untrailingslashit((string) ($expected['wp_root'] ?? ''));
        $wp_root_ok = $wp_root !== '' && is_file($wp_root . '/wp-load.php');
        $smoke_passed = $connection_status === 'ready' && $last_verified !== '' && $synced && $hash_matches;
        $restart_required = $synced && $hash_matches && !$smoke_passed && ($current_step === 'smoke_test' || strpos($last_error, 'Restart Codex') !== false);
        $should_invalidate_ready = $connection_status === 'ready' && (!$synced || !$hash_matches);

        if ($smoke_passed) {
            $status = 'ready';
            $primary_action = 'none';
            $message = __('Codex is connected and the smoke test passed.', 'livecanvas-forge-ai');
        } elseif (!$synced || !$hash_matches || !$script_ok || !$wp_root_ok) {
            $status = trim((string) ($connections['preferred_client'] ?? '')) === '' && (string) ($inspection['status'] ?? '') === 'missing'
                ? 'needs_setup'
                : 'stale';
            $primary_action = 'sync_codex';
            $message = !$synced
                ? (string) ($inspection['message'] ?? __('Codex config is stale. Sync the Codex MCP config.', 'livecanvas-forge-ai'))
                : (!$hash_matches ? __('Codex config changed since the last smoke test. Repair Codex and rerun the smoke test.', 'livecanvas-forge-ai') : __('Codex local prerequisites need attention before testing.', 'livecanvas-forge-ai'));
        } elseif ($connection_status === 'needs_attention') {
            $status = 'test_failed';
            $primary_action = 'run_smoke';
            $message = $last_error !== '' ? $last_error : __('The last Codex smoke test failed.', 'livecanvas-forge-ai');
        } elseif ($restart_required) {
            $status = 'restart_required';
            $primary_action = 'run_smoke';
            $message = __('Restart Codex or reload the MCP server before testing.', 'livecanvas-forge-ai');
        } else {
            $status = 'restart_required';
            $primary_action = 'run_smoke';
            $message = __('Restart Codex or reload the MCP server before testing.', 'livecanvas-forge-ai');
        }

        $checks = [
            'codex_config_scope' => [
                'label' => __('Codex scope', 'livecanvas-forge-ai'),
                'ok' => $config_scope === 'project',
                'message' => $config_scope === 'project'
                    ? __('Project-scoped config keeps this Codex project tied to this WordPress site.', 'livecanvas-forge-ai')
                    : __('Global config is advanced and can be shared across Codex projects.', 'livecanvas-forge-ai'),
            ],
            'wp_root_ok' => [
                'label' => __('WordPress root', 'livecanvas-forge-ai'),
                'ok' => $wp_root_ok,
                'message' => $wp_root_ok ? __('Current local site path detected.', 'livecanvas-forge-ai') : __('Current WordPress root is missing or stale.', 'livecanvas-forge-ai'),
            ],
            'mcp_script_ok' => [
                'label' => __('MCP script', 'livecanvas-forge-ai'),
                'ok' => $script_ok,
                'message' => $script_ok ? __('Readable.', 'livecanvas-forge-ai') : __('Missing or not readable.', 'livecanvas-forge-ai'),
            ],
            'codex_config_synced' => [
                'label' => __('Codex config', 'livecanvas-forge-ai'),
                'ok' => $synced,
                'message' => $synced ? __('Synced.', 'livecanvas-forge-ai') : __('Missing or stale.', 'livecanvas-forge-ai'),
            ],
            'hash_matches' => [
                'label' => __('Fingerprint', 'livecanvas-forge-ai'),
                'ok' => $hash_matches,
                'message' => $hash_matches ? __('Matches current token and paths.', 'livecanvas-forge-ai') : __('Needs a fresh sync and smoke test.', 'livecanvas-forge-ai'),
            ],
            'restart_required' => [
                'label' => __('Restart/reload', 'livecanvas-forge-ai'),
                'ok' => $restart_required,
                'message' => $restart_required ? __('Required before smoke test.', 'livecanvas-forge-ai') : __('Not required right now.', 'livecanvas-forge-ai'),
            ],
            'smoke_passed' => [
                'label' => __('Smoke test', 'livecanvas-forge-ai'),
                'ok' => $smoke_passed,
                'message' => $smoke_passed ? __('Passed.', 'livecanvas-forge-ai') : __('Pending.', 'livecanvas-forge-ai'),
            ],
        ];

        return [
            'mode' => 'local',
            'status' => $status,
            'primary_action' => $primary_action,
            'checks' => $checks,
            'message' => $message,
            'config_scope' => $config_scope,
            'config_path' => $config_path,
            'site_fingerprint' => $site_fingerprint,
            'manual_fallback' => [
                'remove_command' => (string) ($expected['remove_command'] ?? ''),
                'add_command' => (string) ($expected['add_command'] ?? ''),
                'snippet' => (string) ($expected['snippet'] ?? ''),
                'config_scope' => $config_scope,
                'config_path' => $config_path,
                'global_config_path' => (string) ($expected['global_config_path'] ?? ''),
                'site_fingerprint' => $site_fingerprint,
            ],
            'last_smoke' => [
                'verified_at' => $last_verified,
                'error' => $last_error,
            ],
            'should_invalidate_ready' => $should_invalidate_ready,
        ];
    }

    private function get_remote_codex_prerequisites(array $connections, array $remote_status): array {
        return $this->get_direct_agent_onboarding()->get_remote_codex_prerequisites($connections, $remote_status);
    }

    private function render_codex_fast_path_panel(array $state, array $bundle, array $connections, string $selected_mode, array $workspace_write_state): void {
        $mode = $this->normalize_connection_mode((string) ($state['connection_mode'] ?? ($bundle['mode'] ?? $selected_mode)));
        $state_mode = sanitize_key((string) ($state['mode'] ?? $mode));
        $status = sanitize_key((string) ($state['status'] ?? 'needs_setup'));
        $primary_action = sanitize_key((string) ($state['primary_action'] ?? 'sync_codex'));
        $status_labels = [
            'needs_setup' => __('Needs setup', 'livecanvas-forge-ai'),
            'missing_credentials' => __('Missing target', 'livecanvas-forge-ai'),
            'stale' => __('Config stale', 'livecanvas-forge-ai'),
            'restart_required' => __('Restart required', 'livecanvas-forge-ai'),
            'test_failed' => __('Test failed', 'livecanvas-forge-ai'),
            'ready' => __('Ready', 'livecanvas-forge-ai'),
        ];
        $status_label = (string) ($status_labels[$status] ?? $status_labels['needs_setup']);
        $checks = is_array($state['checks'] ?? null) ? $state['checks'] : [];
        $last_smoke = is_array($state['last_smoke'] ?? null) ? $state['last_smoke'] : [];
        $pending_pairings = [];
        if ($mode === 'remote' && class_exists('LCFA_MCP_Session_Manager', false)) {
            $pending_pairings = LCFA_MCP_Session_Manager::get_pending_pairings();
        }
        $pairing_review_required = $pending_pairings !== [] && $status !== 'ready';
        $state['pairing_pending'] = $pairing_review_required;

        echo '<section class="lcfa-card lcfa-ready-card lcfa-codex-fast-path">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('command');
        echo '<div><h2>' . esc_html__('Connect Codex', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Follow the highlighted step. Technical checks and manual commands stay collapsed unless you need them.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        if ($status !== 'ready') {
            echo '<p class="lcfa-inline-doc-link"><a class="button button-small" href="' . esc_url(LCFA_URL . 'docs/coding-agent-setup.html#codex') . '" target="_blank" rel="noreferrer noopener">' . esc_html__('Open the 4-step connection guide', 'livecanvas-forge-ai') . '</a></p>';
        }

        $this->render_codex_mode_switch($mode, (string) ($bundle['workspace_root'] ?? ''));

        echo '<div class="lcfa-chip-row">';
        echo '<span class="lcfa-chip lcfa-chip--agent">' . $this->get_agent_icon_markup('codex', 'stars') . '<span>' . esc_html__('Codex', 'livecanvas-forge-ai') . '</span></span>';
        echo '<span class="lcfa-chip' . ($status === 'ready' ? ' is-positive' : (in_array($status, ['test_failed', 'missing_credentials'], true) ? ' is-negative' : '')) . '">' . esc_html($status_label) . '</span>';
        $mode_label = $state_mode === 'direct' || $mode === 'remote' ? __('Direct Mode', 'livecanvas-forge-ai') : __('Local runtime', 'livecanvas-forge-ai');
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Mode: %s', 'livecanvas-forge-ai'), $mode_label)) . '</span>';
        if ($mode === 'local') {
            $config_scope = sanitize_key((string) ($state['config_scope'] ?? 'project'));
            $config_scope_label = $config_scope === 'global' ? __('Global config', 'livecanvas-forge-ai') : __('Project config', 'livecanvas-forge-ai');
            echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Codex scope: %s', 'livecanvas-forge-ai'), $config_scope_label)) . '</span>';
            if (!empty($state['site_fingerprint'])) {
                echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Site ID: %s', 'livecanvas-forge-ai'), (string) $state['site_fingerprint'])) . '</span>';
            }
        }
        echo '</div>';

        $this->render_codex_next_step_alert($status, $mode, $state);

        if ($mode === 'remote') {
            $manual_fallback = is_array($state['manual_fallback'] ?? null) ? $state['manual_fallback'] : [];
            $prerequisites = is_array($manual_fallback['prerequisites'] ?? null) ? $manual_fallback['prerequisites'] : [];
            $oauth_status = is_array($prerequisites['oauth_status'] ?? null) ? $prerequisites['oauth_status'] : [];
            if (
                !empty($oauth_status['oauth_runtime_ready'])
                && empty($oauth_status['mcp_adapter_available'])
            ) {
                echo '<div class="lcfa-connection-now-alert lcfa-connection-now-alert--needs_setup">';
                echo '<span class="lcfa-connection-now-alert__eyebrow">' . esc_html__('Recommended prerequisite', 'livecanvas-forge-ai') . '</span>';
                echo '<strong>' . esc_html__('Enable the official WordPress MCP Adapter', 'livecanvas-forge-ai') . '</strong>';
                echo '<p>' . esc_html__('Direct OAuth uses the native WordPress MCP HTTP endpoint. Until the adapter is active, AI Bridge will keep using secure pairing fallback.', 'livecanvas-forge-ai') . '</p>';
                if (current_user_can('install_plugins')) {
                    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
                    wp_nonce_field('lcfa_install_mcp_adapter');
                    echo '<input type="hidden" name="action" value="lcfa_install_mcp_adapter">';
                    echo '<button class="button button-primary" type="submit">' . esc_html__('Install MCP Adapter', 'livecanvas-forge-ai') . '</button>';
                    echo '</form>';
                } else {
                    echo '<p>' . esc_html__('Ask a site administrator with plugin installation permission to install WordPress MCP Adapter.', 'livecanvas-forge-ai') . '</p>';
                }
                echo '</div>';
            }
            if (empty($prerequisites['ready'])) {
                $this->render_codex_direct_credentials_form($connections);
                $this->render_remote_codex_prerequisites($prerequisites);
            }
        }

        $this->render_codex_technical_checks($checks);
        if ($mode === 'remote') {
            $this->render_connection_diagnostics_panel();
        }

        echo '<div class="lcfa-cta-row">';
        if ($pairing_review_required) {
            echo '<a class="button button-primary lcfa-button--wide" href="#lcfa-secure-codex-pairing-sessions">' . esc_html__('Review pending Codex pairing', 'livecanvas-forge-ai') . '</a>';
        } elseif ($status === 'ready') {
            $this->render_codex_fast_path_smoke_form($mode, __('Re-test', 'livecanvas-forge-ai'));
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
            wp_nonce_field('lcfa_reconfigure_connection');
            echo '<input type="hidden" name="action" value="lcfa_reconfigure_connection">';
            echo '<button class="button" type="submit">' . esc_html__('Change client', 'livecanvas-forge-ai') . '</button>';
            echo '</form>';
        } elseif ($primary_action === 'run_smoke') {
            $session_active = !empty($checks['session_active']['ok']);
            if ($mode === 'remote' && $status === 'restart_required' && !$session_active) {
                echo '<a class="button button-primary lcfa-button--wide" href="#lcfa-codex-setup-command">' . esc_html__('Open Codex setup prompt', 'livecanvas-forge-ai') . '</a>';
            } else {
                $this->render_codex_fast_path_smoke_form($mode, __('Run Codex smoke test', 'livecanvas-forge-ai'));
            }
        } elseif ($primary_action === 'sync_codex' || $primary_action === 'connect' || $primary_action === 'repair') {
            $button_label = $status === 'stale'
                ? __('Repair Codex', 'livecanvas-forge-ai')
                : ($mode === 'remote' ? __('Connect Codex securely', 'livecanvas-forge-ai') : __('Connect Codex', 'livecanvas-forge-ai'));
            $this->render_codex_fast_path_action_form('connect_codex', $mode, $button_label, true);
        } else {
            echo '<a class="button" href="#lcfa-connections-secondary">' . esc_html__('Open settings', 'livecanvas-forge-ai') . '</a>';
        }
        echo '</div>';

        if (!$pairing_review_required && (!empty($last_smoke['verified_at']) || !empty($last_smoke['error']))) {
            echo '<div class="lcfa-workspace-note">';
            $last_smoke_label = !empty($last_smoke['verified_at'])
                ? __('Last smoke test', 'livecanvas-forge-ai')
                : __('Connection note', 'livecanvas-forge-ai');
            echo '<strong>' . esc_html($last_smoke_label) . '</strong>';
            if (!empty($last_smoke['verified_at'])) {
                echo '<p>' . esc_html(sprintf(__('Verified at: %s', 'livecanvas-forge-ai'), (string) $last_smoke['verified_at'])) . '</p>';
            }
            if (!empty($last_smoke['error'])) {
                echo '<p>' . esc_html((string) $last_smoke['error']) . '</p>';
            }
            echo '</div>';
        }

        if ($mode === 'remote' && $pairing_review_required) {
            $this->render_codex_mcp_sessions_panel((string) ($state['strategy'] ?? ''));
        }

        if ($status !== 'missing_credentials') {
            $this->render_codex_manual_fallback(
                $mode,
                is_array($state['manual_fallback'] ?? null) ? $state['manual_fallback'] : [],
                $bundle,
                $status,
                $pairing_review_required
            );
        }

        if ($mode === 'remote' && !$pairing_review_required) {
            $this->render_codex_mcp_sessions_panel((string) ($state['strategy'] ?? ''));
        }

        if ($mode === 'local' && !empty($bundle['workspace_files']) && empty($workspace_write_state['available'])) {
            echo '<div class="lcfa-workspace-note">';
            echo '<strong>' . esc_html__('Workspace write fallback available', 'livecanvas-forge-ai') . '</strong>';
            echo '<p>' . esc_html($this->get_workspace_write_notice($workspace_write_state)) . '</p>';
            echo '</div>';
        }

        echo '</section>';
    }

    private function render_connection_diagnostics_panel(): void {
        if (!$this->connection_diagnostics instanceof LCFA_Connection_Diagnostics) {
            return;
        }

        $result = $this->connection_diagnostics->get_last_result();
        $checks = is_array($result['checks'] ?? null) ? $result['checks'] : [];
        $open = $result !== [] && empty($result['ok']);

        echo '<details id="lcfa-connection-diagnostics" class="lcfa-technical-details lcfa-connection-diagnostics"' . ($open ? ' open' : '') . '>';
        echo '<summary>' . esc_html__('Connection diagnostics', 'livecanvas-forge-ai') . '</summary>';
        echo '<div class="lcfa-technical-details__body">';
        echo '<p>' . esc_html__('Run this check when OAuth discovery, Codex login, or the MCP endpoint is slow or unavailable. It does not modify WordPress content.', 'livecanvas-forge-ai') . '</p>';

        if ($result !== []) {
            echo '<div class="lcfa-workspace-note">';
            echo '<strong>' . esc_html((string) ($result['summary'] ?? __('Diagnostics completed.', 'livecanvas-forge-ai'))) . '</strong>';
            if (!empty($result['checked_at'])) {
                echo '<p>' . esc_html(sprintf(__('Checked at: %s', 'livecanvas-forge-ai'), (string) $result['checked_at'])) . '</p>';
            }
            echo '</div>';
            echo '<div class="lcfa-check-grid">';
            foreach ($checks as $check) {
                if (!is_array($check)) {
                    continue;
                }
                $ok = !empty($check['ok']);
                $severity = sanitize_key((string) ($check['severity'] ?? 'warn'));
                $class = $ok ? ' is-positive' : ($severity === 'error' ? ' is-negative' : '');
                echo '<div class="lcfa-check-item">';
                echo '<span class="lcfa-chip' . esc_attr($class) . '">' . esc_html((string) ($check['label'] ?? __('Check', 'livecanvas-forge-ai'))) . ': ' . esc_html($ok ? __('OK', 'livecanvas-forge-ai') : __('Review', 'livecanvas-forge-ai')) . '</span>';
                if (!empty($check['message'])) {
                    echo '<p>' . esc_html((string) $check['message']) . '</p>';
                }
                echo '</div>';
            }
            echo '</div>';
        }

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
        wp_nonce_field('lcfa_run_connection_diagnostics');
        echo '<input type="hidden" name="action" value="lcfa_run_connection_diagnostics">';
        echo '<button class="button" type="submit">' . esc_html__('Run connection diagnostics', 'livecanvas-forge-ai') . '</button>';
        echo '</form>';
        echo '</div>';
        echo '</details>';
    }

    private function render_codex_mcp_sessions_panel(string $strategy = ''): void {
        if ($strategy === 'oauth-direct' && class_exists('LCFA_OAuth_Server', false)) {
            $apps = (new LCFA_OAuth_Server())->get_connected_apps();
            echo '<div id="lcfa-codex-connected-apps" class="lcfa-workspace-note lcfa-mcp-session-panel">';
            echo '<strong>' . esc_html__('Connected Codex apps', 'livecanvas-forge-ai') . '</strong>';
            echo '<p>' . esc_html__('OAuth grants are limited to this site and can be revoked without changing any WordPress password.', 'livecanvas-forge-ai') . '</p>';
            if ($apps === []) {
                echo '<p>' . esc_html__('No Codex OAuth grant is active yet. Run the generated login command and approve the WordPress authorization screen.', 'livecanvas-forge-ai') . '</p>';
            } else {
                echo '<div class="lcfa-stack-list">';
                foreach ($apps as $app) {
                    $revoked = !empty($app['revoked_at']);
                    $active_tokens = (int) ($app['active_tokens'] ?? 0);
                    echo '<div class="lcfa-stack-item">';
                    echo '<div>';
                    echo '<strong>' . esc_html((string) ($app['client_name'] ?? __('Codex', 'livecanvas-forge-ai'))) . '</strong>';
                    echo '<p>' . esc_html(sprintf(
                        __('Client: %1$s · Active grants: %2$d · Last seen: %3$s', 'livecanvas-forge-ai'),
                        (string) ($app['client_id'] ?? ''),
                        $active_tokens,
                        (string) (($app['token_last_seen_at'] ?? '') ?: (($app['last_used_at'] ?? '') ?: __('never', 'livecanvas-forge-ai')))
                    )) . '</p>';
                    echo '<p>' . esc_html($revoked ? __('Status: revoked', 'livecanvas-forge-ai') : ($active_tokens > 0 ? __('Status: active', 'livecanvas-forge-ai') : __('Status: registered, authorization pending', 'livecanvas-forge-ai'))) . '</p>';
                    echo '</div>';
                    if (!$revoked) {
                        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
                        wp_nonce_field('lcfa_oauth_revoke_client');
                        echo '<input type="hidden" name="action" value="lcfa_oauth_revoke_client">';
                        echo '<input type="hidden" name="client_id" value="' . esc_attr((string) ($app['client_id'] ?? '')) . '">';
                        echo '<button class="button" type="submit">' . esc_html__('Revoke OAuth grant', 'livecanvas-forge-ai') . '</button>';
                        echo '</form>';
                    }
                    echo '</div>';
                }
                echo '</div>';
            }
            echo '</div>';
        }

        if (!class_exists('LCFA_MCP_Session_Manager', false)) {
            return;
        }

        $pending = LCFA_MCP_Session_Manager::get_pending_pairings();
        $sessions = LCFA_MCP_Session_Manager::get_public_sessions();
        $client_labels = [
            'codex'    => __('Codex', 'livecanvas-forge-ai'),
            'opencode' => __('OpenCode', 'livecanvas-forge-ai'),
            'claude'   => __('Claude', 'livecanvas-forge-ai'),
            'cursor'   => __('Cursor', 'livecanvas-forge-ai'),
            'generic'  => __('Coding agent', 'livecanvas-forge-ai'),
        ];

        echo '<div id="lcfa-secure-codex-pairing-sessions" class="lcfa-workspace-note lcfa-mcp-session-panel">';
        echo '<strong>' . esc_html($strategy === 'oauth-direct' ? __('Secure pairing fallback', 'livecanvas-forge-ai') : __('Secure coding-agent pairing sessions', 'livecanvas-forge-ai')) . '</strong>';
        echo '<p>' . esc_html__('Approve only the coding-agent project you are using now. Revoked or expired sessions cannot access this site.', 'livecanvas-forge-ai') . '</p>';

        if ($pending !== []) {
            echo '<h3>' . esc_html__('Pending approval', 'livecanvas-forge-ai') . '</h3>';
            echo '<div class="lcfa-stack-list">';
            foreach ($pending as $pairing) {
                $client_key = $this->normalize_connection_client((string) ($pairing['client'] ?? 'codex'));
                $client_label = (string) ($client_labels[$client_key] ?? $client_labels['generic']);
                echo '<div class="lcfa-stack-item">';
                echo '<div>';
                echo '<strong>' . esc_html((string) ($pairing['project_label'] ?? __('Coding-agent project', 'livecanvas-forge-ai'))) . '</strong>';
                echo '<p>' . esc_html(sprintf(__('Code: %1$s · Client: %2$s · Expires: %3$s', 'livecanvas-forge-ai'), (string) ($pairing['user_code'] ?? ''), $client_label, (string) ($pairing['expires_at'] ?? ''))) . '</p>';
                echo '</div>';
                echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
                wp_nonce_field('lcfa_mcp_pairing_approve');
                echo '<input type="hidden" name="action" value="lcfa_mcp_pairing_approve">';
                echo '<input type="hidden" name="pairing_id" value="' . esc_attr((string) ($pairing['pairing_id'] ?? '')) . '">';
                echo '<button class="button button-primary" type="submit">' . esc_html(sprintf(__('Approve %s', 'livecanvas-forge-ai'), $client_label)) . '</button>';
                echo '</form>';
                echo '</div>';
            }
            echo '</div>';
        } else {
            echo '<p>' . esc_html__('No pending pairing requests. Ask the coding agent to call get_connection_handoff after installing its project configuration.', 'livecanvas-forge-ai') . '</p>';
        }

        if ($sessions !== []) {
            echo '<h3>' . esc_html__('Sessions', 'livecanvas-forge-ai') . '</h3>';
            echo '<div class="lcfa-stack-list">';
            foreach ($sessions as $session) {
                $revoked = !empty($session['revoked']);
                $expired = !empty($session['expired']);
                $client_key = $this->normalize_connection_client((string) ($session['client'] ?? 'codex'));
                $client_label = (string) ($client_labels[$client_key] ?? $client_labels['generic']);
                echo '<div class="lcfa-stack-item">';
                echo '<div>';
                echo '<strong>' . esc_html((string) ($session['project_label'] ?? __('Coding-agent project', 'livecanvas-forge-ai'))) . '</strong>';
                echo '<p>' . esc_html(sprintf(__('Session: %1$s · Client: %2$s · Scopes: %3$s · Last seen: %4$s', 'livecanvas-forge-ai'), (string) ($session['session_id'] ?? ''), $client_label, implode(', ', (array) ($session['scopes'] ?? [])), (string) ($session['last_seen_at'] ?: __('never', 'livecanvas-forge-ai')))) . '</p>';
                echo '<p>' . esc_html(sprintf(__('Status: %1$s · Expires: %2$s', 'livecanvas-forge-ai'), $revoked ? __('revoked', 'livecanvas-forge-ai') : ($expired ? __('expired', 'livecanvas-forge-ai') : __('active', 'livecanvas-forge-ai')), (string) ($session['expires_at'] ?? ''))) . '</p>';
                echo '</div>';
                if (!$revoked && !$expired) {
                    echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
                    wp_nonce_field('lcfa_mcp_session_revoke');
                    echo '<input type="hidden" name="action" value="lcfa_mcp_session_revoke">';
                    echo '<input type="hidden" name="session_id" value="' . esc_attr((string) ($session['session_id'] ?? '')) . '">';
                    echo '<button class="button" type="submit">' . esc_html__('Revoke', 'livecanvas-forge-ai') . '</button>';
                    echo '</form>';
                }
                echo '</div>';
            }
            echo '</div>';
        }

        echo '</div>';
    }

    private function render_codex_next_step_alert(string $status, string $mode, array $state): void {
        $guidance = !empty($state['pairing_pending'])
            ? [
                'eyebrow' => __('Step 3', 'livecanvas-forge-ai'),
                'title' => __('Approve the matching Codex pairing', 'livecanvas-forge-ai'),
                'description' => __('Codex has reached this WordPress site. Finish the site-bound authorization before running the smoke test.', 'livecanvas-forge-ai'),
                'steps' => [
                    __('Compare the code shown by Codex with the pending request below.', 'livecanvas-forge-ai'),
                    __('Approve only the matching project, then ask Codex to retry get_connection_handoff.', 'livecanvas-forge-ai'),
                    __('Return here and run the smoke test.', 'livecanvas-forge-ai'),
                ],
            ]
            : $this->get_codex_next_step_guidance($status, $mode, (string) ($state['strategy'] ?? ''));
        $alert_class = 'lcfa-connection-now-alert lcfa-connection-now-alert--' . sanitize_html_class($status);

        echo '<div class="' . esc_attr($alert_class) . '">';
        echo '<span class="lcfa-connection-now-alert__eyebrow">' . esc_html((string) $guidance['eyebrow']) . '</span>';
        echo '<strong>' . esc_html((string) $guidance['title']) . '</strong>';
        if (!empty($guidance['description'])) {
            echo '<p>' . esc_html((string) $guidance['description']) . '</p>';
        }
        if (!empty($guidance['steps']) && is_array($guidance['steps'])) {
            echo '<ol class="lcfa-step-list">';
            foreach ($guidance['steps'] as $step) {
                echo '<li>' . esc_html((string) $step) . '</li>';
            }
            echo '</ol>';
        }
        if (!empty($state['message']) && !in_array($status, ['missing_credentials', 'restart_required', 'ready'], true)) {
            echo '<small>' . esc_html((string) $state['message']) . '</small>';
        }
        echo '</div>';
    }

    private function get_codex_next_step_guidance(string $status, string $mode, string $strategy = ''): array {
        if ($mode === 'remote') {
            $oauth_direct = $strategy === 'oauth-direct';
            switch ($status) {
                case 'missing_credentials':
                    return [
                        'eyebrow' => __('Step 1', 'livecanvas-forge-ai'),
                        'title' => __('Confirm the target site', 'livecanvas-forge-ai'),
                        'description' => $oauth_direct
                            ? __('Direct Mode connects Codex to this site through the WordPress MCP endpoint and a revocable OAuth grant.', 'livecanvas-forge-ai')
                            : __('Direct Mode only needs the WordPress site URL and a project label. Codex will pair through a scoped AI Bridge session.', 'livecanvas-forge-ai'),
                        'steps' => [
                            __('Confirm the site URL below.', 'livecanvas-forge-ai'),
                            __('Add a clear Codex project label so future sessions are recognizable.', 'livecanvas-forge-ai'),
                            __('Save the target site, then click Connect Codex securely.', 'livecanvas-forge-ai'),
                        ],
                    ];
                case 'restart_required':
                    return [
                        'eyebrow' => __('Step 3', 'livecanvas-forge-ai'),
                        'title' => $oauth_direct ? __('Reload Codex, authorize OAuth, then verify', 'livecanvas-forge-ai') : __('Reload Codex, approve pairing, then test', 'livecanvas-forge-ai'),
                        'description' => $oauth_direct
                            ? __('The project config points directly to this WordPress MCP endpoint. Complete the one-time browser authorization before the first tool call.', 'livecanvas-forge-ai')
                            : __('The secure Codex setup has been generated. Codex must reload the MCP server and request a pairing session before WordPress can mark it ready.', 'livecanvas-forge-ai'),
                        'steps' => $oauth_direct
                            ? [
                                __('Copy the setup prompt into the correct Codex project and let it update .codex/config.toml.', 'livecanvas-forge-ai'),
                                __('Restart Codex, run the generated MCP login command, and approve the WordPress OAuth screen.', 'livecanvas-forge-ai'),
                                __('Call get_connection_handoff, verify the site identity, then run the smoke test here.', 'livecanvas-forge-ai'),
                            ]
                            : [
                                __('Copy the setup prompt into the correct Codex project and let it update .codex/config.toml.', 'livecanvas-forge-ai'),
                                __('Restart Codex, then ask it to call get_connection_handoff.', 'livecanvas-forge-ai'),
                                __('Approve the pending project below, then run the smoke test here.', 'livecanvas-forge-ai'),
                            ],
                    ];
                case 'test_failed':
                    return [
                        'eyebrow' => __('Fix required', 'livecanvas-forge-ai'),
                        'title' => __('Smoke test failed', 'livecanvas-forge-ai'),
                        'description' => $oauth_direct
                            ? __('The MCP endpoint answered, but no valid OAuth grant completed the handoff. Re-run Codex MCP login and verify the authorization screen.', 'livecanvas-forge-ai')
                            : __('The site answered, but Codex could not complete the secure MCP handshake. Re-check the setup prompt and pairing session, then test again.', 'livecanvas-forge-ai'),
                        'steps' => [
                            __('Confirm Codex has the LiveCanvas MCP server registered for this project.', 'livecanvas-forge-ai'),
                            $oauth_direct
                                ? __('Run Codex MCP login and approve the OAuth request in WordPress.', 'livecanvas-forge-ai')
                                : __('Ask Codex to call get_connection_handoff and approve any pending pairing request.', 'livecanvas-forge-ai'),
                            __('Run the smoke test again.', 'livecanvas-forge-ai'),
                        ],
                    ];
                case 'ready':
                    return [
                        'eyebrow' => __('Ready', 'livecanvas-forge-ai'),
                        'title' => __('Codex is connected', 'livecanvas-forge-ai'),
                        'description' => __('You can now test the integration from Codex or from the LiveCanvas frontend drawer.', 'livecanvas-forge-ai'),
                        'steps' => [
                            __('In Codex, call get_connection_handoff.', 'livecanvas-forge-ai'),
                            __('Ask for a read-only audit first.', 'livecanvas-forge-ai'),
                            $oauth_direct
                                ? __('For visual QA, use Codex browser tooling; Direct OAuth does not include the local visual_check runtime.', 'livecanvas-forge-ai')
                                : __('Before visual QA, inspect mcp_runtime.visual_check and run visual_check_status if launch is not verified.', 'livecanvas-forge-ai'),
                            __('Enable apply abilities only when you want Codex to write pages or templates.', 'livecanvas-forge-ai'),
                        ],
                    ];
                default:
                    return [
                        'eyebrow' => __('Step 2', 'livecanvas-forge-ai'),
                        'title' => __('Generate the secure Codex setup', 'livecanvas-forge-ai'),
                        'description' => $oauth_direct
                            ? __('The site supports Direct OAuth. Generate the project-scoped MCP URL configuration for Codex.', 'livecanvas-forge-ai')
                            : __('The target site is ready. Now generate the AI Bridge MCP setup for Codex.', 'livecanvas-forge-ai'),
                        'steps' => [
                            __('Click Connect Codex securely.', 'livecanvas-forge-ai'),
                            __('Copy the generated prompt into the correct Codex project.', 'livecanvas-forge-ai'),
                            $oauth_direct
                                ? __('Restart Codex and complete the one-time WordPress authorization.', 'livecanvas-forge-ai')
                                : __('Restart Codex, request the handoff, and approve the project here.', 'livecanvas-forge-ai'),
                        ],
                    ];
            }
        }

        switch ($status) {
            case 'restart_required':
                return [
                    'eyebrow' => __('Step 2', 'livecanvas-forge-ai'),
                    'title' => __('Local runtime needs a Codex reload', 'livecanvas-forge-ai'),
                    'description' => __('This is the advanced local runtime path. If you wanted the easier setup, select Direct Mode above and click Use selected mode.', 'livecanvas-forge-ai'),
                    'steps' => [
                        __('Continue local runtime only if Codex must access this machine files or local build tools.', 'livecanvas-forge-ai'),
                        __('AI Bridge now writes a project-scoped .codex/config.toml inside this WordPress folder by default.', 'livecanvas-forge-ai'),
                        __('Restart Codex or reload the livecanvas-forge MCP server.', 'livecanvas-forge-ai'),
                        __('Return here and run the Codex smoke test.', 'livecanvas-forge-ai'),
                    ],
                ];
            case 'test_failed':
                return [
                    'eyebrow' => __('Fix required', 'livecanvas-forge-ai'),
                    'title' => __('Local smoke test failed', 'livecanvas-forge-ai'),
                    'description' => __('Review the last smoke test message, then repair the local Codex config and test again.', 'livecanvas-forge-ai'),
                    'steps' => [
                        __('Click Repair Codex if the config, token, or site path changed.', 'livecanvas-forge-ai'),
                        __('Restart Codex or reload the MCP server.', 'livecanvas-forge-ai'),
                        __('Run the smoke test again.', 'livecanvas-forge-ai'),
                    ],
                ];
            case 'ready':
                return [
                    'eyebrow' => __('Ready', 'livecanvas-forge-ai'),
                    'title' => __('Codex is connected', 'livecanvas-forge-ai'),
                    'description' => __('The local MCP bridge passed the smoke test.', 'livecanvas-forge-ai'),
                    'steps' => [
                        __('In Codex, call get_connection_handoff.', 'livecanvas-forge-ai'),
                        __('Start with a read-only request before enabling writes.', 'livecanvas-forge-ai'),
                        __('Before visual QA, inspect mcp_runtime.visual_check and call visual_check_status with probe_launch=true.', 'livecanvas-forge-ai'),
                    ],
                ];
            default:
                return [
                    'eyebrow' => __('Advanced path', 'livecanvas-forge-ai'),
                    'title' => __('Local runtime is selected', 'livecanvas-forge-ai'),
                    'description' => __('For plug-and-play setup, select Direct Mode above and click Use selected mode. Local runtime is only for filesystem access, LocalWP path detection, or local build tools.', 'livecanvas-forge-ai'),
                    'steps' => [
                        __('Recommended: switch to Direct Mode and use the WordPress URL plus secure pairing approval.', 'livecanvas-forge-ai'),
                        __('Advanced only: click Connect Codex or Repair Codex to write this project .codex/config.toml.', 'livecanvas-forge-ai'),
                        __('If you continue local runtime, restart Codex before testing.', 'livecanvas-forge-ai'),
                    ],
                ];
        }
    }

    private function render_codex_direct_credentials_form(array $connections): void {
        $site_url = trim((string) ($connections['remote_site_url'] ?? ''));
        if ($site_url === '' && function_exists('home_url')) {
            $site_url = home_url('/');
        }
        $project_label = trim((string) ($connections['remote_project_label'] ?? ''));
        if ($project_label === '' && $site_url !== '') {
            $project_label = (string) parse_url($site_url, PHP_URL_HOST);
        }

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form lcfa-direct-credentials">';
        wp_nonce_field('lcfa_connections');
        echo '<input type="hidden" name="action" value="lcfa_connections">';
        echo '<input type="hidden" name="preferred_client" value="codex">';
        echo '<input type="hidden" name="connection_mode" value="remote">';
        echo '<h3>' . esc_html__('Step 1: Target site', 'livecanvas-forge-ai') . '</h3>';
        echo '<p>' . esc_html__('Secure Direct Mode pairs Codex with this plugin. No WordPress username or Application Password is copied into Codex.', 'livecanvas-forge-ai') . '</p>';
        echo '<label><span>' . esc_html__('Site URL', 'livecanvas-forge-ai') . '</span><input type="text" name="remote_site_url" value="' . esc_attr($site_url) . '" placeholder="https://example.com"></label>';
        echo '<label><span>' . esc_html__('Codex project label', 'livecanvas-forge-ai') . '</span><input type="text" name="remote_project_label" value="' . esc_attr($project_label) . '" placeholder="' . esc_attr__('Client site project', 'livecanvas-forge-ai') . '"></label>';
        echo '<div class="lcfa-cta-row">';
        echo '<button class="button button-primary" type="submit">' . esc_html__('Save target site', 'livecanvas-forge-ai') . '</button>';
        echo '</div>';
        echo '</form>';
    }

    private function render_codex_technical_checks(array $checks): void {
        if ($checks === []) {
            return;
        }

        echo '<details class="lcfa-advanced-settings lcfa-codex-technical-checks">';
        echo '<summary>' . esc_html__('Technical checks', 'livecanvas-forge-ai') . '</summary>';
        echo '<div class="lcfa-chip-row">';
        foreach ($checks as $check_key => $check) {
            if (!is_array($check)) {
                continue;
            }
            $ok = !empty($check['ok']);
            $skipped = !empty($check['skipped']);
            $chip_class = $ok && !$skipped ? ' is-positive' : (!$ok && !$skipped ? ' is-negative' : '');
            $check_value = $ok ? __('OK', 'livecanvas-forge-ai') : __('Pending', 'livecanvas-forge-ai');
            if ($skipped) {
                $check_value = __('N/A', 'livecanvas-forge-ai');
            } elseif ($check_key === 'restart_required') {
                $chip_class = $ok ? ' is-negative' : ' is-positive';
                $check_value = $ok ? __('Required', 'livecanvas-forge-ai') : __('No', 'livecanvas-forge-ai');
            }
            echo '<span class="lcfa-chip' . esc_attr($chip_class) . '" title="' . esc_attr((string) ($check['message'] ?? '')) . '">' . esc_html((string) ($check['label'] ?? $check_key)) . ': ' . esc_html($check_value) . '</span>';
        }
        echo '</div>';
        echo '</details>';
    }

    private function render_codex_mode_switch(string $selected_mode, string $workspace_root): void {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form lcfa-wizard lcfa-codex-mode-switch" data-lcfa-mode-switch data-lcfa-current-mode="' . esc_attr($selected_mode) . '">';
        wp_nonce_field('lcfa_connections');
        echo '<input type="hidden" name="action" value="lcfa_connections">';
        echo '<input type="hidden" name="connection_current_step" value="choose_mode">';
        echo '<input type="hidden" name="preferred_client" value="codex">';
        echo '<input type="hidden" name="workspace_root" value="' . esc_attr($workspace_root) . '">';
        echo '<p class="lcfa-guide-copy">' . esc_html__('Recommended: use Direct Mode for both local and remote WordPress sites. Public HTTPS sites use WordPress MCP OAuth; other environments fall back to secure AI Bridge pairing. Neither path copies WordPress credentials into Codex.', 'livecanvas-forge-ai') . '</p>';
        echo '<div class="lcfa-radio-group lcfa-radio-group--inline">';
        $this->render_radio('connection_mode', 'remote', __('Direct Mode (recommended)', 'livecanvas-forge-ai'), $selected_mode, 'cloud', __('Best first setup: project-scoped MCP URL and one-time authorization.', 'livecanvas-forge-ai'));
        $this->render_radio('connection_mode', 'local', __('Local runtime (advanced)', 'livecanvas-forge-ai'), $selected_mode, 'command', __('Use only when Codex must access local files or compile local build assets.', 'livecanvas-forge-ai'));
        echo '</div>';
        echo '<div class="lcfa-cta-row">';
        echo '<button class="button lcfa-mode-switch-submit" type="submit" disabled data-lcfa-mode-switch-submit data-lcfa-idle-label="' . esc_attr__('Current mode selected', 'livecanvas-forge-ai') . '" data-lcfa-active-label="' . esc_attr__('Use selected mode', 'livecanvas-forge-ai') . '">' . esc_html__('Current mode selected', 'livecanvas-forge-ai') . '</button>';
        echo '</div>';
        echo '</form>';
    }

    private function render_remote_codex_prerequisites(array $prerequisites): void {
        $items = is_array($prerequisites['items'] ?? null) ? $prerequisites['items'] : [];
        echo '<div class="lcfa-connection-now-alert">';
        echo '<span class="lcfa-connection-now-alert__eyebrow">' . esc_html__('Remote Codex prerequisites', 'livecanvas-forge-ai') . '</span>';
        echo '<strong>' . esc_html__('Complete these fields before AI Bridge generates a secure remote Codex config.', 'livecanvas-forge-ai') . '</strong>';
        echo '<ul class="lcfa-plain-list">';
        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }
            echo '<li>' . esc_html((!empty($item['ok']) ? 'OK: ' : 'Missing: ') . (string) ($item['label'] ?? '')) . '</li>';
        }
        echo '</ul>';
        if ((string) ($prerequisites['strategy'] ?? '') === 'oauth-direct') {
            echo '<p>' . esc_html__('Direct OAuth stores only the site MCP URL in the Codex project. Authorization is completed in WordPress and can be revoked at any time.', 'livecanvas-forge-ai') . '</p>';
        } else {
            echo '<p>' . esc_html__('Secure pairing fallback uses @livecanvas/ai-bridge-mcp with site identity only. It does not use LCFA_WP_ROOT and never copies WP_API_PASSWORD into Codex.', 'livecanvas-forge-ai') . '</p>';
        }
        echo '</div>';
    }

    private function render_codex_fast_path_action_form(string $action, string $mode, string $button_label, bool $primary = false): void {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
        wp_nonce_field('lcfa_repair_codex_connection');
        echo '<input type="hidden" name="action" value="lcfa_repair_codex_connection">';
        echo '<input type="hidden" name="codex_repair_action" value="' . esc_attr($action) . '">';
        echo '<input type="hidden" name="connection_mode" value="' . esc_attr($mode) . '">';
        echo '<button class="button ' . ($primary ? 'button-primary ' : '') . 'lcfa-button--wide" type="submit">' . esc_html($button_label) . '</button>';
        echo '</form>';
    }

    private function render_codex_fast_path_smoke_form(string $mode, string $button_label): void {
        $this->render_codex_fast_path_action_form('smoke', $mode, $button_label, true);
    }

    private function render_codex_manual_fallback(string $mode, array $manual_fallback, array $bundle, string $status = '', bool $pairing_pending = false): void {
        $open = $mode === 'remote' && !$pairing_pending && in_array($status, ['needs_setup', 'restart_required'], true) ? ' open' : '';
        $summary = $mode === 'remote' ? __('Codex setup command', 'livecanvas-forge-ai') : __('Advanced/manual fallback', 'livecanvas-forge-ai');
        echo '<details id="lcfa-codex-setup-command" class="lcfa-advanced-settings lcfa-codex-setup-command"' . $open . '>';
        echo '<summary>' . esc_html($summary) . '</summary>';
        if ($mode === 'remote') {
            $oauth_direct = (string) ($bundle['connection_strategy'] ?? '') === 'oauth-direct';
            $shortcut = (string) ($manual_fallback['shortcut_command'] ?? ($bundle['copy_command_string'] ?? ''));
            $command = (string) ($manual_fallback['command'] ?? ($bundle['command_string'] ?? ''));
            $snippet = (string) ($manual_fallback['codex_config_snippet'] ?? ($bundle['codex_config_snippet'] ?? ''));
            $project_config_path = (string) ($manual_fallback['codex_project_config_path'] ?? ($bundle['codex_project_config_path'] ?? '.codex/config.toml'));
            $setup_prompt = $this->build_remote_codex_setup_prompt($snippet, $bundle, $manual_fallback);
            $test_prompt = $this->build_remote_codex_test_prompt($bundle, $manual_fallback);
            echo '<p class="lcfa-guide-copy">' . esc_html__('Copy the setup prompt into the Codex chat for this project. The test prompt is only needed after Codex reloads.', 'livecanvas-forge-ai') . '</p>';
            if ($setup_prompt !== '') {
                $this->render_code_block($setup_prompt, [
                    'language' => 'text',
                    'label' => __('Prompt for Codex', 'livecanvas-forge-ai'),
                    'copy_label' => __('Copy Codex setup prompt', 'livecanvas-forge-ai'),
                ]);
            }
            if ($test_prompt !== '') {
                $this->render_code_block($test_prompt, [
                    'language' => 'text',
                    'label' => __('Test prompt', 'livecanvas-forge-ai'),
                    'copy_label' => __('Copy test prompt', 'livecanvas-forge-ai'),
                ]);
            }
            echo '<details class="lcfa-advanced-settings">';
            echo '<summary>' . esc_html__('Advanced: raw config, global shortcut, and legacy password adapter', 'livecanvas-forge-ai') . '</summary>';
            echo '<p class="lcfa-guide-copy">' . esc_html__('Use these only if you prefer to edit Codex configuration manually. The config file belongs to your local Codex project, not to the remote WordPress server.', 'livecanvas-forge-ai') . '</p>';
            $this->render_code_block($project_config_path !== '' ? $project_config_path : '.codex/config.toml', [
                'language' => 'text',
                'label' => __('Local Codex project config', 'livecanvas-forge-ai'),
                'copy_label' => __('Copy config path', 'livecanvas-forge-ai'),
            ]);
            if ($snippet !== '') {
                $this->render_code_block($snippet, [
                    'language' => 'toml',
                    'label' => __('Project TOML', 'livecanvas-forge-ai'),
                    'copy_label' => __('Copy project TOML', 'livecanvas-forge-ai'),
                ]);
            }
            if ($shortcut !== '') {
                $this->render_code_block($shortcut, [
                    'language' => 'bash',
                    'label' => __('Advanced global shortcut', 'livecanvas-forge-ai'),
                    'copy_label' => __('Copy Codex remote shortcut', 'livecanvas-forge-ai'),
                ]);
            }
            if ($command !== '' && $command !== $shortcut) {
                $this->render_code_block($command, [
                    'language' => 'bash',
                    'label' => __('Command', 'livecanvas-forge-ai'),
                    'copy_label' => __('Copy command', 'livecanvas-forge-ai'),
                ]);
            }
            $legacy = $this->build_legacy_remote_codex_adapter_snippet();
            if ($legacy !== '') {
                echo '<div class="lcfa-connection-now-alert">';
                echo '<span class="lcfa-connection-now-alert__eyebrow">' . esc_html__('Legacy fallback', 'livecanvas-forge-ai') . '</span>';
                echo '<strong>' . esc_html__('Legacy mode stores a WordPress Application Password in Codex config. Use only when required.', 'livecanvas-forge-ai') . '</strong>';
                echo '</div>';
                $this->render_code_block($legacy, [
                    'language' => 'text',
                    'label' => __('Legacy Application Password adapter', 'livecanvas-forge-ai'),
                    'copy_label' => __('Copy legacy adapter template', 'livecanvas-forge-ai'),
                ]);
            }
            echo '</details>';
        } else {
            $config_path = (string) ($manual_fallback['config_path'] ?? '');
            $config_scope = sanitize_key((string) ($manual_fallback['config_scope'] ?? 'project'));
            echo '<p class="lcfa-guide-copy">' . esc_html($config_scope === 'global'
                ? __('Use this if PHP cannot write the global Codex config for this local machine.', 'livecanvas-forge-ai')
                : __('Use this if PHP cannot write the project Codex config inside this WordPress folder.', 'livecanvas-forge-ai')) . '</p>';
            if ($config_path !== '') {
                $this->render_code_block($config_path, [
                    'language' => 'text',
                    'label' => __('Config file', 'livecanvas-forge-ai'),
                    'copy_label' => __('Copy config path', 'livecanvas-forge-ai'),
                ]);
            }
            $snippet = (string) ($manual_fallback['snippet'] ?? '');
            if ($snippet !== '') {
                $this->render_code_block($snippet, [
                'language' => 'toml',
                'label' => __('TOML', 'livecanvas-forge-ai'),
                'copy_label' => __('Copy config snippet', 'livecanvas-forge-ai'),
                ]);
            }
            if ($config_scope === 'global') {
                $this->render_code_block((string) ($manual_fallback['remove_command'] ?? ''), [
                    'language' => 'bash',
                    'label' => __('Remove', 'livecanvas-forge-ai'),
                    'copy_label' => __('Copy remove command', 'livecanvas-forge-ai'),
                ]);
                $this->render_code_block((string) ($manual_fallback['add_command'] ?? ''), [
                    'language' => 'bash',
                    'label' => __('Add', 'livecanvas-forge-ai'),
                    'copy_label' => __('Copy add command', 'livecanvas-forge-ai'),
                ]);
            }
        }
        echo '</details>';
    }

    private function build_remote_codex_setup_prompt(string $toml, array $bundle, array $manual_fallback): string {
        $toml = trim($toml);
        if ($toml === '') {
            return '';
        }

        $site_url = $this->get_remote_codex_target_url($bundle, $manual_fallback);
        $target_line = $site_url !== ''
            ? 'Target WordPress site: ' . $site_url
            : 'Target WordPress site: the site configured in the TOML below';
        $oauth_direct = (string) ($bundle['connection_strategy'] ?? '') === 'oauth-direct';
        $server_name = trim((string) ($bundle['server_name'] ?? ($manual_fallback['server_name'] ?? 'livecanvas-ai-bridge')));

        if ($oauth_direct) {
            return implode("\n", [
                'Configure this Codex project for LiveCanvas AI Bridge Direct OAuth.',
                '',
                $target_line,
                'Expected site fingerprint: ' . (class_exists('LCFA_Settings', false) ? LCFA_Settings::get_site_fingerprint() : ''),
                '',
                'Create or update `.codex/config.toml` in the current Codex project.',
                'Codex loads this file only after the project is trusted. If Codex marks the project untrusted, stop and tell me to trust it before restarting.',
                'Preserve every unrelated Codex setting and MCP server.',
                'Replace only the `[mcp_servers.' . $server_name . ']` block with the TOML below.',
                'Remove obsolete project-level LiveCanvas MCP blocks only if they point to another WordPress URL or use the old local/pairing runtime. Preserve non-LiveCanvas servers.',
                'Do not add WordPress usernames, Application Passwords, bearer tokens, commands, or environment variables.',
                'Do not edit WordPress, themes, plugins, pages, posts, or remote files yet.',
                '',
                'After writing the file, stop and tell me to restart Codex.',
                'After restart, if Codex Settings still shows an old global `livecanvas-forge` server with the same tools, tell me to disable it before testing this project.',
                'After restart I will run `codex mcp login --scopes mcp ' . $server_name . '` once and approve the WordPress authorization screen.',
                'When I ask you to test, call `livecanvas-forge-ai/get-connection-handoff` with `{"limit":5}` and verify the site URL and fingerprint before doing anything else.',
                '',
                'TOML to write:',
                '',
                '```toml',
                $toml,
                '```',
            ]);
        }

        return implode("\n", [
            'Configure this Codex project for LiveCanvas AI Bridge.',
            '',
            $target_line,
            '',
                'Create or update `.codex/config.toml` in the current Codex project.',
                'Codex loads this file only after the project is trusted. If Codex marks the project untrusted, stop and tell me to trust it before restarting.',
                'Preserve any existing unrelated Codex configuration.',
                'Replace only the `[mcp_servers.livecanvas-ai-bridge]` block and its `.env` block with the TOML below.',
                'Remove obsolete project-level LiveCanvas MCP blocks only if they target another WordPress site. Preserve non-LiveCanvas servers.',
                'Do not edit WordPress, themes, plugins, pages, posts, or remote files yet.',
                '',
                'After writing the file, stop and tell me to restart Codex or reload the `livecanvas-ai-bridge` MCP server.',
                'After restart, if Codex Settings still shows an old global `livecanvas-forge` server with the same tools, tell me to disable it before testing this project.',
                'When I ask you to test the connection, call `get_connection_handoff`; if a pairing message is returned, I will approve it in WordPress.',
            '',
            'TOML to write:',
            '',
            '```toml',
            $toml,
            '```',
        ]);
    }

    private function build_remote_codex_test_prompt(array $bundle, array $manual_fallback): string {
        $tool = trim((string) ($manual_fallback['start_tool'] ?? ($bundle['agent_start_tool'] ?? 'livecanvas-forge-ai/get-connection-handoff')));
        if ($tool === '') {
            $tool = 'livecanvas-forge-ai/get-connection-handoff';
        }

        $site_url = $this->get_remote_codex_target_url($bundle, $manual_fallback);
        $verify_site = $site_url !== ''
            ? 'Verify that `site_identity.site_url` matches `' . $site_url . '` and that `site_identity.fingerprint` is present.'
            : 'Verify that `site_identity.site_url` and `site_identity.fingerprint` match the WordPress site I want to edit.';
        $oauth_direct = (string) ($bundle['connection_strategy'] ?? '') === 'oauth-direct';

        return implode("\n", [
            'Call `' . $tool . '` with `{"limit":5}`.',
            $verify_site,
            $oauth_direct
                ? 'If OAuth is not authenticated, stop and tell me to run the one-time Codex MCP login for this server.'
                : 'If the response says pairing is pending, tell me the user code and ask me to approve it in WordPress, then retry.',
            $oauth_direct
                ? 'This Direct OAuth transport exposes WordPress abilities only. For visual QA, use Codex browser tooling or switch to the advanced local MCP runtime.'
                : 'Read `mcp_runtime.visual_check`. If `launch_verified` is false, call `visual_check_status` with `{"probe_launch":true}` and report the exact next action.',
            'Summarize the connection status, transport, framework, guardrails, and available safe preview tools.',
            'Do not change anything.',
        ]);
    }

    private function build_legacy_remote_codex_adapter_snippet(): string {
        return implode("\n", [
            '# Legacy fallback only. Prefer secure AI Bridge pairing.',
            '# This stores a WordPress Application Password in Codex config.',
            '[mcp_servers.livecanvas-forge-legacy]',
            'command = "npx"',
            'args = ["-y", "@automattic/mcp-wordpress-remote@latest"]',
            '',
            '[mcp_servers.livecanvas-forge-legacy.env]',
            'WP_API_URL = "https://example.com/wp-json/livecanvas-forge-ai/mcp"',
            'WP_API_USERNAME = "wordpress-username"',
            'WP_API_PASSWORD = "xxxx xxxx xxxx xxxx xxxx xxxx"',
            'LOG_FILE = "/tmp/livecanvas-forge-codex-remote.log"',
        ]);
    }

    private function get_remote_codex_target_url(array $bundle, array $manual_fallback): string {
        $site_url = trim((string) ($bundle['remote_site_url'] ?? ($manual_fallback['remote_site_url'] ?? '')));
        if ($site_url !== '') {
            return rtrim($site_url, '/') . '/';
        }

        $environment = is_array($bundle['environment'] ?? null) ? $bundle['environment'] : [];
        foreach ($environment as $key => $value) {
            if (is_int($key)) {
                $parts = explode('=', (string) $value, 2);
                $env_key = trim((string) ($parts[0] ?? ''));
                $env_value = trim((string) ($parts[1] ?? ''));
            } else {
                $env_key = trim((string) $key);
                $env_value = trim((string) $value);
            }

            if (!in_array($env_key, ['LCFA_SITE_URL', 'WP_API_URL'], true) || $env_value === '') {
                continue;
            }

            $base = preg_replace('#/wp-json/.*$#', '/', $env_value);
            return is_string($base) && $base !== '' ? rtrim($base, '/') . '/' : '';
        }

        return '';
    }

    private function render_codex_other_clients_panel(array $connections, string $selected_mode): void {
        echo '<details class="lcfa-advanced-settings lcfa-connection-option">';
        echo '<summary>' . esc_html__('Other coding agents', 'livecanvas-forge-ai') . '</summary>';
        echo '<div class="lcfa-technical-details__body">';
        echo '<p>' . esc_html__('Switch from Codex to OpenCode, Claude, Cursor, or another MCP client.', 'livecanvas-forge-ai') . '</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form lcfa-wizard">';
        wp_nonce_field('lcfa_connections');
        echo '<input type="hidden" name="action" value="lcfa_connections">';
        echo '<input type="hidden" name="connection_current_step" value="choose_client">';
        echo '<input type="hidden" name="connection_mode" value="' . esc_attr($selected_mode) . '">';
        echo '<input type="hidden" name="workspace_root" value="' . esc_attr((string) ($connections['workspace_root'] ?? '')) . '">';
        echo '<div class="lcfa-radio-group lcfa-radio-group--agents">';
        $this->render_radio('preferred_client', 'opencode', __('OpenCode', 'livecanvas-forge-ai'), '', 'braces');
        $this->render_radio('preferred_client', 'claude', __('Claude', 'livecanvas-forge-ai'), '', 'cpu');
        $this->render_radio('preferred_client', 'cursor', __('Cursor', 'livecanvas-forge-ai'), '', 'cursor');
        $this->render_radio('preferred_client', 'generic', __('Generic MCP client', 'livecanvas-forge-ai'), '', 'plug');
        echo '</div>';
        echo '<div class="lcfa-cta-row">';
        echo '<button class="button" type="submit">' . esc_html__('Open client wizard', 'livecanvas-forge-ai') . '</button>';
        echo '</div>';
        echo '</form>';
        echo '</div>';
        echo '</details>';
    }

    private function render_power_mode_status_card(array $connections, array $snapshot): void {
        $power_state = $this->get_power_mode()->get_state($connections, $snapshot);
        $enabled = !empty($power_state['enabled']);

        echo '<details class="lcfa-advanced-settings lcfa-connection-option lcfa-power-mode-status">';
        echo '<summary>' . esc_html__('Power Mode and write access', 'livecanvas-forge-ai') . '</summary>';
        echo '<div class="lcfa-technical-details__body">';
        echo '<p><strong>' . esc_html__('Power Mode status', 'livecanvas-forge-ai') . '</strong></p>';
        echo '<p>' . esc_html__('Full Access unlocks content patching, theme files, media, debug, cache, SEO, Polylang, and visual checks for approved sessions.', 'livecanvas-forge-ai') . '</p>';
        echo '<div class="lcfa-chip-row">';
        echo '<span class="lcfa-chip' . ($enabled ? ' is-warning' : ' is-positive') . '">' . esc_html($enabled ? __('Policy: enabled', 'livecanvas-forge-ai') : __('Policy: disabled', 'livecanvas-forge-ai')) . '</span>';
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Setting: %s', 'livecanvas-forge-ai'), (string) ($power_state['setting'] ?? 'auto'))) . '</span>';
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Site: %s', 'livecanvas-forge-ai'), (string) ($power_state['site_mode'] ?? 'unknown'))) . '</span>';
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Environment: %s', 'livecanvas-forge-ai'), (string) ($power_state['environment_type'] ?? 'production'))) . '</span>';
        echo '</div>';
        echo '<p class="lcfa-guide-copy">' . esc_html((string) ($power_state['reason'] ?? '')) . '</p>';
        echo '<p class="description">' . esc_html__('For remote production sites, set Power Mode to Enabled by administrator, regenerate the Codex prompt, re-pair the session, and approve only trusted projects.', 'livecanvas-forge-ai') . '</p>';
        echo '</div>';
        echo '</details>';
    }

    private function render_connection_support_panel(array $connections, string $selected_mode, array $snapshot): void {
        echo '<section class="lcfa-card lcfa-connection-support">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('sliders');
        echo '<div><h2>' . esc_html__('More connection options', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Open these only when you need another coding agent or advanced write access.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';
        $this->render_codex_other_clients_panel($connections, $selected_mode);
        $this->render_power_mode_status_card($connections, $snapshot);
        echo '</section>';
    }

    private function get_codex_repair_state(array $connections, array $bundle): array {
        if ((string) ($bundle['client'] ?? '') !== 'codex' || (string) ($bundle['mode'] ?? '') !== 'local') {
            return ['enabled' => false];
        }

        if (!class_exists('LCFA_Codex_Config_Manager', false)) {
            return ['enabled' => false];
        }

        $manager = $this->get_codex_config_manager();
        $expected = $manager->get_expected_config($connections);
        $inspection = $manager->inspect($connections);
        $stored_hash = trim((string) ($connections['connection_last_bundle_hash'] ?? ''));
        $hash_matches = $stored_hash !== '' && hash_equals((string) $expected['hash'], $stored_hash);
        $synced = !empty($inspection['synced']);
        $message = !$synced
            ? (string) ($inspection['message'] ?? __('Codex config is stale. Regenerate or sync the Codex MCP config.', 'livecanvas-forge-ai'))
            : (!$hash_matches ? __('Codex config changed since the last smoke test. Rerun the smoke test.', 'livecanvas-forge-ai') : __('Codex config is aligned with this site.', 'livecanvas-forge-ai'));

        return [
            'enabled'                 => true,
            'expected'                => $expected,
            'inspection'              => $inspection,
            'synced'                  => $synced,
            'hash_matches'            => $hash_matches,
            'message'                 => $message,
            'should_invalidate_ready' => (string) ($connections['connection_status'] ?? '') === 'ready' && (!$synced || !$hash_matches),
        ];
    }

    private function render_codex_repair_panel(array $state): void {
        $expected = is_array($state['expected'] ?? null) ? $state['expected'] : [];
        $inspection = is_array($state['inspection'] ?? null) ? $state['inspection'] : [];
        $synced = !empty($state['synced']);
        $hash_matches = !empty($state['hash_matches']);
        $config_status = (string) ($inspection['status'] ?? 'unknown');
        $config_label = $synced ? __('synced', 'livecanvas-forge-ai') : ($config_status === 'missing' ? __('missing', 'livecanvas-forge-ai') : __('stale', 'livecanvas-forge-ai'));
        $script_ok = is_readable((string) ($expected['script_path'] ?? ''));
        $wp_root = (string) ($expected['wp_root'] ?? '');
        $wp_root_ok = $wp_root !== '' && is_file($wp_root . '/wp-load.php');

        echo '<section class="lcfa-card lcfa-ready-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('command');
        echo '<div><h2>' . esc_html__('Repair Codex Connection', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Use this when Codex has an old MCP token, an old plugin path, or a stale WordPress root in the project .codex/config.toml.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';
        echo '<div class="lcfa-chip-row">';
        echo '<span class="lcfa-chip' . ($wp_root_ok ? ' is-positive' : ' is-negative') . '">' . esc_html(sprintf(__('WordPress root: %s', 'livecanvas-forge-ai'), $wp_root_ok ? 'OK' : 'check')) . '</span>';
        echo '<span class="lcfa-chip is-positive">' . esc_html__('MCP token: current', 'livecanvas-forge-ai') . '</span>';
        echo '<span class="lcfa-chip' . ($synced ? ' is-positive' : ' is-negative') . '">' . esc_html(sprintf(__('Codex config: %s', 'livecanvas-forge-ai'), $config_label)) . '</span>';
        echo '<span class="lcfa-chip' . ($script_ok ? ' is-positive' : ' is-negative') . '">' . esc_html(sprintf(__('MCP script: %s', 'livecanvas-forge-ai'), $script_ok ? 'OK' : 'missing')) . '</span>';
        echo '<span class="lcfa-chip' . ($hash_matches ? ' is-positive' : '') . '">' . esc_html(sprintf(__('Smoke fingerprint: %s', 'livecanvas-forge-ai'), $hash_matches ? 'OK' : 'pending')) . '</span>';
        echo '</div>';
        echo '<div class="lcfa-connection-now-alert">';
        echo '<span class="lcfa-connection-now-alert__eyebrow">' . esc_html__('Codex repair status', 'livecanvas-forge-ai') . '</span>';
        echo '<strong>' . esc_html((string) ($state['message'] ?? __('Codex config should be checked.', 'livecanvas-forge-ai'))) . '</strong>';
        echo '<p>' . esc_html__('After updating the Codex project config, Codex must be restarted or the current MCP server must be reloaded before the new config is used.', 'livecanvas-forge-ai') . '</p>';
        echo '</div>';

        echo '<div class="lcfa-choice-grid lcfa-choice-grid--actions">';
        $this->render_codex_repair_action('sync_wp', __('Detect current WordPress path', 'livecanvas-forge-ai'), __('Sync WordPress connection settings', 'livecanvas-forge-ai'), __('Stores the current local ABSPATH as the active workspace root when the saved root is stale.', 'livecanvas-forge-ai'));
        $this->render_codex_repair_action('sync_codex', __('Update Codex config', 'livecanvas-forge-ai'), __('Write project .codex/config.toml', 'livecanvas-forge-ai'), __('Updates only mcp_servers.livecanvas-forge and creates a backup first.', 'livecanvas-forge-ai'), true);
        $this->render_codex_repair_action('smoke', __('Run smoke test', 'livecanvas-forge-ai'), __('Verify Codex MCP locally', 'livecanvas-forge-ai'), __('Runs REST health, Node, script, and get_mcp_status checks with the current token.', 'livecanvas-forge-ai'));
        echo '</div>';

        echo '<details class="lcfa-advanced-settings">';
        echo '<summary>' . esc_html__('Manual fallback', 'livecanvas-forge-ai') . '</summary>';
        echo '<p class="lcfa-guide-copy">' . esc_html__('Use this snippet if PHP cannot write the project Codex config for this local machine.', 'livecanvas-forge-ai') . '</p>';
        if (!empty($expected['config_path'])) {
            $this->render_code_block((string) $expected['config_path'], [
                'language' => 'text',
                'label' => __('Config file', 'livecanvas-forge-ai'),
                'copy_label' => __('Copy config path', 'livecanvas-forge-ai'),
            ]);
        }
        $this->render_code_block((string) ($expected['snippet'] ?? ''), [
            'language' => 'toml',
            'label' => __('TOML', 'livecanvas-forge-ai'),
            'copy_label' => __('Copy config snippet', 'livecanvas-forge-ai'),
        ]);
        if (sanitize_key((string) ($expected['config_scope'] ?? 'project')) === 'global') {
            $this->render_code_block((string) ($expected['remove_command'] ?? ''), [
                'language' => 'bash',
                'label' => __('Remove', 'livecanvas-forge-ai'),
                'copy_label' => __('Copy remove command', 'livecanvas-forge-ai'),
            ]);
            $this->render_code_block((string) ($expected['add_command'] ?? ''), [
                'language' => 'bash',
                'label' => __('Add', 'livecanvas-forge-ai'),
                'copy_label' => __('Copy add command', 'livecanvas-forge-ai'),
            ]);
        }
        echo '</details>';
        echo '</section>';
    }

    private function render_codex_repair_action(string $action, string $eyebrow, string $title, string $description, bool $primary = false): void {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form lcfa-choice-card lcfa-choice-card--action ' . ($primary ? 'lcfa-choice-card--primary' : 'lcfa-choice-card--secondary') . '">';
        wp_nonce_field('lcfa_repair_codex_connection');
        echo '<input type="hidden" name="action" value="lcfa_repair_codex_connection">';
        echo '<input type="hidden" name="codex_repair_action" value="' . esc_attr($action) . '">';
        echo '<span class="lcfa-choice-eyebrow">' . esc_html($eyebrow) . '</span>';
        echo '<span class="lcfa-choice-copy"><strong>' . esc_html($title) . '</strong><span>' . esc_html($description) . '</span></span>';
        echo '<button class="button ' . ($primary ? 'button-primary ' : '') . 'lcfa-button--wide" type="submit">' . esc_html($title) . '</button>';
        echo '</form>';
    }

    private function render_connection_framework_change_decision_card(array $connections, string $previous_framework, string $next_framework): void {
        $client = $this->normalize_connection_client((string) ($connections['preferred_client'] ?? 'codex'));
        $client_label = ucfirst(str_replace('-', ' ', $client));
        $previous_framework_label = $this->get_framework_display_name($previous_framework);
        $next_framework_label = $this->get_framework_display_name($next_framework);

        echo '<section class="lcfa-card lcfa-ready-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('command');
        echo '<div><h2>' . esc_html(sprintf(__('Reuse the existing %s connection?', 'livecanvas-forge-ai'), $client_label)) . '</h2><p>' . esc_html__('The site framework changed, but this coding-agent connection was already verified. Decide whether to keep using the current connection or regenerate a fresh bundle for the new stack.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';
        echo '<div class="lcfa-chip-row">';
        echo '<span class="lcfa-chip is-positive">' . esc_html__('Verified connection found', 'livecanvas-forge-ai') . '</span>';
        echo '<span class="lcfa-chip lcfa-chip--agent">' . $this->get_agent_icon_markup($client, 'stars') . '<span>' . esc_html(sprintf(__('Client: %s', 'livecanvas-forge-ai'), $client_label)) . '</span></span>';
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('From: %s', 'livecanvas-forge-ai'), $previous_framework_label)) . '</span>';
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('To: %s', 'livecanvas-forge-ai'), $next_framework_label)) . '</span>';
        if (!empty($connections['connection_last_verified_at'])) {
            echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Verified: %s', 'livecanvas-forge-ai'), (string) $connections['connection_last_verified_at'])) . '</span>';
        }
        echo '</div>';
        echo '<div class="lcfa-connection-now-alert">';
        echo '<span class="lcfa-connection-now-alert__eyebrow">' . esc_html__('Decision required', 'livecanvas-forge-ai') . '</span>';
        echo '<strong>' . esc_html__('Changing framework does not always require a brand-new coding-agent registration.', 'livecanvas-forge-ai') . '</strong>';
        echo '<p>' . esc_html__('Keep the existing connection if the same machine, workspace, and coding agent are still valid. Generate a new connection if you want to re-run the bundle flow for the new frontend stack.', 'livecanvas-forge-ai') . '</p>';
        echo '<small>' . esc_html__('AI Bridge will not continue the connection flow until you choose one of these two paths.', 'livecanvas-forge-ai') . '</small>';
        echo '</div>';

        echo '<div class="lcfa-choice-grid lcfa-choice-grid--actions">';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form lcfa-choice-card lcfa-choice-card--action lcfa-choice-card--secondary">';
        wp_nonce_field('lcfa_framework_change_connection');
        echo '<input type="hidden" name="action" value="lcfa_resolve_framework_change_connection">';
        echo '<input type="hidden" name="framework_connection_decision" value="keep">';
        echo '<span class="lcfa-choice-eyebrow">' . esc_html__('Keep current setup', 'livecanvas-forge-ai') . '</span>';
        echo '<span class="lcfa-choice-copy">';
        echo '<strong>' . esc_html__('Keep existing connection', 'livecanvas-forge-ai') . '</strong>';
        echo '<span>' . esc_html__('Use the verified connection that is already attached to this site and continue without generating a new bundle.', 'livecanvas-forge-ai') . '</span>';
        echo '<small>' . esc_html__('Best when the same coding agent, machine, and workspace are still in use.', 'livecanvas-forge-ai') . '</small>';
        echo '</span>';
        echo '<button class="button lcfa-button--wide" type="submit">' . esc_html__('Keep existing connection', 'livecanvas-forge-ai') . '</button>';
        echo '</form>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form lcfa-choice-card lcfa-choice-card--action lcfa-choice-card--primary">';
        wp_nonce_field('lcfa_framework_change_connection');
        echo '<input type="hidden" name="action" value="lcfa_resolve_framework_change_connection">';
        echo '<input type="hidden" name="framework_connection_decision" value="regenerate">';
        echo '<span class="lcfa-choice-eyebrow">' . esc_html__('New bundle flow', 'livecanvas-forge-ai') . '</span>';
        echo '<span class="lcfa-choice-copy">';
        echo '<strong>' . esc_html__('Generate new connection', 'livecanvas-forge-ai') . '</strong>';
        echo '<span>' . esc_html__('Keep the same coding agent, but reopen the bundle-generation flow so the new stack is confirmed step by step.', 'livecanvas-forge-ai') . '</span>';
        echo '<small>' . esc_html__('AI Bridge preserves the selected client and workspace root, then reopens the connection wizard from the details step.', 'livecanvas-forge-ai') . '</small>';
        echo '</span>';
        echo '<button class="button button-primary lcfa-button--wide" type="submit">' . esc_html__('Generate new connection', 'livecanvas-forge-ai') . '</button>';
        echo '</form>';

        echo '</div>';
        echo '</section>';
    }

    private function render_connection_wizard(array $wizard_view, array $bundle, array $connections, string $preferred_client, string $selected_mode, array $mcp_bootstrap, array $settings, array $snapshot, array $mcp_status, array $onboarding_state, array $workspace_write_state): void {
        $panel = is_array($wizard_view['active_panel'] ?? null) ? $wizard_view['active_panel'] : [];
        $current_step = (string) ($onboarding_state['current_step'] ?? 'choose_client');

        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('plug');
        echo '<div><h2>' . esc_html__('Connection wizard', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Follow one step at a time. AI Bridge will show the next action clearly and only unlock the next stage when the current one is done.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<div class="lcfa-wizard__intro">';
        $this->render_connection_stepper((array) ($wizard_view['steps'] ?? []));
        echo '</div>';
        $this->render_connection_active_step_panel($panel, $current_step, $bundle, $connections, $preferred_client, $selected_mode, $mcp_bootstrap, $settings, $snapshot, $mcp_status, $workspace_write_state);
        $this->render_connection_visual_help_strip($wizard_view);
        $this->render_agent_connection_guide($mcp_bootstrap, $settings, $snapshot, $preferred_client, $mcp_status, true);
        $this->render_connection_technical_summary($bundle, !empty($wizard_view['technical_summary']['expanded']));
        echo '</section>';
    }

    private function render_connections_secondary_panels(): void {
        echo '<details id="lcfa-connections-secondary" class="lcfa-card lcfa-advanced-settings lcfa-connections-secondary" data-lcfa-connections-secondary-root>';
        echo '<summary>' . esc_html__('Technical connection details', 'livecanvas-forge-ai') . '</summary>';
        echo '<div class="lcfa-connections-secondary__body">';
        echo '<section class="lcfa-connections-secondary__panel is-loading" data-lcfa-connections-panel="remote" aria-busy="true">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('cloud');
        echo '<div><h2>' . esc_html__('Advanced remote target', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Loading optional remote companion status and credentials…', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';
        echo '<div class="lcfa-connections-secondary__placeholder">';
        echo '<span class="lcfa-connections-secondary__line is-wide"></span>';
        echo '<span class="lcfa-connections-secondary__line"></span>';
        echo '<span class="lcfa-connections-secondary__line is-short"></span>';
        echo '</div>';
        echo '</section>';

        echo '<section class="lcfa-connections-secondary__panel is-loading" data-lcfa-connections-panel="advanced" aria-busy="true">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('plug');
        echo '<div><h2>' . esc_html__('Advanced settings', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Loading transport overrides, raw commands, and diagnostics…', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';
        echo '<div class="lcfa-connections-secondary__placeholder">';
        echo '<span class="lcfa-connections-secondary__line is-wide"></span>';
        echo '<span class="lcfa-connections-secondary__line"></span>';
        echo '<span class="lcfa-connections-secondary__line"></span>';
        echo '<span class="lcfa-connections-secondary__line is-short"></span>';
        echo '</div>';
        echo '</section>';

        echo '<section class="lcfa-connections-secondary__panel is-loading" data-lcfa-connections-panel="diagnostics" aria-busy="true">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('sparkles');
        echo '<div><h2>' . esc_html__('Ability diagnostics', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Loading WordPress 7 ability and MCP exposure summary…', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';
        echo '<div class="lcfa-connections-secondary__placeholder">';
        echo '<span class="lcfa-connections-secondary__line is-wide"></span>';
        echo '<span class="lcfa-connections-secondary__line"></span>';
        echo '<span class="lcfa-connections-secondary__line is-short"></span>';
        echo '</div>';
        echo '</section>';
        echo '</div>';
        echo '</details>';
    }

    private function render_connection_ready_card(array $wizard_view, array $bundle, array $connections, array $workspace_write_state): void {
        $panel = is_array($wizard_view['ready_panel'] ?? null) ? $wizard_view['ready_panel'] : [];
        $show_workspace_install = !empty($bundle['workspace_files']) && !empty($workspace_write_state['available']);
        echo '<section class="lcfa-card lcfa-ready-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('command');
        echo '<div><h2>' . esc_html((string) ($panel['title'] ?? __('Connection status', 'livecanvas-forge-ai'))) . '</h2><p>' . esc_html((string) ($panel['description'] ?? __('The selected client bundle has already been verified.', 'livecanvas-forge-ai'))) . '</p></div>';
        echo '</div>';
        $this->render_connection_now_alert((array) ($panel['alert'] ?? []));
        echo '<dl class="lcfa-runtime-facts lcfa-ready-facts">';
        echo '<div><dt>' . esc_html__('Status', 'livecanvas-forge-ai') . '</dt><dd class="is-positive"><span class="lcfa-status-dot" aria-hidden="true"></span><span>' . esc_html((string) ($panel['status_label'] ?? __('Ready', 'livecanvas-forge-ai'))) . '</span></dd></div>';
        echo '<div><dt>' . esc_html__('Coding agent', 'livecanvas-forge-ai') . '</dt><dd>' . $this->get_agent_icon_markup((string) ($bundle['client'] ?? 'codex'), 'stars') . '<span>' . esc_html(ucfirst(str_replace('-', ' ', (string) ($bundle['client'] ?? 'codex')))) . '</span></dd></div>';
        echo '<div><dt>' . esc_html__('Mode', 'livecanvas-forge-ai') . '</dt><dd>' . esc_html(ucfirst((string) ($bundle['mode'] ?? 'local'))) . '</dd></div>';
        if (!empty($connections['connection_last_verified_at'])) {
            echo '<div><dt>' . esc_html__('Last verified', 'livecanvas-forge-ai') . '</dt><dd>' . esc_html((string) $connections['connection_last_verified_at']) . '</dd></div>';
        }
        echo '</dl>';
        $this->render_connection_technical_summary($bundle, true);

        echo '<div class="lcfa-cta-row">';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
        wp_nonce_field('lcfa_test_connections');
        echo '<input type="hidden" name="action" value="lcfa_test_connections">';
        echo '<input type="hidden" name="connection_mode" value="' . esc_attr((string) ($bundle['mode'] ?? 'local')) . '">';
        echo '<button class="button button-primary lcfa-button-with-icon" type="submit">' . $this->get_icon_svg('activity') . '<span>' . esc_html((string) (($panel['primary_cta']['label'] ?? __('Run checks', 'livecanvas-forge-ai')))) . '</span></button>';
        echo '</form>';

        if ($show_workspace_install) {
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
            wp_nonce_field('lcfa_install_client_bundle');
            echo '<input type="hidden" name="action" value="lcfa_install_client_bundle">';
            echo '<input type="hidden" name="preferred_client" value="' . esc_attr((string) ($bundle['client'] ?? 'codex')) . '">';
            echo '<input type="hidden" name="connection_mode" value="' . esc_attr((string) ($bundle['mode'] ?? 'local')) . '">';
            echo '<input type="hidden" name="workspace_root" value="' . esc_attr((string) ($bundle['workspace_root'] ?? '')) . '">';
            echo '<button class="button lcfa-button-with-icon" type="submit">' . $this->get_icon_svg('file-earmark') . '<span>' . esc_html__('Write config in workspace', 'livecanvas-forge-ai') . '</span></button>';
            echo '</form>';
        }

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
        wp_nonce_field('lcfa_download_client_bundle');
        echo '<input type="hidden" name="action" value="lcfa_download_client_bundle">';
        echo '<input type="hidden" name="preferred_client" value="' . esc_attr((string) ($bundle['client'] ?? 'codex')) . '">';
        echo '<input type="hidden" name="connection_mode" value="' . esc_attr((string) ($bundle['mode'] ?? 'local')) . '">';
        echo '<input type="hidden" name="workspace_root" value="' . esc_attr((string) ($bundle['workspace_root'] ?? '')) . '">';
        echo '<button class="button lcfa-button-with-icon" type="submit">' . $this->get_icon_svg('shuffle') . '<span>' . esc_html__('Regenerate bundle', 'livecanvas-forge-ai') . '</span></button>';
        echo '</form>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
        wp_nonce_field('lcfa_reconfigure_connection');
        echo '<input type="hidden" name="action" value="lcfa_reconfigure_connection">';
        echo '<button class="button lcfa-button-with-icon" type="submit">' . $this->get_icon_svg('shuffle') . '<span>' . esc_html__('Change coding agent', 'livecanvas-forge-ai') . '</span></button>';
        echo '</form>';
        echo '</div>';

        if (!empty($bundle['workspace_files']) && empty($workspace_write_state['available'])) {
            echo '<div class="lcfa-workspace-note">';
            echo '<strong>' . esc_html__('Browser write disabled for this workspace', 'livecanvas-forge-ai') . '</strong>';
            echo '<p>' . esc_html($this->get_workspace_write_notice($workspace_write_state)) . '</p>';
            echo '</div>';
        }
        echo '</section>';
    }

    private function render_connection_now_alert(array $alert): void {
        $title = trim((string) ($alert['title'] ?? ''));
        $body = trim((string) ($alert['body'] ?? ''));
        $next = trim((string) ($alert['next'] ?? ''));
        $eyebrow = trim((string) ($alert['eyebrow'] ?? ''));

        if ($title === '' && $body === '' && $next === '') {
            return;
        }

        echo '<div class="lcfa-connection-now-alert">';
        if ($eyebrow !== '') {
            echo '<span class="lcfa-connection-now-alert__eyebrow">' . esc_html($eyebrow) . '</span>';
        }
        if ($title !== '') {
            echo '<strong>' . esc_html($title) . '</strong>';
        }
        if ($body !== '') {
            echo '<p>' . esc_html($body) . '</p>';
        }
        if ($next !== '') {
            echo '<small>' . esc_html($next) . '</small>';
        }
        echo '</div>';
    }

    private function render_connection_stepper(array $steps): void {
        echo '<ol class="lcfa-wizard__steps">';
        foreach ($steps as $step) {
            $state = (string) ($step['state'] ?? 'locked');
            echo '<li class="is-' . esc_attr($state) . '"' . ($state === 'active' ? ' aria-current="step"' : '') . '>';
            if ($state === 'done') {
                echo '<span class="lcfa-wizard__step-number is-complete" aria-label="' . esc_attr__('Completed', 'livecanvas-forge-ai') . '">' . $this->get_icon_svg('check-circle') . '</span>';
            } else {
                echo '<span class="lcfa-wizard__step-number">' . esc_html((string) ($step['number'] ?? '')) . '</span>';
            }
            echo '<strong>' . esc_html((string) ($step['title'] ?? '')) . '</strong>';
            echo '</li>';
        }
        echo '</ol>';
    }

    private function render_connection_active_step_panel(array $panel, string $current_step, array $bundle, array $connections, string $preferred_client, string $selected_mode, array $mcp_bootstrap, array $settings, array $snapshot, array $mcp_status, array $workspace_write_state): void {
        $claude_connection_target = $this->normalize_claude_connection_target((string) ($connections['claude_connection_target'] ?? ''));
        $panel_class = 'lcfa-wizard__panel';
        if ($current_step === 'smoke_test') {
            $panel_class .= ' lcfa-wizard__panel--blocking';
        }

        echo '<section class="' . esc_attr($panel_class) . '">';
        echo '<div class="lcfa-wizard__panel-head">';
        echo '<div class="lcfa-wizard__panel-label">' . $this->get_icon_svg('activity') . '<span>' . esc_html__('Current action', 'livecanvas-forge-ai') . '</span></div>';
        echo '<h3>' . esc_html((string) ($panel['title'] ?? __('Connection step', 'livecanvas-forge-ai'))) . '</h3>';
        if (!empty($panel['description'])) {
            echo '<p>' . esc_html((string) $panel['description']) . '</p>';
        }
        echo '</div>';

        switch ($current_step) {
            case 'choose_claude_target':
                $this->render_connection_choose_claude_target_form($preferred_client, $claude_connection_target, $selected_mode, (string) ($bundle['workspace_root'] ?? ''), (string) ($panel['primary_cta']['label'] ?? __('Continue', 'livecanvas-forge-ai')));
                break;

            case 'choose_mode':
                $this->render_connection_choose_mode_form($preferred_client, $claude_connection_target, $selected_mode, (string) ($bundle['workspace_root'] ?? ''), (string) ($panel['primary_cta']['label'] ?? __('Continue', 'livecanvas-forge-ai')));
                break;

            case 'confirm_details':
                $this->render_connection_confirm_details_form($bundle, $preferred_client, $claude_connection_target, $selected_mode, (string) ($panel['primary_cta']['label'] ?? __('Confirm connection', 'livecanvas-forge-ai')));
                break;

            case 'generate_bundle':
                $this->render_connection_generate_bundle_actions($bundle, $workspace_write_state, $panel);
                break;

            case 'smoke_test':
                $this->render_connection_smoke_test_form($selected_mode, (string) ($panel['primary_cta']['label'] ?? __('Run smoke test', 'livecanvas-forge-ai')), $bundle);
                break;

            case 'choose_client':
            default:
                $this->render_connection_choose_client_form($preferred_client, $selected_mode, (string) ($bundle['workspace_root'] ?? ''), (string) ($panel['primary_cta']['label'] ?? __('Continue', 'livecanvas-forge-ai')));
                break;
        }

        if ($current_step !== 'choose_client') {
            echo '<div class="lcfa-cta-row lcfa-wizard__secondary-actions">';
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
            wp_nonce_field('lcfa_reconfigure_connection');
            echo '<input type="hidden" name="action" value="lcfa_reconfigure_connection">';
            echo '<button class="button lcfa-button-with-icon" type="submit">' . $this->get_icon_svg('shuffle') . '<span>' . esc_html__('Change coding agent', 'livecanvas-forge-ai') . '</span></button>';
            echo '</form>';
            echo '</div>';
        }

        echo '</section>';
    }

    private function render_connection_choose_client_form(string $preferred_client, string $selected_mode, string $workspace_root, string $button_label): void {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form lcfa-wizard">';
        wp_nonce_field('lcfa_connections');
        echo '<input type="hidden" name="action" value="lcfa_connections">';
        echo '<input type="hidden" name="connection_current_step" value="choose_client">';
        echo '<input type="hidden" name="connection_mode" value="' . esc_attr($selected_mode) . '">';
        echo '<input type="hidden" name="workspace_root" value="' . esc_attr($workspace_root) . '">';
        echo '<div class="lcfa-guide"><p class="lcfa-guide-copy">' . esc_html__('Choose the coding agent you want to connect. Each option uses its official client icon so the flow stays recognizable when you switch tools.', 'livecanvas-forge-ai') . '</p></div>';
        echo '<div class="lcfa-radio-group lcfa-radio-group--agents">';
        $this->render_radio('preferred_client', 'codex', __('Codex', 'livecanvas-forge-ai'), $preferred_client, 'stars');
        $this->render_radio('preferred_client', 'opencode', __('OpenCode', 'livecanvas-forge-ai'), $preferred_client, 'braces');
        $this->render_radio('preferred_client', 'claude', __('Claude', 'livecanvas-forge-ai'), $preferred_client, 'cpu');
        $this->render_radio('preferred_client', 'cursor', __('Cursor', 'livecanvas-forge-ai'), $preferred_client, 'cursor');
        $this->render_radio('preferred_client', 'generic', __('Generic MCP client', 'livecanvas-forge-ai'), $preferred_client, 'plug');
        echo '</div>';
        echo '<div class="lcfa-cta-row">';
        echo '<button class="button button-primary lcfa-button-with-icon" type="submit">' . $this->get_icon_svg('rocket') . '<span>' . esc_html($button_label) . '</span></button>';
        echo '</div>';
        echo '</form>';
    }

    private function render_connection_choose_claude_target_form(string $preferred_client, string $selected_target, string $selected_mode, string $workspace_root, string $button_label): void {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form lcfa-wizard">';
        wp_nonce_field('lcfa_connections');
        echo '<input type="hidden" name="action" value="lcfa_connections">';
        echo '<input type="hidden" name="connection_current_step" value="choose_claude_target">';
        echo '<input type="hidden" name="preferred_client" value="' . esc_attr($preferred_client) . '">';
        echo '<input type="hidden" name="connection_mode" value="' . esc_attr($selected_mode) . '">';
        echo '<input type="hidden" name="workspace_root" value="' . esc_attr($workspace_root) . '">';
        echo '<div class="lcfa-radio-group lcfa-radio-group--inline">';
        $this->render_radio('claude_connection_target', 'desktop_app', __('Desktop App', 'livecanvas-forge-ai'), $selected_target, 'window-stack');
        $this->render_radio('claude_connection_target', 'cli', __('Command Line Interface', 'livecanvas-forge-ai'), $selected_target, 'command');
        echo '</div>';
        echo '<div class="lcfa-cta-row">';
        echo '<button class="button button-primary lcfa-button-with-icon" type="submit">' . $this->get_icon_svg('rocket') . '<span>' . esc_html($button_label) . '</span></button>';
        echo '</div>';
        echo '</form>';
    }

    private function render_connection_choose_mode_form(string $preferred_client, string $claude_connection_target, string $selected_mode, string $workspace_root, string $button_label): void {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form lcfa-wizard">';
        wp_nonce_field('lcfa_connections');
        echo '<input type="hidden" name="action" value="lcfa_connections">';
        echo '<input type="hidden" name="connection_current_step" value="choose_mode">';
        echo '<input type="hidden" name="preferred_client" value="' . esc_attr($preferred_client) . '">';
        echo '<input type="hidden" name="claude_connection_target" value="' . esc_attr($claude_connection_target) . '">';
        echo '<input type="hidden" name="workspace_root" value="' . esc_attr($workspace_root) . '">';
        echo '<label><span>' . esc_html__('Connection mode', 'livecanvas-forge-ai') . '</span>';
        echo '<select name="connection_mode">';
        echo '<option value="local"' . selected($selected_mode, 'local', false) . '>' . esc_html__('Local WordPress site (this computer)', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="remote"' . selected($selected_mode, 'remote', false) . '>' . esc_html__('Remote WordPress site (online)', 'livecanvas-forge-ai') . '</option>';
        echo '</select></label>';
        echo '<div class="lcfa-cta-row">';
        echo '<button class="button button-primary lcfa-button-with-icon" type="submit">' . $this->get_icon_svg('rocket') . '<span>' . esc_html($button_label) . '</span></button>';
        echo '</div>';
        echo '</form>';
    }

    private function render_connection_confirm_details_form(array $bundle, string $preferred_client, string $claude_connection_target, string $selected_mode, string $button_label): void {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form lcfa-wizard">';
        wp_nonce_field('lcfa_connections');
        echo '<input type="hidden" name="action" value="lcfa_connections">';
        echo '<input type="hidden" name="connection_current_step" value="confirm_details">';
        echo '<input type="hidden" name="preferred_client" value="' . esc_attr($preferred_client) . '">';
        echo '<input type="hidden" name="claude_connection_target" value="' . esc_attr($claude_connection_target) . '">';
        echo '<input type="hidden" name="connection_mode" value="' . esc_attr($selected_mode) . '">';

        echo '<div class="lcfa-wizard__details">';
        echo '<div class="lcfa-wizard__connection-target"><span>' . esc_html__('Connection target', 'livecanvas-forge-ai') . '</span><strong>' . esc_html($selected_mode === 'remote' ? __('Remote WordPress site', 'livecanvas-forge-ai') : __('This local WordPress site', 'livecanvas-forge-ai')) . '</strong><small>' . esc_html($selected_mode === 'remote' ? __('The client will connect to the online site shown below.', 'livecanvas-forge-ai') : __('The site is already detected as local. There is nothing to choose in this step.', 'livecanvas-forge-ai')) . '</small></div>';
        if ((string) ($bundle['connection_strategy'] ?? '') === 'ai-bridge-session') {
            echo '<div><span>' . esc_html__('Target site', 'livecanvas-forge-ai') . '</span><code>' . esc_html((string) ($bundle['environment']['LCFA_SITE_URL'] ?? '')) . '</code></div>';
            echo '<div><span>' . esc_html__('Site fingerprint', 'livecanvas-forge-ai') . '</span><code>' . esc_html((string) ($bundle['environment']['LCFA_SITE_FINGERPRINT'] ?? '')) . '</code></div>';
            echo '<div><span>' . esc_html__('Remote proxy', 'livecanvas-forge-ai') . '</span><code>@livecanvas/ai-bridge-mcp</code></div>';
            echo '<div><span>' . esc_html__('Auth', 'livecanvas-forge-ai') . '</span><code>' . esc_html__('Secure pairing session', 'livecanvas-forge-ai') . '</code></div>';
        } elseif ((string) ($bundle['connection_strategy'] ?? '') === 'remote-mcp-adapter') {
            echo '<div><span>' . esc_html__('MCP Adapter URL', 'livecanvas-forge-ai') . '</span><code>' . esc_html((string) ($bundle['mcp_adapter_url'] ?? ($bundle['environment']['WP_API_URL'] ?? ''))) . '</code></div>';
            echo '<div><span>' . esc_html__('Remote user', 'livecanvas-forge-ai') . '</span><code>' . esc_html((string) (($bundle['environment']['WP_API_USERNAME'] ?? ''))) . '</code></div>';
            echo '<div><span>' . esc_html__('Remote proxy', 'livecanvas-forge-ai') . '</span><code>@automattic/mcp-wordpress-remote</code></div>';
        } else {
            echo '<div><span>' . esc_html__('REST base', 'livecanvas-forge-ai') . '</span><code>' . esc_html((string) (($bundle['environment']['LCFA_REST_BASE'] ?? ''))) . '</code></div>';
            echo '<div><span>' . esc_html__('MCP token', 'livecanvas-forge-ai') . '</span><code>' . esc_html((string) (($bundle['environment']['LCFA_MCP_TOKEN'] ?? ''))) . '</code></div>';
        }
        if ($selected_mode === 'local') {
            echo '<label><span>' . esc_html__('Local workspace root', 'livecanvas-forge-ai') . '</span><input type="text" name="workspace_root" value="' . esc_attr((string) ($bundle['workspace_root'] ?? '')) . '" placeholder="/Users/you/project"></label>';
            echo '<p class="lcfa-guide-copy">' . esc_html__('This must be the real project path on your machine, not the runtime mount path used by Local or Docker.', 'livecanvas-forge-ai') . '</p>';
        } else {
            echo '<input type="hidden" name="workspace_root" value="">';
        }
        echo '</div>';
        echo '<p class="lcfa-guide-copy">' . esc_html((string) ($bundle['connection_strategy'] ?? '') === 'remote-mcp-adapter' ? __('If these values look correct, confirm them to generate the Codex remote MCP Adapter shortcut.', 'livecanvas-forge-ai') : __('If these values look correct, confirm them to generate the client bundle for the selected coding agent.', 'livecanvas-forge-ai')) . '</p>';
        echo '<div class="lcfa-cta-row">';
        echo '<button class="button button-primary lcfa-button-with-icon" type="submit">' . $this->get_icon_svg('check-circle') . '<span>' . esc_html($button_label) . '</span></button>';
        if ((string) ($bundle['connection_strategy'] ?? '') !== 'remote-mcp-adapter') {
            echo '<button class="button lcfa-button-with-icon" type="submit" name="rotate_mcp_token" value="1">' . $this->get_icon_svg('shuffle') . '<span>' . esc_html__('Rotate MCP token', 'livecanvas-forge-ai') . '</span></button>';
        }
        echo '</div>';
        echo '</form>';
    }

    private function render_connection_generate_bundle_actions(array $bundle, array $workspace_write_state, array $panel): void {
        $show_workspace_install = !empty($bundle['workspace_files']) && !empty($workspace_write_state['available']);
        $secondary_ctas = is_array($panel['secondary_ctas'] ?? null) ? $panel['secondary_ctas'] : [];
        $primary_cta = is_array($panel['primary_cta'] ?? null) ? $panel['primary_cta'] : [];
        $primary_action = (string) ($primary_cta['action'] ?? '');
        $copy_text = (string) ($bundle['copy_command_string'] ?? ($bundle['command_string'] ?? ''));
        $claude_connection_target = (string) ($bundle['claude_connection_target'] ?? '');

        echo '<div class="lcfa-choice-grid lcfa-choice-grid--actions">';
        if (($primary_cta['action'] ?? '') === 'copy_command' && $copy_text !== '') {
            $primary_copy = $this->get_generate_bundle_action_copy($bundle, 'copy_command', true);
            echo '<div class="lcfa-choice-card lcfa-choice-card--action lcfa-choice-card--primary">';
            echo '<span class="lcfa-choice-eyebrow">' . esc_html($primary_copy['eyebrow']) . '</span>';
            echo '<span class="lcfa-choice-copy">';
            echo '<strong>' . esc_html($primary_copy['title']) . '</strong>';
            echo '<span>' . esc_html($primary_copy['description']) . '</span>';
            echo '<small>' . esc_html($primary_copy['note']) . '</small>';
            echo '</span>';
            echo '<button class="button button-primary lcfa-button--wide lcfa-button-with-icon" type="button" data-lcfa-copy-text="' . esc_attr($copy_text) . '" data-lcfa-copy-label="' . esc_attr((string) ($primary_cta['label'] ?? __('Copy command', 'livecanvas-forge-ai'))) . '" data-lcfa-copied-label="' . esc_attr(__('Copied', 'livecanvas-forge-ai')) . '">' . $this->get_icon_svg('file-earmark') . '<span>' . esc_html((string) ($primary_cta['label'] ?? __('Copy command', 'livecanvas-forge-ai'))) . '</span></button>';
            echo '</div>';
        } elseif ($show_workspace_install && ($primary_cta['action'] ?? '') === 'install') {
            $primary_install = $this->get_generate_bundle_action_copy($bundle, 'install', true);
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form lcfa-choice-card lcfa-choice-card--action lcfa-choice-card--primary">';
            wp_nonce_field('lcfa_install_client_bundle');
            echo '<input type="hidden" name="action" value="lcfa_install_client_bundle">';
            echo '<input type="hidden" name="preferred_client" value="' . esc_attr((string) ($bundle['client'] ?? 'codex')) . '">';
            echo '<input type="hidden" name="claude_connection_target" value="' . esc_attr($claude_connection_target) . '">';
            echo '<input type="hidden" name="connection_mode" value="' . esc_attr((string) ($bundle['mode'] ?? 'local')) . '">';
            echo '<input type="hidden" name="workspace_root" value="' . esc_attr((string) ($bundle['workspace_root'] ?? '')) . '">';
            echo '<span class="lcfa-choice-eyebrow">' . esc_html($primary_install['eyebrow']) . '</span>';
            echo '<span class="lcfa-choice-copy">';
            echo '<strong>' . esc_html($primary_install['title']) . '</strong>';
            echo '<span>' . esc_html($primary_install['description']) . '</span>';
            echo '<small>' . esc_html($primary_install['note']) . '</small>';
            echo '</span>';
            echo '<label class="lcfa-checkbox lcfa-checkbox--card"><input type="checkbox" name="create_backup" value="1"> ' . esc_html__('Create backup before overwrite', 'livecanvas-forge-ai') . '</label>';
            echo '<button class="button button-primary lcfa-button--wide lcfa-button-with-icon" type="submit">' . $this->get_icon_svg('file-earmark') . '<span>' . esc_html((string) ($panel['primary_cta']['label'] ?? __('Write config in workspace', 'livecanvas-forge-ai'))) . '</span></button>';
            echo '</form>';
        } else {
            $primary_download = $this->get_generate_bundle_action_copy($bundle, 'download', true);
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form lcfa-choice-card lcfa-choice-card--action lcfa-choice-card--primary">';
            wp_nonce_field('lcfa_download_client_bundle');
            echo '<input type="hidden" name="action" value="lcfa_download_client_bundle">';
            echo '<input type="hidden" name="preferred_client" value="' . esc_attr((string) ($bundle['client'] ?? 'codex')) . '">';
            echo '<input type="hidden" name="claude_connection_target" value="' . esc_attr($claude_connection_target) . '">';
            echo '<input type="hidden" name="connection_mode" value="' . esc_attr((string) ($bundle['mode'] ?? 'local')) . '">';
            echo '<input type="hidden" name="workspace_root" value="' . esc_attr((string) ($bundle['workspace_root'] ?? '')) . '">';
            echo '<span class="lcfa-choice-eyebrow">' . esc_html($primary_download['eyebrow']) . '</span>';
            echo '<span class="lcfa-choice-copy">';
            echo '<strong>' . esc_html($primary_download['title']) . '</strong>';
            echo '<span>' . esc_html($primary_download['description']) . '</span>';
            echo '<small>' . esc_html($primary_download['note']) . '</small>';
            echo '</span>';
            echo '<button class="button button-primary lcfa-button--wide lcfa-button-with-icon" type="submit">' . $this->get_icon_svg('file-earmark') . '<span>' . esc_html((string) ($panel['primary_cta']['label'] ?? __('Download client bundle', 'livecanvas-forge-ai'))) . '</span></button>';
            echo '</form>';
        }

        foreach ($secondary_ctas as $secondary_cta) {
            $action = (string) ($secondary_cta['action'] ?? '');
            $label = (string) ($secondary_cta['label'] ?? '');

            if ($action === $primary_action) {
                continue;
            }

            if ($action === 'download') {
                $secondary_download = $this->get_generate_bundle_action_copy($bundle, 'download', false);
                echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form lcfa-choice-card lcfa-choice-card--action lcfa-choice-card--secondary">';
                wp_nonce_field('lcfa_download_client_bundle');
                echo '<input type="hidden" name="action" value="lcfa_download_client_bundle">';
                echo '<input type="hidden" name="preferred_client" value="' . esc_attr((string) ($bundle['client'] ?? 'codex')) . '">';
                echo '<input type="hidden" name="claude_connection_target" value="' . esc_attr($claude_connection_target) . '">';
                echo '<input type="hidden" name="connection_mode" value="' . esc_attr((string) ($bundle['mode'] ?? 'local')) . '">';
                echo '<input type="hidden" name="workspace_root" value="' . esc_attr((string) ($bundle['workspace_root'] ?? '')) . '">';
                echo '<span class="lcfa-choice-eyebrow">' . esc_html($secondary_download['eyebrow']) . '</span>';
                echo '<span class="lcfa-choice-copy">';
                echo '<strong>' . esc_html($secondary_download['title']) . '</strong>';
                echo '<span>' . esc_html($secondary_download['description']) . '</span>';
                echo '<small>' . esc_html($secondary_download['note']) . '</small>';
                echo '</span>';
                echo '<button class="button lcfa-button--wide lcfa-button-with-icon" type="submit">' . $this->get_icon_svg('file-earmark') . '<span>' . esc_html($label ?: __('Download client bundle', 'livecanvas-forge-ai')) . '</span></button>';
                echo '</form>';
            }

            if ($action === 'copy_command' && $copy_text !== '') {
                $copy_label = $label ?: __('Copy command', 'livecanvas-forge-ai');
                $secondary_copy = $this->get_generate_bundle_action_copy($bundle, 'copy_command', false);
                echo '<div class="lcfa-choice-card lcfa-choice-card--action lcfa-choice-card--secondary">';
                echo '<span class="lcfa-choice-eyebrow">' . esc_html($secondary_copy['eyebrow']) . '</span>';
                echo '<span class="lcfa-choice-copy">';
                echo '<strong>' . esc_html($secondary_copy['title']) . '</strong>';
                echo '<span>' . esc_html($secondary_copy['description']) . '</span>';
                echo '<small>' . esc_html($secondary_copy['note']) . '</small>';
                echo '</span>';
                echo '<button class="button lcfa-button--wide lcfa-button-with-icon" type="button" data-lcfa-copy-text="' . esc_attr($copy_text) . '" data-lcfa-copy-label="' . esc_attr($copy_label) . '" data-lcfa-copied-label="' . esc_attr(__('Copied', 'livecanvas-forge-ai')) . '">' . $this->get_icon_svg('file-earmark') . '<span>' . esc_html($copy_label) . '</span></button>';
                echo '</div>';
            }
        }
        echo '</div>';

        if (!empty($bundle['workspace_files']) && empty($workspace_write_state['available'])) {
            echo '<div class="lcfa-workspace-note">';
            echo '<strong>' . esc_html__('Browser write disabled for this workspace', 'livecanvas-forge-ai') . '</strong>';
            echo '<p>' . esc_html($this->get_workspace_write_notice($workspace_write_state)) . '</p>';
            if ((string) ($bundle['client'] ?? '') === 'codex' && (string) ($bundle['mode'] ?? 'local') === 'local') {
                echo '<p>' . esc_html__('Recommended Codex flow: copy the Codex shortcut, run it once in a terminal from this workspace, let it auto-detect the embedded Codex desktop CLI if codex is not in PATH, confirm with codex mcp list or /Applications/Codex.app/Contents/Resources/codex mcp list, then come back here and run the smoke test.', 'livecanvas-forge-ai') . '</p>';
            } else {
                echo '<p>' . esc_html__('Recommended local flow: download the client bundle, open the project in your coding agent, let the local MCP bridge start once, then come back here and run the smoke test.', 'livecanvas-forge-ai') . '</p>';
            }
            echo '</div>';
        }
    }

    private function get_generate_bundle_action_copy(array $bundle, string $action, bool $is_primary): array {
        $is_codex_local = $this->normalize_connection_client((string) ($bundle['client'] ?? '')) === 'codex'
            && (($bundle['mode'] ?? 'local') === 'local');
        $is_codex_remote_adapter = $this->normalize_connection_client((string) ($bundle['client'] ?? '')) === 'codex'
            && (string) ($bundle['connection_strategy'] ?? '') === 'remote-mcp-adapter';
        $is_opencode_local = $this->normalize_connection_client((string) ($bundle['client'] ?? '')) === 'opencode'
            && (($bundle['mode'] ?? 'local') === 'local');

        if ($action === 'install') {
            return [
                'eyebrow'     => $is_primary ? __('Recommended', 'livecanvas-forge-ai') : __('Alternative', 'livecanvas-forge-ai'),
                'title'       => __('Write the config for me', 'livecanvas-forge-ai'),
                'description' => $is_codex_local
                    ? __('AI Bridge writes the generated Codex helper directly into this workspace now. This is the fastest path when the browser can reach the project folder.', 'livecanvas-forge-ai')
                    : __('AI Bridge writes the generated client config directly into this workspace now, so you can verify the connection immediately after.', 'livecanvas-forge-ai'),
                'note'        => __('Optional: enable the backup toggle first if you want to preserve the current file before overwrite.', 'livecanvas-forge-ai'),
            ];
        }

        if ($action === 'copy_command') {
            return [
                'eyebrow'     => $is_primary ? __('Recommended', 'livecanvas-forge-ai') : __('Alternative', 'livecanvas-forge-ai'),
                'title'       => ($is_codex_local || $is_codex_remote_adapter) ? __('Copy and run the Codex shortcut', 'livecanvas-forge-ai') : __('Copy the setup command', 'livecanvas-forge-ai'),
                'description' => $is_codex_remote_adapter
                    ? __('Run it once on the machine where Codex runs. It registers the WordPress MCP Adapter remote proxy with Codex.', 'livecanvas-forge-ai')
                    : ($is_codex_local
                    ? __('Run it once from this exact project root, then return here and move to the smoke test.', 'livecanvas-forge-ai')
                    : __('Use this if you want to execute the setup manually from your coding agent shell.', 'livecanvas-forge-ai')),
                'note'        => $is_codex_remote_adapter
                    ? __('Best for remote WordPress because no local WordPress filesystem is required.', 'livecanvas-forge-ai')
                    : __('Best when the browser cannot write into the host workspace directly.', 'livecanvas-forge-ai'),
            ];
        }

        return [
            'eyebrow'     => $is_primary ? __('Recommended', 'livecanvas-forge-ai') : __('Manual option', 'livecanvas-forge-ai'),
            'title'       => $is_opencode_local ? __('Download the OpenCode config', 'livecanvas-forge-ai') : __('Download and place it yourself', 'livecanvas-forge-ai'),
            'description' => $is_opencode_local
                ? __('Save the generated OpenCode config and place it in the project root before you switch back to OpenCode.', 'livecanvas-forge-ai')
                : __('Use this if you prefer a manual install, want to move the bundle to another machine, or do not want the browser to write inside the workspace.', 'livecanvas-forge-ai'),
            'note'        => __('After the file is in place, come back here and run the smoke test.', 'livecanvas-forge-ai'),
        ];
    }

    private function render_connection_smoke_test_form(string $selected_mode, string $button_label, array $bundle = []): void {
        $is_codex = $this->normalize_connection_client((string) ($bundle['client'] ?? '')) === 'codex';
        if ($is_codex) {
            $workspace_root = trim((string) ($bundle['workspace_root'] ?? ''));
            $helper_path = '';
            $workspace_files = is_array($bundle['workspace_files'] ?? null) ? $bundle['workspace_files'] : [];
            if (isset($workspace_files[0]) && is_array($workspace_files[0])) {
                $helper_path = trim((string) ($workspace_files[0]['path'] ?? ''));
            }
            if ($helper_path === '' && $workspace_root !== '') {
                $helper_path = rtrim($workspace_root, '/\\') . '/livecanvas-forge.codex.sh';
            }

            echo '<div class="lcfa-codex-smoke-guide">';
            echo '<strong>' . esc_html__('To connect Codex, complete these steps in order:', 'livecanvas-forge-ai') . '</strong>';
            echo '<ol>';
            if ((string) ($bundle['connection_strategy'] ?? '') === 'remote-mcp-adapter') {
                echo '<li>' . esc_html__('Run the generated Codex shortcut on the machine where Codex runs. It starts the WordPress MCP Adapter remote proxy.', 'livecanvas-forge-ai') . '</li>';
            } elseif ($workspace_root !== '') {
                echo '<li>' . esc_html__('Open Terminal in this project root:', 'livecanvas-forge-ai') . ' <code>' . esc_html($workspace_root) . '</code></li>';
            } else {
                echo '<li>' . esc_html__('Open Terminal in the WordPress project root selected in this wizard.', 'livecanvas-forge-ai') . '</li>';
            }
            if ($helper_path !== '') {
                echo '<li>' . esc_html__('Run the generated helper:', 'livecanvas-forge-ai') . ' ' . $this->render_inline_copy_command('sh "' . $helper_path . '"') . '</li>';
            } elseif ((string) ($bundle['connection_strategy'] ?? '') === 'remote-mcp-adapter') {
                echo '<li>' . esc_html__('If you downloaded the helper, run it from any trusted local folder; it does not need the WordPress filesystem.', 'livecanvas-forge-ai') . '</li>';
            } else {
                echo '<li>' . esc_html__('Run the generated livecanvas-forge.codex.sh helper from that project root.', 'livecanvas-forge-ai') . '</li>';
            }
            echo '<li>' . esc_html__('Verify that Codex can see the MCP server:', 'livecanvas-forge-ai') . ' ' . $this->render_inline_copy_command('codex mcp list') . ' ' . esc_html__('or', 'livecanvas-forge-ai') . ' ' . $this->render_inline_copy_command('/Applications/Codex.app/Contents/Resources/codex mcp list') . '</li>';
            echo '<li>' . esc_html__('The command output must show:', 'livecanvas-forge-ai') . ' <code>livecanvas-forge</code>. ' . esc_html__('If the output does not show livecanvas-forge, the connection is not ready yet.', 'livecanvas-forge-ai') . '</li>';
            echo '</ol>';
            echo '<div class="lcfa-codex-smoke-alert">';
            echo '<strong>' . esc_html__('Important', 'livecanvas-forge-ai') . '</strong>';
            echo '<span>' . esc_html__('Reopen Codex if the registration was added while Codex was already open, then return here and run the smoke test below.', 'livecanvas-forge-ai') . '</span>';
            echo '</div>';
            echo '</div>';
        }

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
        wp_nonce_field('lcfa_test_connections');
        echo '<input type="hidden" name="action" value="lcfa_test_connections">';
        echo '<input type="hidden" name="connection_mode" value="' . esc_attr($selected_mode) . '">';
        echo '<button class="button button-primary lcfa-button-with-icon" type="submit">' . $this->get_icon_svg('activity') . '<span>' . esc_html($button_label) . '</span></button>';
        echo '</form>';
    }

    private function render_inline_copy_command(string $command, string $label = ''): string {
        $copy_label = $label !== '' ? $label : __('Copy', 'livecanvas-forge-ai');

        return '<span class="lcfa-inline-copy-code"><code>' . esc_html($command) . '</code><button class="lcfa-inline-copy-code__button" type="button" data-lcfa-copy-text="' . esc_attr($command) . '" data-lcfa-copy-label="' . esc_attr($copy_label) . '" data-lcfa-copied-label="' . esc_attr(__('Copied', 'livecanvas-forge-ai')) . '">' . esc_html($copy_label) . '</button></span>';
    }

    private function render_code_block_explanation(string $description): void {
        if (trim($description) === '') {
            return;
        }

        echo '<div class="lcfa-code-explanation" data-lcfa-read-more>';
        echo '<p data-lcfa-read-more-body>' . esc_html($description) . '</p>';
        echo '<button class="lcfa-code-explanation__toggle" type="button" data-lcfa-read-more-toggle data-lcfa-expanded-label="' . esc_attr(__('Show less', 'livecanvas-forge-ai')) . '" hidden>' . esc_html__('Read more', 'livecanvas-forge-ai') . '</button>';
        echo '</div>';
    }

    private function render_connection_visual_help_strip(array $wizard_view): void {
        $visual_help = is_array($wizard_view['visual_help'] ?? null) ? $wizard_view['visual_help'] : [];
        $items = is_array($visual_help['items'] ?? null) ? $visual_help['items'] : [];
        $client = $this->sanitize_key_compat((string) ($visual_help['client'] ?? ''));

        if ($items === []) {
            return;
        }

        echo '<section class="lcfa-visual-help" aria-labelledby="lcfa-visual-help-title">';
        echo '<div class="lcfa-guide">';
        echo '<h3 class="lcfa-visual-help__title" id="lcfa-visual-help-title">';
        if ($client !== '') {
            echo $this->get_agent_icon_markup($client, $this->get_client_fallback_icon($client), 'lcfa-agent-icon lcfa-agent-icon--section');
        }
        echo '<span>' . esc_html((string) ($visual_help['title'] ?? __('What this looks like', 'livecanvas-forge-ai'))) . '</span>';
        echo '</h3>';
        echo '</div>';
        echo '<ol class="lcfa-visual-help__grid lcfa-visual-help__flow">';

        foreach ($items as $index => $item) {
            $tone = sanitize_html_class((string) ($item['tone'] ?? 'default'));
            $icon = sanitize_key((string) ($item['icon'] ?? ($tone === 'verify' ? 'check-circle' : ($tone === 'mcp' ? 'plug' : 'laptop'))));
            echo '<li class="lcfa-visual-help__card tone-' . esc_attr($tone) . '">';
            echo '<span class="lcfa-visual-help__marker" aria-hidden="true">' . $this->get_icon_svg($icon) . '</span>';
            echo '<div class="lcfa-visual-help__content">';
            if (!empty($item['context'])) {
                echo '<span class="lcfa-visual-help__context">' . esc_html((string) $item['context']) . '</span>';
            }
            echo '<strong><span class="screen-reader-text">' . esc_html(sprintf(__('Step %d:', 'livecanvas-forge-ai'), $index + 1)) . ' </span>' . esc_html((string) ($item['title'] ?? '')) . '</strong>';
            echo '<p>' . esc_html((string) ($item['caption'] ?? '')) . '</p>';
            echo '</div>';
            echo '</li>';
        }

        echo '</ol>';
        echo '</section>';
    }

    private function render_connection_technical_summary(array $bundle, bool $expanded): void {
        echo '<section class="lcfa-wizard__summary' . ($expanded ? '' : ' is-collapsed') . '">';
        if ($expanded) {
            $this->render_connection_bundle_details($bundle);
        } else {
            echo '<div class="lcfa-guide">';
            echo '<h3>' . esc_html__('Technical summary', 'livecanvas-forge-ai') . '</h3>';
            echo '<p class="lcfa-guide-copy">' . esc_html__('Bundle files, environment variables, and smoke test commands will appear here once you reach the generation step.', 'livecanvas-forge-ai') . '</p>';
            echo '</div>';
        }
        echo '</section>';
    }

    private function get_workspace_write_notice(array $workspace_state): string {
        $path = (string) ($workspace_state['path'] ?? '');
        $reason = (string) ($workspace_state['reason'] ?? 'unreachable');

        switch ($reason) {
            case 'missing':
                return __('Set a local workspace root first.', 'livecanvas-forge-ai');
            case 'runtime_only':
                return __('The current value points to a runtime mount such as /wordpress. Use the host-side project path instead.', 'livecanvas-forge-ai');
            case 'not_absolute':
                return __('Use an absolute host path for the local workspace root.', 'livecanvas-forge-ai');
            case 'not_writable':
                return sprintf(__('The browser runtime can see %s but cannot write there.', 'livecanvas-forge-ai'), $path);
            case 'unreachable':
            default:
                return sprintf(__('The browser runtime cannot reach %s. Use Download client bundle or let your coding agent create the file from the host machine.', 'livecanvas-forge-ai'), $path);
        }
    }

    private function render_connection_bundle_details(array $bundle): void {
        $is_claude_desktop = (string) ($bundle['client'] ?? '') === 'claude'
            && (string) ($bundle['claude_connection_target'] ?? '') === 'desktop_app';

        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('Generated bundle', 'livecanvas-forge-ai') . '</h3>';
        if ($is_claude_desktop) {
            echo '<p class="lcfa-guide-copy">' . esc_html__('For Claude Desktop, this JSON is a snippet. Merge livecanvas-forge into ~/Library/Application Support/Claude/claude_desktop_config.json under mcpServers. Do not paste it as a second top-level JSON object and do not replace your existing preferences block.', 'livecanvas-forge-ai') . '</p>';
        }
        echo '<div class="lcfa-agent-guide__bundle-layout">';

        echo '<div class="lcfa-agent-guide__window lcfa-agent-guide__window--files">';
        echo '<h3>' . esc_html__('Files', 'livecanvas-forge-ai') . '</h3>';
        if (!empty($bundle['workspace_files'])) {
            echo '<ul class="lcfa-bullets">';
            foreach ((array) $bundle['workspace_files'] as $file) {
                echo '<li><code>' . esc_html((string) ($file['path'] ?? '')) . '</code></li>';
            }
            echo '</ul>';
        } elseif (!empty($bundle['download_files'])) {
            echo '<ul class="lcfa-bullets">';
            foreach ((array) $bundle['download_files'] as $file) {
                echo '<li><code>' . esc_html((string) ($file['name'] ?? '')) . '</code></li>';
            }
            echo '</ul>';
        } else {
            echo '<p>' . esc_html__('This client currently uses copy or command-based setup.', 'livecanvas-forge-ai') . '</p>';
        }
        echo '</div>';

        echo '<div class="lcfa-agent-guide__panel-grid lcfa-agent-guide__panel-grid--bundle">';

        if (!empty($bundle['shortcut_command'])) {
            echo '<div class="lcfa-agent-guide__window">';
            echo '<h3>' . esc_html((string) ($bundle['shortcut_title'] ?? __('Shortcut', 'livecanvas-forge-ai'))) . '</h3>';
            if ($is_claude_desktop) {
                $this->render_claude_desktop_merge_guide();
                $this->render_code_block_explanation(__('Shows the JSON snippet that must be merged into Claude Desktop config. It does not replace the whole file; it only adds the livecanvas-forge MCP server under mcpServers.', 'livecanvas-forge-ai'));
            } elseif ((string) ($bundle['client'] ?? '') === 'codex') {
                $this->render_code_block_explanation(__('Registers livecanvas-forge inside Codex, so Codex can call the AI Bridge MCP server for this WordPress site. Run it once from the project root after generating the bundle; if Codex was already open, reopen it before the smoke test.', 'livecanvas-forge-ai'));
            } else {
                $this->render_code_block_explanation(__('Creates or runs the setup shortcut for the selected coding agent. Use it to register livecanvas-forge with the agent without manually rebuilding the raw MCP command.', 'livecanvas-forge-ai'));
            }
            $this->render_code_block((string) $bundle['shortcut_command'], [
                'language'   => $is_claude_desktop ? 'json' : 'bash',
                'label'      => $is_claude_desktop ? __('JSON', 'livecanvas-forge-ai') : __('Shell', 'livecanvas-forge-ai'),
                'copy_label' => $is_claude_desktop ? __('Copy config', 'livecanvas-forge-ai') : __('Copy shortcut', 'livecanvas-forge-ai'),
            ]);
            echo '</div>';
        }

        echo '<div class="lcfa-agent-guide__window">';
        echo '<h3>' . esc_html__('Server command', 'livecanvas-forge-ai') . '</h3>';
        $this->render_code_block_explanation(__('Shows the raw MCP server command the coding agent runs behind the scenes. Use it for manual MCP setup or diagnostics when the shortcut or generated config is not enough.', 'livecanvas-forge-ai'));
        $this->render_code_block((string) ($bundle['command_string'] ?? ''), [
            'language'   => 'bash',
            'label'      => __('Shell', 'livecanvas-forge-ai'),
            'copy_label' => __('Copy command', 'livecanvas-forge-ai'),
        ]);
        echo '</div>';

        echo '<div class="lcfa-agent-guide__window">';
        echo '<h3>' . esc_html__('Environment variables', 'livecanvas-forge-ai') . '</h3>';
        $this->render_code_block_explanation(__('Defines the REST endpoint, token, site URL, and local project root passed to the MCP server. These values must match this WordPress install, otherwise the agent can connect to the wrong site or fail authorization.', 'livecanvas-forge-ai'));
        $this->render_code_block($this->build_environment_block((array) ($bundle['environment'] ?? [])), [
            'language'   => 'bash',
            'label'      => __('Environment', 'livecanvas-forge-ai'),
            'copy_label' => __('Copy env', 'livecanvas-forge-ai'),
        ]);
        echo '</div>';

        echo '<div class="lcfa-agent-guide__window">';
        echo '<h3>' . esc_html__('Smoke test', 'livecanvas-forge-ai') . '</h3>';
        $this->render_code_block_explanation(__('Runs get_snapshot and confirms the MCP bridge can reach WordPress before page edits. If this command fails, AI Bridge can show setup data but the coding agent is not ready to execute changes.', 'livecanvas-forge-ai'));
        $this->render_code_block((string) ($bundle['smoke_test_command'] ?? ''), [
            'language'   => 'bash',
            'label'      => __('Shell', 'livecanvas-forge-ai'),
            'copy_label' => __('Copy smoke test', 'livecanvas-forge-ai'),
        ]);
        echo '</div>';

        if (!empty($bundle['agent_start_prompt'])) {
            echo '<div class="lcfa-agent-guide__window">';
            echo '<h3>' . esc_html__('First agent prompt', 'livecanvas-forge-ai') . '</h3>';
            $this->render_code_block_explanation(__('Send this to the connected coding agent after the MCP server is visible. It asks the agent to fetch the lightweight connection handoff, inspect current guardrails, and stay read-only before reviewed previews.', 'livecanvas-forge-ai'));
            $this->render_code_block((string) $bundle['agent_start_prompt'], [
                'language'   => 'text',
                'label'      => __('Prompt', 'livecanvas-forge-ai'),
                'copy_label' => __('Copy prompt', 'livecanvas-forge-ai'),
            ]);
            echo '</div>';
        }

        echo '</div>';
        echo '</div>';
        echo '</details>';
    }

    private function render_remote_companion_card(array $remote_status): void {
        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('cloud');
        echo '<div><h2>' . esc_html__('Advanced remote target', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Use this only when the agent should target another WordPress site through the legacy remote companion. The main Codex Direct Mode above now uses secure AI Bridge pairing without copying WordPress credentials into Codex.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';
        echo '<div class="lcfa-chip-row">';
        echo '<span class="lcfa-chip' . (!empty($remote_status['available']) ? ' is-positive' : (!empty($remote_status['configured']) ? ' is-negative' : '')) . '">' . esc_html(!empty($remote_status['available']) ? __('Remote ready', 'livecanvas-forge-ai') : (!empty($remote_status['configured']) ? __('Configured but failing', 'livecanvas-forge-ai') : __('Not configured', 'livecanvas-forge-ai'))) . '</span>';
        if (!empty($remote_status['snapshot']['framework'])) {
            echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Framework: %s', 'livecanvas-forge-ai'), (string) $remote_status['snapshot']['framework'])) . '</span>';
        }
        if (!empty($remote_status['mcp']['token'])) {
            echo '<span class="lcfa-chip is-positive">' . esc_html__('Remote MCP token available', 'livecanvas-forge-ai') . '</span>';
        }
        if (!empty($remote_status['mcp_adapter']['available'])) {
            echo '<span class="lcfa-chip is-positive">' . esc_html__('WordPress MCP Adapter ready', 'livecanvas-forge-ai') . '</span>';
        } elseif (!empty($remote_status['available'])) {
            echo '<span class="lcfa-chip">' . esc_html__('MCP Adapter not detected', 'livecanvas-forge-ai') . '</span>';
        }
        echo '</div>';
        echo '<p class="lcfa-guide-copy">' . esc_html((string) ($remote_status['message'] ?? '')) . '</p>';
        if (!empty($remote_status['endpoint'])) {
            echo '<p><code>' . esc_html((string) $remote_status['endpoint']) . '</code></p>';
        }
        if (!empty($remote_status['mcp_adapter']['custom_server']['url'])) {
            echo '<p><code>' . esc_html((string) $remote_status['mcp_adapter']['custom_server']['url']) . '</code></p>';
        }
        echo '</section>';
    }

    private function get_ability_diagnostics_for_admin(): array {
        if ($this->ability_registry instanceof LCFA_Ability_Registry) {
            return $this->ability_registry->get_ability_diagnostics();
        }

        $mcp_adapter = method_exists($this->environment, 'get_mcp_adapter_status')
            ? $this->environment->get_mcp_adapter_status()
            : [];

        return [
            'ability_diagnostics' => [
                'total'                => 0,
                'mcp_public_total'     => 0,
                'mcp_public'           => [],
                'mcp_public_preview'   => [],
                'mcp_public_write'     => [],
                'has_mcp_public_write' => false,
                'mcp_write_opt_in_enabled' => false,
                'mcp_write_allowlist'  => [],
                'mcp_write_available'  => array_keys(LCFA_Settings::get_mcp_write_ability_options()),
                'items'                => [],
            ],
            'mcp_adapter' => $mcp_adapter,
            'ai_client' => [
                'available' => false,
                'text_generation_supported' => false,
                'connectors' => [
                    'available' => false,
                    'count' => 0,
                    'text_generation_count' => 0,
                ],
            ],
        ];
    }

    private function render_ability_diagnostics_card(array $diagnostics): void {
        $ability = is_array($diagnostics['ability_diagnostics'] ?? null) ? $diagnostics['ability_diagnostics'] : [];
        $adapter = is_array($diagnostics['mcp_adapter'] ?? null) ? $diagnostics['mcp_adapter'] : [];
        $ai_client = is_array($diagnostics['ai_client'] ?? null) ? $diagnostics['ai_client'] : [];
        $connectors = is_array($ai_client['connectors'] ?? null) ? $ai_client['connectors'] : [];
        $public_preview = is_array($ability['mcp_public_preview'] ?? null) ? $ability['mcp_public_preview'] : [];
        $public_write = is_array($ability['mcp_public_write'] ?? null) ? $ability['mcp_public_write'] : [];
        $write_allowlist = is_array($ability['mcp_write_allowlist'] ?? null) ? $ability['mcp_write_allowlist'] : [];

        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('sparkles');
        echo '<div><h2>' . esc_html__('Ability diagnostics', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Shows the WordPress-native ability surface exposed to MCP-capable agents. Preview abilities are safe dry-run entry points; curated write abilities are enabled by default and should be reviewed before trusting an agent.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<div class="lcfa-chip-row">';
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Abilities: %d', 'livecanvas-forge-ai'), (int) ($ability['total'] ?? 0))) . '</span>';
        echo '<span class="lcfa-chip is-positive">' . esc_html(sprintf(__('MCP public: %d', 'livecanvas-forge-ai'), (int) ($ability['mcp_public_total'] ?? 0))) . '</span>';
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Preview public: %d', 'livecanvas-forge-ai'), count($public_preview))) . '</span>';
        echo '<span class="lcfa-chip' . (!empty($ability['has_mcp_public_write']) ? ' is-negative' : ' is-positive') . '">' . esc_html(!empty($ability['has_mcp_public_write']) ? __('Write exposed', 'livecanvas-forge-ai') : __('No public write abilities', 'livecanvas-forge-ai')) . '</span>';
        echo '<span class="lcfa-chip' . (!empty($ability['mcp_write_opt_in_enabled']) ? ' is-warning' : '') . '">' . esc_html(!empty($ability['mcp_write_opt_in_enabled']) ? __('Write opt-in enabled', 'livecanvas-forge-ai') : __('Write opt-in disabled', 'livecanvas-forge-ai')) . '</span>';
        echo '<span class="lcfa-chip' . (!empty($adapter['available']) ? ' is-positive' : '') . '">' . esc_html(!empty($adapter['available']) ? __('MCP Adapter ready', 'livecanvas-forge-ai') : __('MCP Adapter not detected', 'livecanvas-forge-ai')) . '</span>';
        echo '<span class="lcfa-chip' . (!empty($ai_client['text_generation_supported']) ? ' is-positive' : '') . '">' . esc_html(!empty($ai_client['text_generation_supported']) ? __('AI text ready', 'livecanvas-forge-ai') : __('AI text unavailable', 'livecanvas-forge-ai')) . '</span>';
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Connectors: %d', 'livecanvas-forge-ai'), (int) ($connectors['count'] ?? 0))) . '</span>';
        echo '</div>';

        if (!empty($adapter['custom_server']['url'])) {
            echo '<p><code>' . esc_html((string) $adapter['custom_server']['url']) . '</code></p>';
        }

        if ($public_preview) {
            echo '<div class="lcfa-guide">';
            echo '<h3>' . esc_html__('Public preview abilities', 'livecanvas-forge-ai') . '</h3>';
            echo '<ul class="lcfa-check-list">';
            foreach ($public_preview as $ability_name) {
                echo '<li><code>' . esc_html((string) $ability_name) . '</code></li>';
            }
            echo '</ul>';
            echo '</div>';
        }

        if ($public_write) {
            echo '<div class="lcfa-notice lcfa-notice--warning">';
            echo '<strong>' . esc_html__('Review MCP write exposure', 'livecanvas-forge-ai') . '</strong>';
            echo '<p>' . esc_html__('At least one destructive ability is public to MCP. Keep this disabled unless the site owner explicitly opted into write-capable remote agents.', 'livecanvas-forge-ai') . '</p>';
            echo '<ul class="lcfa-check-list">';
            foreach ($public_write as $ability_name) {
                echo '<li><code>' . esc_html((string) $ability_name) . '</code></li>';
            }
            echo '</ul>';
            echo '</div>';
        } elseif (!empty($ability['mcp_write_opt_in_enabled']) && $write_allowlist === []) {
            echo '<div class="lcfa-guide">';
            echo '<h3>' . esc_html__('Write opt-in is enabled with no allowed write abilities', 'livecanvas-forge-ai') . '</h3>';
            echo '<p>' . esc_html__('The MCP write master switch is on, but the per-ability allowlist is empty, so no destructive ability is public.', 'livecanvas-forge-ai') . '</p>';
            echo '</div>';
        }

        echo '</section>';
    }

    private function render_advanced_connection_settings(array $connections, string $preferred_client, array $mcp_status, array $preferred_bootstrap, string $common_bootstrap, string $command_example, string $workspace_root): void {
        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('plug');
        echo '<div><h2>' . esc_html__('Advanced settings', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('These are the low-level controls behind the wizard. You only need them when you want to override transport details, remote companion credentials, or package sources manually.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';
        echo '<details class="lcfa-advanced-settings">';
        echo '<summary>' . esc_html__('Show advanced settings', 'livecanvas-forge-ai') . '</summary>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form">';
        wp_nonce_field('lcfa_connections');
        echo '<input type="hidden" name="action" value="lcfa_connections">';
        echo '<input type="hidden" name="preferred_client" value="' . esc_attr($preferred_client) . '">';
        echo '<input type="hidden" name="connection_mode" value="' . esc_attr((string) ($connections['connection_mode'] ?: ($preferred_client === 'codex' ? 'remote' : 'local'))) . '">';
        echo '<input type="hidden" name="workspace_root" value="' . esc_attr($workspace_root) . '">';

        echo '<label><span>' . esc_html__('Preferred transport', 'livecanvas-forge-ai') . '</span>';
        echo '<select name="transport">';
        echo '<option value="rest"' . selected($connections['transport'], 'rest', false) . '>' . esc_html__('REST first', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="mcp"' . selected($connections['transport'], 'mcp', false) . '>' . esc_html__('MCP first', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="hybrid"' . selected($connections['transport'], 'hybrid', false) . '>' . esc_html__('Hybrid', 'livecanvas-forge-ai') . '</option>';
        echo '</select></label>';

        echo '<label><span>' . esc_html__('Picowind package URL', 'livecanvas-forge-ai') . '</span><input type="text" name="picowind_package_url" value="' . esc_attr($connections['picowind_package_url']) . '" placeholder="https://...zip"></label>';
        echo '<label><span>' . esc_html__('Picostrap package URL', 'livecanvas-forge-ai') . '</span><input type="text" name="picostrap_package_url" value="' . esc_attr($connections['picostrap_package_url']) . '" placeholder="https://...zip"></label>';
        echo '<label><span>' . esc_html__('Local bridge URL', 'livecanvas-forge-ai') . '</span><input type="text" name="local_bridge_url" value="' . esc_attr($connections['local_bridge_url']) . '"></label>';
        echo '<label class="lcfa-checkbox"><input type="checkbox" name="mcp_enabled" value="1"' . checked((bool) $connections['mcp_enabled'], true, false) . '> ' . esc_html__('Enable the built-in MCP bridge profile for local tooling.', 'livecanvas-forge-ai') . '</label>';
        echo '<div class="lcfa-notice lcfa-notice--warning">';
        echo '<strong>' . esc_html__('Write abilities are enabled by default', 'livecanvas-forge-ai') . '</strong>';
        echo '<p>' . esc_html__('AI Bridge exposes the curated write allowlist so a paired agent can create and update LiveCanvas content after previews. Disable the master switch or uncheck individual abilities when you want read/preview-only access.', 'livecanvas-forge-ai') . '</p>';
        echo '</div>';
        echo '<label class="lcfa-checkbox"><input type="checkbox" name="mcp_write_abilities_enabled" value="1"' . checked(!empty($connections['mcp_write_abilities_enabled']), true, false) . '> ' . esc_html__('Expose curated write abilities through the AI Bridge MCP server.', 'livecanvas-forge-ai') . '</label>';
        echo '<p class="description">' . esc_html__('Leave enabled for trusted paired agents. Turn it off when the connected MCP client should only inspect and preview.', 'livecanvas-forge-ai') . '</p>';
        echo '<input type="hidden" name="mcp_public_write_abilities_submitted" value="1">';
        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('MCP write ability allowlist', 'livecanvas-forge-ai') . '</h3>';
        echo '<p>' . esc_html__('Select the destructive abilities that may become MCP-public when the master write opt-in above is enabled. Leave all unchecked to expose no write abilities.', 'livecanvas-forge-ai') . '</p>';
        $selected_write_abilities = LCFA_Settings::sanitize_mcp_write_abilities($connections['mcp_public_write_abilities'] ?? []);
        foreach (LCFA_Settings::get_mcp_write_ability_options() as $ability_name => $ability_data) {
            echo '<label class="lcfa-checkbox"><input type="checkbox" name="mcp_public_write_abilities[]" value="' . esc_attr((string) $ability_name) . '"' . checked(in_array((string) $ability_name, $selected_write_abilities, true), true, false) . '> ';
            echo '<span><strong>' . esc_html((string) ($ability_data['label'] ?? $ability_name)) . '</strong> <code>' . esc_html((string) $ability_name) . '</code><br><small>' . esc_html((string) ($ability_data['description'] ?? '')) . '</small></span>';
            echo '</label>';
        }
        echo '</div>';
        echo '<label><span>' . esc_html__('MCP host', 'livecanvas-forge-ai') . '</span><input type="text" name="mcp_host" value="' . esc_attr($connections['mcp_host']) . '" placeholder="127.0.0.1"></label>';
        echo '<label><span>' . esc_html__('MCP port', 'livecanvas-forge-ai') . '</span><input type="text" name="mcp_port" value="' . esc_attr($connections['mcp_port']) . '" placeholder="7681"></label>';
        echo '<label><span>' . esc_html__('Remote site URL', 'livecanvas-forge-ai') . '</span><input type="text" name="remote_site_url" value="' . esc_attr($connections['remote_site_url']) . '" placeholder="https://example.com"></label>';
        echo '<label><span>' . esc_html__('Remote username', 'livecanvas-forge-ai') . '</span><input type="text" name="remote_username" value="' . esc_attr($connections['remote_username']) . '"></label>';
        echo '<label><span>' . esc_html__('Remote application password', 'livecanvas-forge-ai') . '</span><input type="password" name="remote_application_password" value="" placeholder="' . esc_attr($connections['remote_application_password'] !== '' ? __('Stored. Leave blank to keep current value.', 'livecanvas-forge-ai') : __('xxxx xxxx xxxx xxxx xxxx xxxx', 'livecanvas-forge-ai')) . '"></label>';
        echo '<label><span>' . esc_html__('MCP server command', 'livecanvas-forge-ai') . '</span><textarea name="mcp_server_command" rows="4" placeholder="npx @livecanvas/forge-mcp">' . esc_textarea($connections['mcp_server_command']) . '</textarea></label>';

        $update_channel = sanitize_key((string) get_option('lcfa_update_channel', str_contains((string) LCFA_VERSION, '-') ? 'beta' : 'stable'));
        if (!in_array($update_channel, ['stable', 'beta'], true)) {
            $update_channel = 'stable';
        }
        echo '<label><span>' . esc_html__('AI Bridge update channel', 'livecanvas-forge-ai') . '</span><select name="lcfa_update_channel">';
        echo '<option value="stable"' . selected($update_channel, 'stable', false) . '>' . esc_html__('Stable releases only', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="beta"' . selected($update_channel, 'beta', false) . '>' . esc_html__('Beta and stable releases', 'livecanvas-forge-ai') . '</option>';
        echo '</select></label>';
        echo '<p class="description">' . esc_html__('Stable installations ignore prereleases until an administrator explicitly opts into the beta channel.', 'livecanvas-forge-ai') . '</p>';

        $power_mode = LCFA_Settings::sanitize_power_mode((string) ($connections['power_mode'] ?? 'auto'));
        echo '<label><span>' . esc_html__('Power Mode policy', 'livecanvas-forge-ai') . '</span><select name="power_mode">';
        foreach (LCFA_Settings::get_power_mode_options() as $value => $label) {
            echo '<option value="' . esc_attr((string) $value) . '"' . selected((string) $value, $power_mode, false) . '>' . esc_html((string) $label) . '</option>';
        }
        echo '</select></label>';
        echo '<p class="description">' . esc_html__('Power Mode prepares advanced filesystem, WP-CLI, upload, admin-link, and sandbox tools. In auto mode it is available only for trusted local/development sites and remains off for remote/staging/production.', 'livecanvas-forge-ai') . '</p>';

        if ($preferred_client === 'codex') {
            $codex_defaults = LCFA_Settings::sanitize_codex_options([
                'model'            => $connections['codex_model'] ?? '',
                'speed'            => $connections['codex_speed'] ?? '',
                'reasoning_effort' => $connections['codex_reasoning_effort'] ?? '',
                'sandbox'          => $connections['codex_sandbox'] ?? '',
            ]);
            echo '<div class="lcfa-guide">';
            echo '<h3>' . esc_html__('Codex defaults', 'livecanvas-forge-ai') . '</h3>';
            echo '<p>' . esc_html__('These defaults are used by frontend LiveCanvas prompts before each run. The drawer can still override them for a single request.', 'livecanvas-forge-ai') . '</p>';
            echo '<label><span>' . esc_html__('Default model', 'livecanvas-forge-ai') . '</span><select name="codex_model">';
            foreach (LCFA_Settings::get_codex_model_options() as $value => $label) {
                echo '<option value="' . esc_attr((string) $value) . '"' . selected((string) $value, $codex_defaults['model'], false) . '>' . esc_html((string) $label) . '</option>';
            }
            echo '</select></label>';
            echo '<label><span>' . esc_html__('Default speed', 'livecanvas-forge-ai') . '</span><select name="codex_speed">';
            foreach (LCFA_Settings::get_codex_speed_options() as $value => $label) {
                echo '<option value="' . esc_attr((string) $value) . '"' . selected((string) $value, $codex_defaults['speed'], false) . '>' . esc_html((string) $label) . '</option>';
            }
            echo '</select></label>';
            echo '<label><span>' . esc_html__('Default intelligence', 'livecanvas-forge-ai') . '</span><select name="codex_reasoning_effort">';
            foreach (LCFA_Settings::get_codex_reasoning_effort_options() as $value => $label) {
                echo '<option value="' . esc_attr((string) $value) . '"' . selected((string) $value, $codex_defaults['reasoning_effort'], false) . '>' . esc_html((string) $label) . '</option>';
            }
            echo '</select></label>';
            echo '<label><span>' . esc_html__('Default sandbox', 'livecanvas-forge-ai') . '</span><select name="codex_sandbox">';
            foreach (LCFA_Settings::get_codex_sandbox_options() as $value => $label) {
                echo '<option value="' . esc_attr((string) $value) . '"' . selected((string) $value, $codex_defaults['sandbox'], false) . '>' . esc_html((string) $label) . '</option>';
            }
            echo '</select></label>';
            echo '</div>';
        }

        echo '<div class="lcfa-cta-row">';
        echo '<button class="button button-primary" type="submit">' . esc_html__('Save advanced settings', 'livecanvas-forge-ai') . '</button>';
        echo '<button class="button" type="submit" name="rotate_mcp_token" value="1">' . esc_html__('Rotate MCP token', 'livecanvas-forge-ai') . '</button>';
        echo '</div>';
        echo '</form>';

        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('Connection checks', 'livecanvas-forge-ai') . '</h3>';
        echo '<p>' . esc_html__('Run live checks against the local bridge, the local MCP runtime, and the configured remote site credentials.', 'livecanvas-forge-ai') . '</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
        wp_nonce_field('lcfa_test_connections');
        echo '<input type="hidden" name="action" value="lcfa_test_connections">';
        echo '<button class="button" type="submit">' . esc_html__('Run connection checks', 'livecanvas-forge-ai') . '</button>';
        echo '</form>';
        echo '</div>';

        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('MCP bootstrap', 'livecanvas-forge-ai') . '</h3>';
        echo '<ul class="lcfa-bullets">';
        echo '<li>' . esc_html(sprintf(__('REST base: %s', 'livecanvas-forge-ai'), rest_url('lcfa/v1/'))) . '</li>';
        echo '<li>' . esc_html(sprintf(__('MCP endpoint: %s', 'livecanvas-forge-ai'), (string) ($mcp_status['endpoint'] ?? ''))) . '</li>';
        echo '<li>' . esc_html__('Execution endpoints: /command/actions, /command/suggest, /command, /mcp/health, /mcp/status, /mcp/local-status, /mcp/bootstrap.', 'livecanvas-forge-ai') . '</li>';
        echo '</ul>';
        $this->render_code_block($common_bootstrap, [
            'language'   => 'bash',
            'label'      => __('Shell', 'livecanvas-forge-ai'),
            'copy_label' => __('Copy bootstrap', 'livecanvas-forge-ai'),
        ]);
        echo '</div>';

        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('Preferred client bootstrap', 'livecanvas-forge-ai') . '</h3>';
        $this->render_code_block((string) ($preferred_bootstrap['command'] ?? '') . "\n\n" . implode("\n", (array) ($preferred_bootstrap['env'] ?? [])), [
            'language'   => 'bash',
            'label'      => __('Shell', 'livecanvas-forge-ai'),
            'copy_label' => __('Copy client bootstrap', 'livecanvas-forge-ai'),
        ]);
        echo '</div>';

        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('Example command request', 'livecanvas-forge-ai') . '</h3>';
        $this->render_code_block("POST " . rest_url('lcfa/v1/command') . "\nContent-Type: application/json\n\n" . $command_example, [
            'language'   => 'bash',
            'label'      => __('HTTP', 'livecanvas-forge-ai'),
            'copy_label' => __('Copy request', 'livecanvas-forge-ai'),
        ]);
        echo '</div>';

        echo '</details>';
        echo '</section>';
    }

    private function render_agent_connection_guide(array $mcp_bootstrap, array $settings, array $snapshot, string $preferred_client, array $mcp_status, bool $is_wizard_context = false): void {
        $guides        = $this->get_agent_connection_guides($mcp_bootstrap, $settings, $snapshot);
        $selected_key  = $preferred_client === 'other'
            ? 'generic'
            : ($preferred_client === 'claude-code'
                ? 'claude'
                : (isset($guides[$preferred_client]) ? $preferred_client : 'codex'));
        $selected_claude_mode = $this->normalize_claude_connection_target((string) ($settings['claude_connection_target'] ?? ''));
        if ($selected_claude_mode === '') {
            $selected_claude_mode = 'desktop_app';
        }
        $local_bridge  = is_array($mcp_status['local_bridge'] ?? null) ? $mcp_status['local_bridge'] : [];
        $local_bridge_deferred = !empty($local_bridge['deferred']);
        $local_bridge_ready = !$local_bridge_deferred && !empty($local_bridge['available']);
        $site_mode     = (string) (($settings['site_mode'] ?? '') ?: ($snapshot['site_mode'] ?? 'local'));
        $filesystem_mode = (string) ($mcp_status['filesystem_mode'] ?? '');
        $selected_guide = is_array($guides[$selected_key] ?? null) ? $guides[$selected_key] : [];
        $selected_label = (string) ($selected_guide['label'] ?? ucfirst($selected_key));

        if ($is_wizard_context) {
            echo '<details class="lcfa-agent-setup-details">';
            echo '<summary>';
            echo $this->get_icon_svg('command');
            echo '<span><strong>' . esc_html(sprintf(__('Manual %s setup', 'livecanvas-forge-ai'), $selected_label)) . '</strong><small>' . esc_html__('Open only if the coding agent cannot see the AI Bridge tools.', 'livecanvas-forge-ai') . '</small></span>';
            echo '</summary>';
            echo '<div class="lcfa-agent-setup-details__body">';
        } else {
            echo '<section class="lcfa-card">';
            echo '<div class="lcfa-card-head">';
            echo $this->get_icon_svg('stars');
            echo '<div><h2>' . esc_html__('Client quickstart details', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('These quickstart guides are written in English on purpose. Pick your client to review the exact command, environment, and smoke test generated by the plugin.', 'livecanvas-forge-ai') . '</p></div>';
            echo '</div>';
        }

        echo '<dl class="lcfa-runtime-facts">';
        echo '<div><dt>' . esc_html__('Site', 'livecanvas-forge-ai') . '</dt><dd>' . esc_html(ucfirst($site_mode)) . '</dd></div>';
        echo '<div><dt>' . esc_html__('File access', 'livecanvas-forge-ai') . '</dt><dd>' . esc_html($filesystem_mode ?: __('Not available', 'livecanvas-forge-ai')) . '</dd></div>';
        echo '<div><dt>' . esc_html__('Local bridge', 'livecanvas-forge-ai') . '</dt><dd class="' . esc_attr($local_bridge_ready ? 'is-positive' : ($local_bridge_deferred ? 'is-pending' : 'is-warning')) . '"><span class="lcfa-status-dot" aria-hidden="true"></span>' . esc_html($local_bridge_deferred ? __('Checking', 'livecanvas-forge-ai') : ($local_bridge_ready ? __('Ready', 'livecanvas-forge-ai') : __('Not ready', 'livecanvas-forge-ai'))) . '</dd></div>';
        echo '</dl>';

        $guide_notice = in_array($site_mode, ['remote', 'hybrid'], true)
            ? __('Remote agents use secure site-bound pairing. No WordPress password or legacy MCP token belongs in the generated client configuration.', 'livecanvas-forge-ai')
            : ($is_wizard_context
                ? __('The local runtime may use the site MCP token. Treat raw commands and environment values as advanced reference material.', 'livecanvas-forge-ai')
                : __('Local MCP tokens are only for trusted local runtimes. Remote agents should use secure site-bound pairing.', 'livecanvas-forge-ai'));
        echo '<div class="lcfa-agent-guide__notice">' . $this->get_icon_svg('shield-lock') . '<p>' . esc_html($guide_notice) . '</p></div>';

        if ($is_wizard_context) {
            echo '<div class="lcfa-agent-guide lcfa-agent-guide--single">';
            echo '<section class="lcfa-agent-guide__panel is-current">';
            if (!empty($selected_guide['intro'])) {
                echo '<p class="lcfa-agent-guide__intro">' . esc_html((string) $selected_guide['intro']) . '</p>';
            }
            if (!empty($selected_guide['modes']) && is_array($selected_guide['modes'])) {
                $this->render_agent_connection_mode_switcher($selected_key, $selected_guide, $selected_claude_mode);
            } else {
                $this->render_agent_connection_windows($selected_guide);
            }
            echo '</section>';
            echo '</div>';
            echo '</div>';
            echo '</details>';
            return;
        }

        echo '<div class="lcfa-agent-guide">';
        foreach ($guides as $key => $guide) {
            $input_id = 'lcfa-agent-tab-' . $this->sanitize_key_compat($key);
            echo '<input class="lcfa-agent-guide__input" type="radio" name="lcfa_agent_tab" id="' . esc_attr($input_id) . '"' . checked($selected_key, $key, false) . '>';
        }

        echo '<div class="lcfa-agent-guide__tabs" role="tablist" aria-label="' . esc_attr__('Coding agent quickstart tabs', 'livecanvas-forge-ai') . '">';
        foreach ($guides as $key => $guide) {
            $input_id = 'lcfa-agent-tab-' . $this->sanitize_key_compat($key);
            echo '<label class="lcfa-agent-guide__tab" for="' . esc_attr($input_id) . '" role="tab">' . $this->get_agent_icon_markup($key, $this->get_client_fallback_icon($key), 'lcfa-agent-icon lcfa-agent-icon--tab') . '<span>' . esc_html($guide['label']) . '</span></label>';
        }
        echo '</div>';

        echo '<div class="lcfa-agent-guide__panels">';
        foreach ($guides as $key => $guide) {
            echo '<section class="lcfa-agent-guide__panel lcfa-agent-guide__panel--' . esc_attr(sanitize_html_class($key)) . '">';
            echo '<p class="lcfa-agent-guide__intro">' . esc_html($guide['intro']) . '</p>';
            if (!empty($guide['modes']) && is_array($guide['modes'])) {
                $this->render_agent_connection_mode_switcher($key, $guide, $selected_claude_mode);
            } else {
                $this->render_agent_connection_windows($guide);
            }
            echo '</section>';
        }
        echo '</div>';
        echo '</div>';
        echo '</section>';
    }

    private function render_agent_connection_mode_switcher(string $client_key, array $guide, string $selected_mode): void {
        $modes = is_array($guide['modes'] ?? null) ? $guide['modes'] : [];
        if ($modes === []) {
            $this->render_agent_connection_windows($guide);
            return;
        }

        if (!isset($modes[$selected_mode])) {
            $selected_mode = (string) array_key_first($modes);
        }

        foreach ($modes as $mode_key => $mode_guide) {
            $input_id = 'lcfa-agent-' . $this->sanitize_key_compat($client_key) . '-mode-' . $this->sanitize_key_compat((string) $mode_key);
            echo '<input class="lcfa-agent-guide__input" type="radio" name="lcfa_agent_' . esc_attr($this->sanitize_key_compat($client_key)) . '_mode" id="' . esc_attr($input_id) . '"' . checked($selected_mode, $mode_key, false) . '>';
        }

        echo '<div class="lcfa-agent-guide__subtabs" role="tablist" aria-label="' . esc_attr__('Claude connection target', 'livecanvas-forge-ai') . '">';
        foreach ($modes as $mode_key => $mode_guide) {
            $input_id = 'lcfa-agent-' . $this->sanitize_key_compat($client_key) . '-mode-' . $this->sanitize_key_compat((string) $mode_key);
            echo '<label class="lcfa-agent-guide__subtab" for="' . esc_attr($input_id) . '" role="tab">' . esc_html((string) ($mode_guide['label'] ?? $mode_key)) . '</label>';
        }
        echo '</div>';

        echo '<div class="lcfa-agent-guide__subpanels">';
        foreach ($modes as $mode_key => $mode_guide) {
            echo '<section class="lcfa-agent-guide__subpanel lcfa-agent-guide__subpanel--' . esc_attr(sanitize_html_class($client_key . '-' . $mode_key)) . '">';
            if (!empty($mode_guide['summary'])) {
                echo '<p class="lcfa-agent-guide__mode-copy">' . esc_html((string) $mode_guide['summary']) . '</p>';
            }
            $this->render_agent_connection_windows($mode_guide);
            echo '</section>';
        }
        echo '</div>';
    }

    private function render_agent_connection_windows(array $guide): void {
        $is_claude_desktop = (string) ($guide['mode_key'] ?? '') === 'desktop_app';

        echo '<div class="lcfa-agent-guide__panel-grid">';

        echo '<div class="lcfa-agent-guide__window">';
        echo '<h3>' . esc_html__('Step-by-step', 'livecanvas-forge-ai') . '</h3>';
        echo '<ol class="lcfa-agent-guide__steps">';
        foreach ((array) ($guide['steps'] ?? []) as $step) {
            echo '<li>' . esc_html((string) $step) . '</li>';
        }
        echo '</ol>';
        if (!empty($guide['note'])) {
            echo '<p class="lcfa-agent-guide__note">' . esc_html((string) $guide['note']) . '</p>';
        }
        echo '</div>';

        if (!empty($guide['shortcut_title']) && !empty($guide['shortcut'])) {
            echo '<div class="lcfa-agent-guide__window">';
            echo '<h3>' . esc_html((string) $guide['shortcut_title']) . '</h3>';
            if ($is_claude_desktop) {
                $this->render_claude_desktop_merge_guide();
            }
            $this->render_code_block((string) $guide['shortcut'], [
                'language'   => $is_claude_desktop ? 'json' : 'bash',
                'label'      => $is_claude_desktop ? __('JSON', 'livecanvas-forge-ai') : __('Shell', 'livecanvas-forge-ai'),
                'copy_label' => $is_claude_desktop ? __('Copy config', 'livecanvas-forge-ai') : __('Copy shortcut', 'livecanvas-forge-ai'),
            ]);
            echo '</div>';
        }

        echo '<div class="lcfa-agent-guide__window">';
        echo '<h3>' . esc_html__('Server command', 'livecanvas-forge-ai') . '</h3>';
        $this->render_code_block((string) ($guide['command'] ?? ''), [
            'language'   => 'bash',
            'label'      => __('Shell', 'livecanvas-forge-ai'),
            'copy_label' => __('Copy command', 'livecanvas-forge-ai'),
        ]);
        echo '</div>';

        echo '<div class="lcfa-agent-guide__window">';
        echo '<h3>' . esc_html__('Environment variables', 'livecanvas-forge-ai') . '</h3>';
        $this->render_code_block((string) ($guide['environment'] ?? ''), [
            'language'   => 'bash',
            'label'      => __('Environment', 'livecanvas-forge-ai'),
            'copy_label' => __('Copy env', 'livecanvas-forge-ai'),
        ]);
        echo '</div>';

        echo '<div class="lcfa-agent-guide__window">';
        echo '<h3>' . esc_html__('Quick terminal test', 'livecanvas-forge-ai') . '</h3>';
        $this->render_code_block((string) ($guide['test_command'] ?? ''), [
            'language'   => 'bash',
            'label'      => __('Shell', 'livecanvas-forge-ai'),
            'copy_label' => __('Copy test command', 'livecanvas-forge-ai'),
        ]);
        echo '</div>';

        echo '</div>';
    }

    private function get_agent_connection_guides(array $mcp_bootstrap, array $settings, array $snapshot): array {
        $clients = is_array($mcp_bootstrap['clients'] ?? null) ? $mcp_bootstrap['clients'] : [];
        $common  = is_array($mcp_bootstrap['common'] ?? null) ? $mcp_bootstrap['common'] : [];
        $is_local_filesystem = (string) ($common['filesystem_mode'] ?? '') === 'local-theme-access';
        $site_mode = (string) (($settings['site_mode'] ?? '') ?: ($snapshot['site_mode'] ?? 'local'));
        $is_remote_site = in_array($site_mode, ['remote', 'hybrid'], true);
        $wp_root_note = $is_local_filesystem
            ? __('This site is detected as local, so keep LCFA_WP_ROOT in the environment if you want local file access and local build tools.', 'livecanvas-forge-ai')
            : __('This site is currently handled as remote. In most cases you can leave LCFA_WP_ROOT out of the client environment.', 'livecanvas-forge-ai');

        $codex = is_array($clients['codex'] ?? null) ? $clients['codex'] : ['command' => '', 'env' => []];
        $cursor = is_array($clients['cursor'] ?? null) ? $clients['cursor'] : $codex;
        $claude = is_array($clients['claude'] ?? null)
            ? $clients['claude']
            : (is_array($clients['claude-code'] ?? null) ? $clients['claude-code'] : $codex);
        $opencode = is_array($clients['opencode'] ?? null) ? $clients['opencode'] : $codex;
        $claude_desktop_shortcut_title = $is_remote_site
            ? __('Claude Desktop reference', 'livecanvas-forge-ai')
            : __('Claude Desktop config', 'livecanvas-forge-ai');
        $claude_desktop_shortcut = $is_remote_site
            ? $this->build_claude_desktop_reference_snippet($claude)
            : $this->build_claude_desktop_config_snippet($claude);

        return [
            'codex' => [
                'label'          => __('Codex', 'livecanvas-forge-ai'),
                'intro'          => __('Use this if Codex is your main coding agent. The easiest path is to register the MCP server once, then let Codex call the plugin tools from the current workspace.', 'livecanvas-forge-ai'),
                'steps'          => [
                    __('Open a terminal in the same workspace as your WordPress project.', 'livecanvas-forge-ai'),
                    __('Prefer a project .codex/config.toml for each WordPress project. The shortcut below can still register a global fallback.', 'livecanvas-forge-ai'),
                    __('Keep the server name as livecanvas-forge so it is easy to recognize later.', 'livecanvas-forge-ai'),
                    __('Restart Codex if needed, verify with codex mcp list or the embedded Codex CLI path, then call get_snapshot as your first tool check.', 'livecanvas-forge-ai'),
                ],
                'note'           => $wp_root_note,
                'shortcut_title' => __('Codex shortcut', 'livecanvas-forge-ai'),
                'shortcut'       => $this->build_codex_register_command($codex),
                'command'        => (string) ($codex['command'] ?? ''),
                'environment'    => $this->build_environment_block((array) ($codex['env'] ?? [])),
                'test_command'   => $this->build_manual_mcp_test_command((array) ($codex['env'] ?? [])),
            ],
            'cursor' => [
                'label'        => __('Cursor', 'livecanvas-forge-ai'),
                'intro'        => __('Use this if you want Cursor to discover the AI Bridge tools through MCP. Add one local stdio MCP server and keep the command and environment exactly as shown.', 'livecanvas-forge-ai'),
                'steps'        => [
                    __('Open the MCP server settings in Cursor.', 'livecanvas-forge-ai'),
                    __('Create a new local or stdio MCP server named livecanvas-forge.', 'livecanvas-forge-ai'),
                    __('Paste the server command and environment variables from this tab.', 'livecanvas-forge-ai'),
                    __('Save the server, reconnect it, and ask for get_snapshot to confirm that the bridge is live.', 'livecanvas-forge-ai'),
                ],
                'note'         => $wp_root_note,
                'command'      => (string) ($cursor['command'] ?? ''),
                'environment'  => $this->build_environment_block((array) ($cursor['env'] ?? [])),
                'test_command' => $this->build_manual_mcp_test_command((array) ($cursor['env'] ?? [])),
            ],
            'claude' => [
                'label' => __('Claude', 'livecanvas-forge-ai'),
                'intro' => __('Use this if Claude is your main agent. Choose whether you are connecting through Claude Desktop App or through the Command Line Interface.', 'livecanvas-forge-ai'),
                'modes' => [
                    'desktop_app' => [
                        'mode_key'       => 'desktop_app',
                        'label'          => __('Desktop App', 'livecanvas-forge-ai'),
                        'summary'        => $is_remote_site
                            ? __('Use this when Claude Desktop needs to reach a remote WordPress target. Review the reference block before editing the desktop config manually.', 'livecanvas-forge-ai')
                            : __('Use this when Claude Desktop is your main app. Merge the JSON block under mcpServers inside your existing Claude Desktop config, reopen the app, then verify the bridge with get_snapshot.', 'livecanvas-forge-ai'),
                        'steps'          => [
                            __('Open ~/Library/Application Support/Claude/claude_desktop_config.json on your machine.', 'livecanvas-forge-ai'),
                            __('Merge the JSON block under mcpServers inside your existing Claude Desktop config.', 'livecanvas-forge-ai'),
                            __('Do not paste it as a second top-level JSON object or replace your preferences block.', 'livecanvas-forge-ai'),
                            __('Quit and reopen Claude Desktop.', 'livecanvas-forge-ai'),
                            __('Ask Claude to run get_snapshot before requesting any writes.', 'livecanvas-forge-ai'),
                        ],
                        'note'           => $wp_root_note,
                        'shortcut_title' => $claude_desktop_shortcut_title,
                        'shortcut'       => $claude_desktop_shortcut,
                        'command'        => (string) ($claude['command'] ?? ''),
                        'environment'    => $this->build_environment_block((array) ($claude['env'] ?? [])),
                        'test_command'   => $this->build_manual_mcp_test_command((array) ($claude['env'] ?? [])),
                    ],
                    'cli' => [
                        'mode_key'       => 'cli',
                        'label'          => __('Command Line Interface', 'livecanvas-forge-ai'),
                        'summary'        => __('Use this when Claude runs from the terminal. Register the MCP server once, verify it, then keep working from the same project root.', 'livecanvas-forge-ai'),
                        'steps'          => [
                            __('Open a terminal in the same workspace as your WordPress project.', 'livecanvas-forge-ai'),
                            __('Run the Claude CLI shortcut below.', 'livecanvas-forge-ai'),
                            __('Verify the MCP registration with claude mcp list.', 'livecanvas-forge-ai'),
                            __('Run get_snapshot before requesting any writes.', 'livecanvas-forge-ai'),
                        ],
                        'note'           => $wp_root_note,
                        'shortcut_title' => __('Claude CLI shortcut', 'livecanvas-forge-ai'),
                        'shortcut'       => $this->build_claude_cli_register_command($claude),
                        'command'        => (string) ($claude['command'] ?? ''),
                        'environment'    => $this->build_environment_block((array) ($claude['env'] ?? [])),
                        'test_command'   => $this->build_manual_mcp_test_command((array) ($claude['env'] ?? [])),
                    ],
                ],
            ],
            'opencode' => [
                'label'        => __('OpenCode', 'livecanvas-forge-ai'),
                'intro'        => __('Use this if OpenCode is your main terminal agent. You only need one local MCP entry that points to the AI Bridge bridge.', 'livecanvas-forge-ai'),
                'steps'        => [
                    __('Open the MCP server configuration in OpenCode.', 'livecanvas-forge-ai'),
                    __('Add a new local MCP server named livecanvas-forge.', 'livecanvas-forge-ai'),
                    __('Paste the command and environment variables from this tab.', 'livecanvas-forge-ai'),
                    __('Reconnect the server and run get_snapshot to make sure the WordPress companion is reachable.', 'livecanvas-forge-ai'),
                ],
                'note'         => $wp_root_note,
                'command'      => (string) ($opencode['command'] ?? ''),
                'environment'  => $this->build_environment_block((array) ($opencode['env'] ?? [])),
                'test_command' => $this->build_manual_mcp_test_command((array) ($opencode['env'] ?? [])),
            ],
            'generic' => [
                'label'        => __('Generic MCP client', 'livecanvas-forge-ai'),
                'intro'        => __('Use this if your coding agent is MCP-compatible but not listed here. The same MCP bridge still works: you only need a stdio server entry and the variables shown below.', 'livecanvas-forge-ai'),
                'steps'        => [
                    __('Open the MCP server settings in your client.', 'livecanvas-forge-ai'),
                    __('Create a new stdio server named livecanvas-forge.', 'livecanvas-forge-ai'),
                    __('Paste the command and environment variables shown in this tab.', 'livecanvas-forge-ai'),
                    __('Reconnect the client and test with get_snapshot before running write commands.', 'livecanvas-forge-ai'),
                ],
                'note'         => $wp_root_note,
                'command'      => (string) ($codex['command'] ?? ''),
                'environment'  => $this->build_environment_block((array) ($codex['env'] ?? [])),
                'test_command' => $this->build_manual_mcp_test_command((array) ($codex['env'] ?? [])),
            ],
        ];
    }

    private function build_environment_block(array $environment): string {
        if (!$environment) {
            return __('No environment variables were generated for this client.', 'livecanvas-forge-ai');
        }

        $lines = [];

        foreach ($environment as $key => $value) {
            if (is_int($key)) {
                $lines[] = (string) $value;
                continue;
            }

            $lines[] = (string) $key . '=' . (string) $value;
        }

        return implode("\n", $lines);
    }

    private function build_codex_register_command(array $client): string {
        $command = trim((string) ($client['command'] ?? ''));
        $environment = (array) ($client['env'] ?? []);

        $lines = [
            'LCFA_CODEX_BIN=""',
            'if command -v codex >/dev/null 2>&1; then',
            '  LCFA_CODEX_BIN="$(command -v codex)"',
            'elif [ -x "/Applications/Codex.app/Contents/Resources/codex" ]; then',
            '  LCFA_CODEX_BIN="/Applications/Codex.app/Contents/Resources/codex"',
            'fi',
            '',
            'if [ -n "$LCFA_CODEX_BIN" ]; then',
            '  "$LCFA_CODEX_BIN" mcp add livecanvas-forge \\',
        ];

        foreach ($environment as $entry) {
            $lines[] = '    --env ' . (string) $entry . ' \\';
        }

        $lines[] = '    -- ' . $command;
        $lines[] = 'else';
        $lines[] = "  cat <<'EOF'";
        $lines[] = 'Codex CLI not found in PATH and the embedded desktop CLI was not found at /Applications/Codex.app/Contents/Resources/codex.';
        $lines[] = 'Add this MCP server to the project .codex/config.toml, then reopen Codex:';
        $lines[] = '';
        $lines[] = $this->build_codex_config_snippet($client);
        $lines[] = 'EOF';
        $lines[] = '  exit 1';
        $lines[] = 'fi';

        return implode("\n", $lines);
    }

    private function build_codex_config_snippet(array $client): string {
        $command = trim((string) ($client['command'] ?? ''));
        $command_tokens = preg_split('/\s+/', $command, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $command_bin = $command_tokens[0] ?? 'node';
        $args = array_slice($command_tokens, 1);
        $lines = [
            '[mcp_servers.livecanvas-forge]',
            'command = ' . $this->quote_toml_string($command_bin),
            'args = [' . implode(', ', array_map([$this, 'quote_toml_string'], $args)) . ']',
            '',
            '[mcp_servers.livecanvas-forge.env]',
        ];

        foreach ((array) ($client['env'] ?? []) as $entry) {
            $parts = explode('=', (string) $entry, 2);
            $key = trim((string) ($parts[0] ?? ''));
            $value = (string) ($parts[1] ?? '');

            if ($key === '') {
                continue;
            }

            $lines[] = $key . ' = ' . $this->quote_toml_string($value);
        }

        return implode("\n", $lines);
    }

    private function build_claude_cli_register_command(array $client): string {
        $command = trim((string) ($client['command'] ?? ''));
        $lines = [
            'claude mcp add --transport stdio livecanvas-forge \\',
        ];

        foreach ((array) ($client['env'] ?? []) as $entry) {
            $parts = explode('=', (string) $entry, 2);
            $key = trim((string) ($parts[0] ?? ''));
            $value = (string) ($parts[1] ?? '');

            if ($key === '') {
                continue;
            }

            $lines[] = '  --env ' . $key . '=' . $this->quote_shell_value($value) . ' \\';
        }

        $lines[] = '  -- ' . $command;

        return implode("\n", $lines);
    }

    private function build_claude_desktop_config_snippet(array $client): string {
        $environment = $this->normalize_environment_entries((array) ($client['env'] ?? []));
        $command_tokens = $this->resolve_claude_desktop_command_tokens(
            $this->tokenize_command_string((string) ($client['command'] ?? '')),
            $environment
        );

        return (string) wp_json_encode([
            'mcpServers' => [
                'livecanvas-forge' => [
                    'type'    => 'stdio',
                    'command' => $command_tokens[0] ?? 'node',
                    'args'    => array_slice($command_tokens, 1),
                    'env'     => (object) $environment,
                ],
            ],
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";
    }

    private function build_claude_desktop_reference_snippet(array $client): string {
        $environment = $this->normalize_environment_entries((array) ($client['env'] ?? []));
        $command_tokens = $this->resolve_claude_desktop_command_tokens(
            $this->tokenize_command_string((string) ($client['command'] ?? '')),
            $environment
        );
        $lines = [
            '# Claude Desktop reference',
            '# Review these values before editing Claude Desktop on another machine or remote target.',
            '# Command',
            $command_tokens[0] ?? 'node',
            '',
            '# Args',
        ];

        foreach (array_slice($command_tokens, 1) as $token) {
            $lines[] = $token;
        }

        $lines[] = '';
        $lines[] = '# Environment';
        foreach ($environment as $key => $value) {
            $lines[] = $key . '=' . $value;
        }

        return implode("\n", $lines) . "\n";
    }

    private function tokenize_command_string(string $command): array {
        $command = trim($command);
        if ($command === '') {
            return [];
        }

        preg_match_all('/"(?:\\\\.|[^"])*"|\'(?:\\\\.|[^\'])*\'|[^\s]+/', $command, $matches);

        return array_values(array_filter(array_map(static function (string $token): string {
            $token = trim($token);
            if ($token === '') {
                return '';
            }

            if (($token[0] === '"' && substr($token, -1) === '"') || ($token[0] === "'" && substr($token, -1) === "'")) {
                return stripcslashes(substr($token, 1, -1));
            }

            return $token;
        }, $matches[0] ?? [])));
    }

    private function normalize_environment_entries(array $environment): array {
        $normalized = [];

        foreach ($environment as $key => $value) {
            if (is_int($key)) {
                $parts = explode('=', (string) $value, 2);
                $env_key = trim((string) ($parts[0] ?? ''));
                $env_value = (string) ($parts[1] ?? '');
            } else {
                $env_key = trim((string) $key);
                $env_value = (string) $value;
            }

            if ($env_key === '') {
                continue;
            }

            $normalized[$env_key] = $env_value;
        }

        return $normalized;
    }

    private function resolve_claude_desktop_command_tokens(array $command_tokens, array $environment): array {
        if ($command_tokens === []) {
            return [];
        }

        $wp_root = trim((string) ($environment['LCFA_WP_ROOT'] ?? ''));
        if ($wp_root === '' || count($command_tokens) < 2) {
            return $command_tokens;
        }

        $relative_script = 'wp-content/plugins/livecanvas-forge-ai/mcp/bin/livecanvas-forge-mcp.js';
        $script_path = str_replace('\\', '/', (string) ($command_tokens[1] ?? ''));
        $normalized_script_path = ltrim($script_path, './');

        if ($normalized_script_path !== $relative_script) {
            return $command_tokens;
        }

        $command_tokens[1] = rtrim($wp_root, "/\\") . '/' . $relative_script;

        return $command_tokens;
    }

    private function render_claude_desktop_merge_guide(): void {
        echo '<div class="lcfa-agent-guide__callout">';
        echo '<strong>' . esc_html__('What to do', 'livecanvas-forge-ai') . '</strong>';
        echo '<ol class="lcfa-agent-guide__callout-list">';
        echo '<li>' . esc_html__('Open Claude Desktop config', 'livecanvas-forge-ai') . ': <code>~/Library/Application Support/Claude/claude_desktop_config.json</code></li>';
        echo '<li>' . esc_html__('If mcpServers already exists, paste only the livecanvas-forge entry inside it.', 'livecanvas-forge-ai') . '</li>';
        echo '<li>' . esc_html__('If mcpServers does not exist, paste the full mcpServers block from below.', 'livecanvas-forge-ai') . '</li>';
        echo '<li>' . esc_html__('Do not replace your existing preferences or paste a second top-level JSON object.', 'livecanvas-forge-ai') . '</li>';
        echo '<li>' . esc_html__('Save the file and reopen Claude Desktop.', 'livecanvas-forge-ai') . '</li>';
        echo '</ol>';
        echo '</div>';
    }

    private function build_manual_mcp_test_command(array $environment): string {
        $lines = [];

        foreach ($environment as $entry) {
            $parts = explode('=', (string) $entry, 2);
            $key   = $parts[0] ?? '';
            $value = $parts[1] ?? '';

            if ($key === '') {
                continue;
            }

            $lines[] = $key . '=' . $this->quote_shell_value($value) . ' \\';
        }

        $lines[] = 'node ' . $this->quote_shell_value(LCFA_DIR . 'mcp/bin/livecanvas-forge-mcp.js') . ' \\';
        $lines[] = '  --tool get_snapshot \\';
        $lines[] = '  --output pretty';

        return implode("\n", $lines);
    }

    private function quote_shell_value(string $value): string {
        return "'" . str_replace("'", "'\"'\"'", $value) . "'";
    }

    private function quote_toml_string(string $value): string {
        return (string) wp_json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    private function render_studio_tab(array $settings, array $snapshot): void {
        $diagnostics = $this->get_ability_diagnostics_for_admin();
        $history     = LCFA_Settings::get_history();
        $connections = LCFA_Settings::get_connections();

        echo '<div class="lcfa-studio-app-shell" data-lcfa-studio-app-root data-lcfa-studio-endpoint="' . esc_url(rest_url('lcfa/v1/studio')) . '"></div>';
        echo '<div class="lcfa-grid" data-lcfa-studio-root data-lcfa-studio-fallback>';
        echo '<div class="lcfa-main">';
        $this->render_studio_overview_panel($settings, $snapshot, $diagnostics, $history);
        $this->render_studio_abilities_panel($diagnostics);
        echo '</div>';
        echo '<aside class="lcfa-sidebar">';
        $this->render_studio_write_policy_panel($diagnostics, $connections);
        $this->render_studio_runs_panel($history);
        echo '</aside>';
        echo '</div>';
    }

    private function render_studio_overview_panel(array $settings, array $snapshot, array $diagnostics, array $history): void {
        $ability       = is_array($diagnostics['ability_diagnostics'] ?? null) ? $diagnostics['ability_diagnostics'] : [];
        $adapter       = is_array($diagnostics['mcp_adapter'] ?? null) ? $diagnostics['mcp_adapter'] : [];
        $ai_client     = is_array($diagnostics['ai_client'] ?? null) ? $diagnostics['ai_client'] : [];
        $rollback_runs = 0;

        foreach ($history as $entry) {
            if (is_array($entry) && !empty($entry['rollback_available'])) {
                $rollback_runs++;
            }
        }

        $framework = '';
        if (isset($settings['framework']) && is_scalar($settings['framework'])) {
            $framework = (string) $settings['framework'];
        } elseif (isset($snapshot['framework']) && is_scalar($snapshot['framework'])) {
            $framework = (string) $snapshot['framework'];
        }

        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('sparkles');
        echo '<div><h2>' . esc_html__('AI Studio overview', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('A consolidated control surface for the WordPress-native AI Bridge contract: abilities, MCP exposure, AI readiness, and audited runs.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<div class="lcfa-summary-grid">';
        $this->render_summary_tile(__('Abilities', 'livecanvas-forge-ai'), (string) (int) ($ability['total'] ?? 0));
        $this->render_summary_tile(__('MCP public', 'livecanvas-forge-ai'), (string) (int) ($ability['mcp_public_total'] ?? 0));
        $this->render_summary_tile(__('Public writes', 'livecanvas-forge-ai'), (string) count((array) ($ability['mcp_public_write'] ?? [])));
        $this->render_summary_tile(__('Runs', 'livecanvas-forge-ai'), (string) count($history));
        $this->render_summary_tile(__('Rollbacks', 'livecanvas-forge-ai'), (string) $rollback_runs);
        $this->render_summary_tile(__('Framework', 'livecanvas-forge-ai'), $framework !== '' ? $framework : __('Auto', 'livecanvas-forge-ai'));
        echo '</div>';

        echo '<div class="lcfa-chip-row">';
        echo '<span class="lcfa-chip' . (!empty($adapter['available']) ? ' is-positive' : '') . '">' . esc_html(!empty($adapter['available']) ? __('MCP Adapter ready', 'livecanvas-forge-ai') : __('MCP Adapter pending', 'livecanvas-forge-ai')) . '</span>';
        echo '<span class="lcfa-chip' . (!empty($ai_client['text_generation_supported']) ? ' is-positive' : '') . '">' . esc_html(!empty($ai_client['text_generation_supported']) ? __('AI text ready', 'livecanvas-forge-ai') : __('AI text unavailable', 'livecanvas-forge-ai')) . '</span>';
        echo '<span class="lcfa-chip' . (!empty($settings['completed']) ? ' is-positive' : ' is-negative') . '">' . esc_html(!empty($settings['completed']) ? __('Setup complete', 'livecanvas-forge-ai') : __('Setup incomplete', 'livecanvas-forge-ai')) . '</span>';
        echo '</div>';

        echo '<div class="lcfa-cta-row">';
        echo '<a class="button" href="' . esc_url(admin_url('admin.php?page=lcfa-dashboard&tab=connections')) . '">' . esc_html__('Connection settings', 'livecanvas-forge-ai') . '</a>';
        echo '<a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=lcfa-dashboard&tab=command')) . '">' . esc_html__('Open Command Deck', 'livecanvas-forge-ai') . '</a>';
        echo '</div>';

        echo '</section>';
    }

    private function render_studio_abilities_panel(array $diagnostics): void {
        $ability = is_array($diagnostics['ability_diagnostics'] ?? null) ? $diagnostics['ability_diagnostics'] : [];
        $items   = is_array($ability['items'] ?? null) ? $ability['items'] : [];

        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('layers');
        echo '<div><h2>' . esc_html__('Abilities', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Registered AI Bridge abilities and their current MCP exposure state. Write abilities are private unless explicitly allowed in Connections.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        if (!$items) {
            echo '<p class="lcfa-empty">' . esc_html__('No AI Bridge abilities are registered in this runtime.', 'livecanvas-forge-ai') . '</p>';
            echo '</section>';

            return;
        }

        echo '<div class="lcfa-studio-toolbar" data-lcfa-studio-ability-controls>';
        echo '<label class="lcfa-studio-search"><span>' . esc_html__('Search abilities', 'livecanvas-forge-ai') . '</span><input type="search" data-lcfa-studio-ability-search placeholder="' . esc_attr__('Search name or label', 'livecanvas-forge-ai') . '"></label>';
        echo '<div class="lcfa-studio-segmented" role="group" aria-label="' . esc_attr__('Ability filters', 'livecanvas-forge-ai') . '">';
        echo '<button type="button" class="button is-current" data-lcfa-studio-ability-filter="all">' . esc_html__('All', 'livecanvas-forge-ai') . '</button>';
        echo '<button type="button" class="button" data-lcfa-studio-ability-filter="public">' . esc_html__('MCP public', 'livecanvas-forge-ai') . '</button>';
        echo '<button type="button" class="button" data-lcfa-studio-ability-filter="private">' . esc_html__('Private', 'livecanvas-forge-ai') . '</button>';
        echo '<button type="button" class="button" data-lcfa-studio-ability-filter="write">' . esc_html__('Write', 'livecanvas-forge-ai') . '</button>';
        echo '<button type="button" class="button" data-lcfa-studio-ability-filter="destructive">' . esc_html__('Destructive', 'livecanvas-forge-ai') . '</button>';
        echo '</div>';
        echo '</div>';

        echo '<div class="lcfa-target-list">';
        foreach (array_slice($items, 0, 40) as $item) {
            if (!is_array($item)) {
                continue;
            }

            $name        = (string) ($item['name'] ?? '');
            $label       = (string) ($item['label'] ?? '');
            $label       = $label !== '' ? $label : $name;
            $is_public   = !empty($item['mcp_public']);
            $is_readonly = !empty($item['readonly']);
            $destructive = !empty($item['destructive']);
            $idempotent  = !empty($item['idempotent']);
            $search_text  = strtolower($label . ' ' . $name);

            echo '<div class="lcfa-target-item" data-lcfa-studio-ability-item data-lcfa-search="' . esc_attr($search_text) . '" data-lcfa-mcp="' . esc_attr($is_public ? 'public' : 'private') . '" data-lcfa-kind="' . esc_attr($is_readonly ? 'read' : 'write') . '" data-lcfa-destructive="' . esc_attr($destructive ? '1' : '0') . '">';
            echo '<div class="lcfa-target-copy">';
            echo '<strong>' . esc_html($label) . '</strong>';
            echo '<span><code>' . esc_html($name) . '</code></span>';
            echo '</div>';
            echo '<div class="lcfa-chip-row">';
            echo '<span class="lcfa-chip' . ($is_public ? ' is-positive' : '') . '">' . esc_html($is_public ? __('MCP public', 'livecanvas-forge-ai') : __('MCP private', 'livecanvas-forge-ai')) . '</span>';
            echo '<span class="lcfa-chip' . ($is_readonly ? ' is-positive' : ' is-warning') . '">' . esc_html($is_readonly ? __('Read-only', 'livecanvas-forge-ai') : __('Write', 'livecanvas-forge-ai')) . '</span>';
            echo '<span class="lcfa-chip' . ($destructive ? ' is-negative' : '') . '">' . esc_html($destructive ? __('Destructive', 'livecanvas-forge-ai') : __('Non-destructive', 'livecanvas-forge-ai')) . '</span>';
            echo '<span class="lcfa-chip">' . esc_html($idempotent ? __('Idempotent', 'livecanvas-forge-ai') : __('Non-idempotent', 'livecanvas-forge-ai')) . '</span>';
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';

        if (count($items) > 40) {
            echo '<p class="lcfa-empty">' . esc_html(sprintf(__('Showing 40 of %d abilities.', 'livecanvas-forge-ai'), count($items))) . '</p>';
        }

        echo '<p class="lcfa-empty" data-lcfa-studio-ability-empty hidden>' . esc_html__('No abilities match the current filters.', 'livecanvas-forge-ai') . '</p>';
        echo '</section>';
    }

    private function render_studio_write_policy_panel(array $diagnostics, array $connections): void {
        $ability        = is_array($diagnostics['ability_diagnostics'] ?? null) ? $diagnostics['ability_diagnostics'] : [];
        $public_write   = is_array($ability['mcp_public_write'] ?? null) ? $ability['mcp_public_write'] : [];
        $allowlist      = is_array($ability['mcp_write_allowlist'] ?? null) ? $ability['mcp_write_allowlist'] : [];
        $available      = is_array($ability['mcp_write_available'] ?? null) ? $ability['mcp_write_available'] : [];
        $options        = method_exists('LCFA_Settings', 'get_mcp_write_ability_options') ? LCFA_Settings::get_mcp_write_ability_options() : [];
        $master_enabled = !empty($connections['mcp_write_abilities_enabled']) || !empty($ability['mcp_write_opt_in_enabled']);

        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('shield-check');
        echo '<div><h2>' . esc_html__('MCP write policy', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Destructive abilities require the master switch and a per-ability allowlist before they become MCP-public.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<div class="lcfa-chip-row">';
        echo '<span class="lcfa-chip' . ($master_enabled ? ' is-warning' : ' is-positive') . '">' . esc_html($master_enabled ? __('Master opt-in enabled', 'livecanvas-forge-ai') : __('Master opt-in disabled', 'livecanvas-forge-ai')) . '</span>';
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Allowed: %d', 'livecanvas-forge-ai'), count($allowlist))) . '</span>';
        echo '<span class="lcfa-chip' . ($public_write ? ' is-negative' : ' is-positive') . '">' . esc_html(sprintf(__('Exposed: %d', 'livecanvas-forge-ai'), count($public_write))) . '</span>';
        echo '</div>';

        if ($allowlist) {
            echo '<div class="lcfa-guide">';
            echo '<h3>' . esc_html__('Allowed write abilities', 'livecanvas-forge-ai') . '</h3>';
            echo '<ul class="lcfa-check-list">';
            foreach ($allowlist as $ability_name) {
                $label = is_array($options[$ability_name] ?? null) ? (string) ($options[$ability_name]['label'] ?? $ability_name) : (string) $ability_name;
                echo '<li><strong>' . esc_html($label) . '</strong><br><code>' . esc_html((string) $ability_name) . '</code></li>';
            }
            echo '</ul>';
            echo '</div>';
        } else {
            echo '<p class="lcfa-empty">' . esc_html__('No write ability is currently allowed for MCP exposure.', 'livecanvas-forge-ai') . '</p>';
        }

        if ($public_write) {
            echo '<div class="lcfa-notice lcfa-notice--warning">';
            echo '<strong>' . esc_html__('Review exposed write abilities', 'livecanvas-forge-ai') . '</strong>';
            echo '<p>' . esc_html__('These abilities can write through an MCP-capable client. Keep this list as small as possible.', 'livecanvas-forge-ai') . '</p>';
            echo '</div>';
        }

        if ($available) {
            echo '<p class="lcfa-empty">' . esc_html(sprintf(__('Available write abilities: %d', 'livecanvas-forge-ai'), count($available))) . '</p>';
        }

        echo '<p><a class="button" href="' . esc_url(admin_url('admin.php?page=lcfa-dashboard&tab=connections')) . '">' . esc_html__('Edit write allowlist', 'livecanvas-forge-ai') . '</a></p>';
        echo '</section>';
    }

    private function render_studio_runs_panel(array $history): void {
        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('activity');
        echo '<div><h2>' . esc_html__('Runs & audit', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Recent AI Bridge operations with audit IDs and rollback shortcuts when a local restore record exists.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        if (!$history) {
            echo '<p class="lcfa-empty">' . esc_html__('No audited run has been recorded yet.', 'livecanvas-forge-ai') . '</p>';
            echo '</section>';

            return;
        }

        echo '<div class="lcfa-studio-toolbar" data-lcfa-studio-run-controls>';
        echo '<label class="lcfa-studio-search"><span>' . esc_html__('Search runs', 'livecanvas-forge-ai') . '</span><input type="search" data-lcfa-studio-run-search placeholder="' . esc_attr__('Search action, audit ID, or target', 'livecanvas-forge-ai') . '"></label>';
        echo '<div class="lcfa-studio-segmented" role="group" aria-label="' . esc_attr__('Run filters', 'livecanvas-forge-ai') . '">';
        echo '<button type="button" class="button is-current" data-lcfa-studio-run-filter="all">' . esc_html__('All', 'livecanvas-forge-ai') . '</button>';
        echo '<button type="button" class="button" data-lcfa-studio-run-filter="rollback">' . esc_html__('Rollback', 'livecanvas-forge-ai') . '</button>';
        echo '<button type="button" class="button" data-lcfa-studio-run-filter="error">' . esc_html__('Errors', 'livecanvas-forge-ai') . '</button>';
        echo '<button type="button" class="button" data-lcfa-studio-run-filter="apply">' . esc_html__('Apply', 'livecanvas-forge-ai') . '</button>';
        echo '</div>';
        echo '</div>';

        echo '<div class="lcfa-history-list">';
        foreach (array_slice($history, 0, 12) as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $time = !empty($entry['time'])
                ? get_date_from_gmt((string) $entry['time'], get_option('date_format') . ' ' . get_option('time_format'))
                : '';
            $summary = (string) ($entry['summary'] ?? ($entry['message'] ?? __('Unnamed operation', 'livecanvas-forge-ai')));
            $target = '';

            if (!empty($entry['target_title'])) {
                $target = (string) $entry['target_title'];
            } elseif (!empty($entry['target_id'])) {
                $target = sprintf(__('Target #%d', 'livecanvas-forge-ai'), (int) $entry['target_id']);
            }
            $search_text = strtolower($summary . ' ' . $target . ' ' . (string) ($entry['action'] ?? '') . ' ' . (string) ($entry['audit_id'] ?? ''));

            echo '<div class="lcfa-history-item" data-lcfa-studio-run-item data-lcfa-search="' . esc_attr($search_text) . '" data-lcfa-status="' . esc_attr(!empty($entry['ok']) ? 'ok' : 'error') . '" data-lcfa-mode="' . esc_attr((string) ($entry['mode'] ?? '')) . '" data-lcfa-rollback="' . esc_attr(!empty($entry['rollback_available']) ? '1' : '0') . '">';
            echo '<div class="lcfa-history-copy">';
            echo '<strong>' . esc_html($summary !== '' ? $summary : __('Unnamed operation', 'livecanvas-forge-ai')) . '</strong>';
            if ($time !== '') {
                echo '<span>' . esc_html($time) . '</span>';
            }
            if ($target !== '') {
                echo '<span>' . esc_html($target) . '</span>';
            }
            echo '</div>';
            echo '<div class="lcfa-chip-row">';
            if (!empty($entry['action'])) {
                echo '<span class="lcfa-chip">' . esc_html((string) $entry['action']) . '</span>';
            }
            if (!empty($entry['mode'])) {
                echo '<span class="lcfa-chip">' . esc_html((string) $entry['mode']) . '</span>';
            }
            if (!empty($entry['execution_target'])) {
                echo '<span class="lcfa-chip">' . esc_html((string) $entry['execution_target']) . '</span>';
            }
            echo '<span class="lcfa-chip' . (!empty($entry['ok']) ? ' is-positive' : ' is-negative') . '">' . esc_html(!empty($entry['ok']) ? __('OK', 'livecanvas-forge-ai') : __('Error', 'livecanvas-forge-ai')) . '</span>';
            if (!empty($entry['audit_id'])) {
                echo '<span class="lcfa-chip">' . esc_html((string) $entry['audit_id']) . '</span>';
            }
            if (!empty($entry['rollback_available'])) {
                echo '<span class="lcfa-chip is-positive">' . esc_html__('Rollback ready', 'livecanvas-forge-ai') . '</span>';
                if (($entry['execution_target'] ?? 'local') === 'local' && !empty($entry['audit_id'])) {
                    echo '<a class="button button-small" href="' . esc_url($this->get_command_url([
                        'suggest_action' => 'restore_audit_rollback',
                        'audit_id'       => (string) $entry['audit_id'],
                    ])) . '">' . esc_html__('Restore', 'livecanvas-forge-ai') . '</a>';
                }
            }
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';

        echo '<p class="lcfa-empty" data-lcfa-studio-run-empty hidden>' . esc_html__('No runs match the current filters.', 'livecanvas-forge-ai') . '</p>';
        echo '<p><a class="button" href="' . esc_url(admin_url('admin.php?page=lcfa-dashboard&tab=command')) . '">' . esc_html__('Open full history in Command Deck', 'livecanvas-forge-ai') . '</a></p>';
        echo '</section>';
    }

    private function render_command_tab(array $settings, array $snapshot): void {
        $allowed_views  = ['command', 'inventory', 'runtimes', 'files', 'history'];
        $requested_view = sanitize_key(wp_unslash((string) ($_GET['command_view'] ?? 'command')));
        $command_view   = in_array($requested_view, $allowed_views, true) ? $requested_view : 'command';
        $inventory      = $command_view === 'inventory' ? $this->inventory->get_inventory() : [];
        $actions        = $this->command_deck->get_actions();
        $command_result = LCFA_Settings::consume_command_result();
        $command_suggestion = LCFA_Settings::consume_command_suggestion();
        $history        = LCFA_Settings::get_history();
        $theme_context  = $this->context_builder->get_theme_context();
        $windpress      = is_array($theme_context['windpress'] ?? null) ? $theme_context['windpress'] : [];
        $mcp_status     = $this->context_builder->get_mcp_status();
        $local_bridge   = is_array($mcp_status['local_bridge'] ?? null) ? $mcp_status['local_bridge'] : [];
        $remote_status  = $this->remote_client->get_status();
        $command_form   = $this->get_command_form_context($actions);
        $current_thread_id = LCFA_Settings::normalize_thread_id((string) ($command_form['thread_id'] ?? 'default'));
        $current_thread = LCFA_Settings::get_thread($current_thread_id);
        $thread_summaries = LCFA_Settings::get_thread_summaries();
        $theme_roots    = null;
        $theme_templates = null;

        if ($command_view === 'files') {
            try {
                $theme_roots = $this->theme_files_bridge->get_theme_roots();
                $theme_templates = $this->theme_files_bridge->list_templates([
                    'root_scope' => 'active',
                    'limit'      => 8,
                ]);
            } catch (Throwable $throwable) {
                $theme_roots = [
                    'error' => $throwable->getMessage(),
                ];
            }
        }

        $this->render_command_view_nav($command_view);

        echo '<div class="lcfa-grid' . ($command_view === 'command' ? '' : ' lcfa-grid--single') . '">';
        echo '<div class="lcfa-main">';
        if ($command_view === 'command') {
        $this->render_command_result($command_result);
        $this->render_command_suggestion($command_suggestion);
        $this->render_command_thread_panel($current_thread, $thread_summaries, $command_form);

        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('command');
        echo '<div><h2>' . esc_html__('Run command', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Execute LiveCanvas targets and WindPress maintenance operations from the same backend console.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        if (!empty($command_form['context_label'])) {
            echo '<div class="lcfa-guide">';
            echo '<h3>' . esc_html__('Current editor context', 'livecanvas-forge-ai') . '</h3>';
            echo '<p>' . esc_html($command_form['context_label']) . '</p>';
            echo '</div>';
        }

        if (!empty($command_form['genesis_task_id'])) {
            echo '<div class="lcfa-guide">';
            echo '<h3>' . esc_html__('Genesis task', 'livecanvas-forge-ai') . '</h3>';
            echo '<p>' . esc_html(sprintf(__('This command run is linked to Genesis task ID %s. Preview and apply results will update the Genesis plan progress automatically.', 'livecanvas-forge-ai'), (string) $command_form['genesis_task_id'])) . '</p>';
            echo '</div>';
        }

        echo '<div class="lcfa-chip-row lcfa-command-runtime-summary">';
        echo '<span class="lcfa-chip' . (!empty($local_bridge['build_available']) ? ' is-positive' : '') . '">' . esc_html(!empty($local_bridge['build_available']) ? __('Local runtime ready', 'livecanvas-forge-ai') : __('Local runtime limited', 'livecanvas-forge-ai')) . '</span>';
        echo '<span class="lcfa-chip' . (!empty($remote_status['available']) ? ' is-positive' : '') . '">' . esc_html(!empty($remote_status['available']) ? __('Site-to-site runtime ready', 'livecanvas-forge-ai') : __('Site-to-site runtime off', 'livecanvas-forge-ai')) . '</span>';
        echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Policy: %s', 'livecanvas-forge-ai'), (string) ($settings['permission_profile'] ?: 'advanced_templates'))) . '</span>';
        echo '<a class="button button-small" href="' . esc_url($this->get_command_view_url('runtimes')) . '">' . esc_html__('Review runtimes', 'livecanvas-forge-ai') . '</a>';
        echo '</div>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form">';
        wp_nonce_field('lcfa_command');
        echo '<input type="hidden" name="action" value="lcfa_command">';
        echo '<input type="hidden" name="thread_id" value="' . esc_attr($current_thread_id) . '">';
        echo '<input type="hidden" name="genesis_task_id" value="' . esc_attr((string) ($command_form['genesis_task_id'] ?? '')) . '">';
        echo '<input type="hidden" name="context_post_id" value="' . esc_attr((string) ($command_form['context_post_id'] ?? '')) . '">';

        echo '<label><span>' . esc_html__('Request to AI Bridge', 'livecanvas-forge-ai') . '</span><textarea name="user_prompt" rows="4" placeholder="' . esc_attr__('Describe the requested change, why it matters, or what the assistant should keep in mind for this run.', 'livecanvas-forge-ai') . '">' . esc_textarea($command_form['user_prompt']) . '</textarea></label>';

        echo '<label><span>' . esc_html__('Action', 'livecanvas-forge-ai') . '</span>';
        echo '<select name="action">';
        foreach ($actions as $action_key => $action_data) {
            echo '<option value="' . esc_attr($action_key) . '"' . selected($command_form['action'], $action_key, false) . '>' . esc_html($action_data['label']) . '</option>';
        }
        echo '</select></label>';
        echo '<label><span>' . esc_html__('Execution target', 'livecanvas-forge-ai') . '</span>';
        echo '<select name="execution_target">';
        echo '<option value="local"' . selected($command_form['execution_target'], 'local', false) . '>' . esc_html__('Local site', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="remote"' . selected($command_form['execution_target'], 'remote', false) . (!empty($remote_status['configured']) ? '' : ' disabled') . '>' . esc_html__('Remote site', 'livecanvas-forge-ai') . '</option>';
        echo '</select></label>';

        echo '<label><span>' . esc_html__('Target ID', 'livecanvas-forge-ai') . '</span><input type="text" name="target_id" value="' . esc_attr($command_form['target_id']) . '" placeholder="' . esc_attr__('Required for update actions.', 'livecanvas-forge-ai') . '"></label>';
        echo '<label><span>' . esc_html__('Variant', 'livecanvas-forge-ai') . '</span><input type="text" name="variant" value="' . esc_attr($command_form['variant']) . '" placeholder="1"></label>';
        echo '<label><span>' . esc_html__('Title', 'livecanvas-forge-ai') . '</span><input type="text" name="title" value="' . esc_attr($command_form['title']) . '" placeholder="' . esc_attr__('Used for create actions.', 'livecanvas-forge-ai') . '"></label>';
        echo '<label><span>' . esc_html__('Slug', 'livecanvas-forge-ai') . '</span><input type="text" name="slug" value="' . esc_attr($command_form['slug']) . '" placeholder="optional-slug"></label>';
        echo '<label><span>' . esc_html__('WindPress provider ID', 'livecanvas-forge-ai') . '</span><input type="text" name="provider_id" value="' . esc_attr($command_form['provider_id']) . '" placeholder="wordpress-theme-json, livecanvas-content"></label>';
        echo '<label><span>' . esc_html__('WindPress relative path', 'livecanvas-forge-ai') . '</span><input type="text" name="relative_path" value="' . esc_attr($command_form['relative_path']) . '" placeholder="main.css"></label>';
        echo '<label><span>' . esc_html__('Theme root scope', 'livecanvas-forge-ai') . '</span>';
        echo '<select name="root_scope">';
        echo '<option value="stylesheet"' . selected($command_form['root_scope'], 'stylesheet', false) . '>' . esc_html__('Stylesheet theme', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="template"' . selected($command_form['root_scope'], 'template', false) . '>' . esc_html__('Template theme', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="active"' . selected($command_form['root_scope'], 'active', false) . '>' . esc_html__('Active roots', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="all"' . selected($command_form['root_scope'], 'all', false) . '>' . esc_html__('All roots', 'livecanvas-forge-ai') . '</option>';
        echo '</select></label>';
        echo '<label><span>' . esc_html__('Theme file path', 'livecanvas-forge-ai') . '</span><input type="text" name="file_path" value="' . esc_attr($command_form['file_path']) . '" placeholder="views/single.twig"></label>';
        echo '<label><span>' . esc_html__('Backup ID', 'livecanvas-forge-ai') . '</span><input type="text" name="backup_id" value="' . esc_attr($command_form['backup_id']) . '" placeholder="2026-04-03/theme-name/..."></label>';
        echo '<label><span>' . esc_html__('Audit ID', 'livecanvas-forge-ai') . '</span><input type="text" name="audit_id" value="' . esc_attr($command_form['audit_id']) . '" placeholder="audit-..."></label>';
        echo '<label><span>' . esc_html__('Post status', 'livecanvas-forge-ai') . '</span>';
        echo '<select name="status">';
        echo '<option value="draft"' . selected($command_form['status'], 'draft', false) . '>' . esc_html__('Draft', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="publish"' . selected($command_form['status'], 'publish', false) . '>' . esc_html__('Publish', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="private"' . selected($command_form['status'], 'private', false) . '>' . esc_html__('Private', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="pending"' . selected($command_form['status'], 'pending', false) . '>' . esc_html__('Pending', 'livecanvas-forge-ai') . '</option>';
        echo '</select></label>';
        echo '<label><span>' . esc_html__('HTML / template / CSS / theme.json content', 'livecanvas-forge-ai') . '</span><textarea name="content" rows="16" placeholder="' . esc_attr__('<section>...</section>', 'livecanvas-forge-ai') . '">' . esc_textarea($command_form['content']) . '</textarea></label>';
        echo '<label class="lcfa-checkbox"><input type="checkbox" name="dry_run" value="1"' . checked($command_form['dry_run'], true, false) . '> ' . esc_html__('Run as preview only', 'livecanvas-forge-ai') . '</label>';

        echo '<div class="lcfa-cta-row">';
        echo '<button class="button" type="submit" name="analyze_request" value="1">' . esc_html__('Analyze request', 'livecanvas-forge-ai') . '</button>';
        echo '<button class="button button-primary" type="submit">' . esc_html__('Run command', 'livecanvas-forge-ai') . '</button>';
        echo '</div>';
        echo '</form>';

        echo '<details class="lcfa-command-details lcfa-command-action-reference">';
        echo '<summary>' . esc_html__('Action reference', 'livecanvas-forge-ai') . '</summary>';
        echo '<div class="lcfa-command-details__body">';
        echo '<ul class="lcfa-bullets">';
        foreach ($actions as $action_key => $action_data) {
            echo '<li><strong>' . esc_html($action_data['label']) . '</strong>: ' . esc_html($action_data['description']) . ' ';
            echo '<code>' . esc_html($action_key) . '</code></li>';
        }
        echo '<li>' . esc_html__('For build_windpress_cache, the provider field accepts one provider ID or a comma-separated list.', 'livecanvas-forge-ai') . '</li>';
        echo '<li>' . esc_html__('Use Analyze request to convert a natural-language prompt into a safer suggested action before you run it.', 'livecanvas-forge-ai') . '</li>';
        echo '<li>' . esc_html__('restore_theme_backup expects a backup ID. Use the backup list below to prefill it safely.', 'livecanvas-forge-ai') . '</li>';
        echo '<li>' . esc_html__('restore_audit_rollback expects an audit ID from a previous local apply run and can be previewed before restoring.', 'livecanvas-forge-ai') . '</li>';
        echo '<li>' . esc_html__('Remote execution reuses the same companion routes on the target WordPress, so target IDs and template paths must belong to that remote site.', 'livecanvas-forge-ai') . '</li>';
        echo '</ul>';
        echo '</div>';
        echo '</details>';
        echo '</section>';
        }

        if ($command_view === 'inventory') {
        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('layers');
        echo '<div><h2>' . esc_html__('Inventory', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('LiveCanvas-aware targets currently discoverable by the companion.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';
        $this->render_inventory_panel($inventory);
        echo '</section>';
        }

        if ($command_view === 'runtimes') {
        $this->render_command_runtime_status_card($settings, $local_bridge, $remote_status);
        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('wind');
        echo '<div><h2>' . esc_html__('WindPress runtime', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Provider scans, local cache builds, and cache maintenance for Picowind and Tailwind workflows.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';
        $this->render_windpress_panel($windpress, $local_bridge);
        echo '</section>';
        }

        if ($command_view === 'files') {
        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('file-earmark');
        echo '<div><h2>' . esc_html__('Theme files', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Fallback templates and theme files available to the companion inside the active theme roots.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';
        $this->render_theme_files_panel($theme_roots, $theme_templates);
        echo '</section>';
        }

        if ($command_view === 'history') {
            $this->render_history_panel($history);
        }

        echo '</div>';
        if ($command_view === 'command') {
            echo '<aside class="lcfa-sidebar">';
            $this->render_history_panel($history);
            echo '</aside>';
        }
        echo '</div>';
    }

    private function render_command_view_nav(string $current_view): void {
        $views = [
            'command'   => __('Command', 'livecanvas-forge-ai'),
            'inventory' => __('Inventory', 'livecanvas-forge-ai'),
            'runtimes'  => __('Runtimes', 'livecanvas-forge-ai'),
            'files'     => __('Theme files', 'livecanvas-forge-ai'),
            'history'   => __('History', 'livecanvas-forge-ai'),
        ];

        echo '<nav class="lcfa-workspace-viewbar lcfa-command-viewbar" aria-label="' . esc_attr__('Command Deck views', 'livecanvas-forge-ai') . '">';
        echo '<div class="lcfa-studio-segmented" role="tablist" aria-label="' . esc_attr__('Choose a Command Deck workspace', 'livecanvas-forge-ai') . '">';
        foreach ($views as $view => $label) {
            echo '<a class="button' . ($view === $current_view ? ' is-current' : '') . '" role="tab" aria-selected="' . ($view === $current_view ? 'true' : 'false') . '" href="' . esc_url($this->get_command_view_url($view)) . '">' . esc_html($label) . '</a>';
        }
        echo '</div>';
        echo '</nav>';
    }

    private function get_command_view_url(string $view): string {
        return add_query_arg([
            'page'         => 'lcfa-dashboard',
            'tab'          => 'command',
            'command_view' => sanitize_key($view),
        ], admin_url('admin.php'));
    }

    private function render_command_runtime_status_card(array $settings, array $local_bridge, array $remote_status): void {
        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('activity');
        echo '<div><h2>' . esc_html__('Runtime status', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Build execution and optional site-to-site command targets.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<div class="lcfa-summary-grid">';
        $this->render_summary_tile(__('Local runtime', 'livecanvas-forge-ai'), !empty($local_bridge['build_available']) ? __('Ready', 'livecanvas-forge-ai') : __('Limited', 'livecanvas-forge-ai'));
        $this->render_summary_tile(__('Site-to-site runtime', 'livecanvas-forge-ai'), !empty($remote_status['available']) ? __('Ready', 'livecanvas-forge-ai') : __('Off', 'livecanvas-forge-ai'));
        $this->render_summary_tile(__('Permission profile', 'livecanvas-forge-ai'), (string) ($settings['permission_profile'] ?: 'advanced_templates'));
        $this->render_summary_tile(__('File fallback', 'livecanvas-forge-ai'), !empty($settings['allow_file_fallback']) ? __('Enabled', 'livecanvas-forge-ai') : __('Disabled', 'livecanvas-forge-ai'));
        echo '</div>';

        if (!empty($local_bridge['node_version'])) {
            echo '<p class="lcfa-studio-meta">' . esc_html(sprintf(__('Detected Node.js %s.', 'livecanvas-forge-ai'), (string) $local_bridge['node_version'])) . '</p>';
        }

        echo '<div class="lcfa-workspace-note">';
        echo '<strong>' . esc_html__('Site-to-site runtime is separate from coding-agent pairing', 'livecanvas-forge-ai') . '</strong>';
        echo '<p>' . esc_html__('Codex, OpenCode, Claude, and Cursor use Connections. This optional runtime lets one WordPress dashboard send commands to another site and may use legacy remote credentials.', 'livecanvas-forge-ai') . '</p>';
        echo '</div>';
        echo '</section>';
    }

    private function render_streamlined_setup_nav(int $current_step, array $settings, array $snapshot): void {
        $preflight_ready = $this->is_preflight_ready($snapshot);
        $profile_ready = (int) ($settings['last_completed_step'] ?? 0) >= 5;
        $steps = [
            1 => ['label' => __('Check site', 'livecanvas-forge-ai'), 'icon' => 'shield-check', 'done' => $preflight_ready, 'locked' => false],
            2 => ['label' => __('Confirm project', 'livecanvas-forge-ai'), 'icon' => 'layers', 'done' => $profile_ready, 'locked' => !$preflight_ready],
            3 => ['label' => __('Connect agent', 'livecanvas-forge-ai'), 'icon' => 'plug', 'done' => !empty($settings['completed']), 'locked' => !$profile_ready],
        ];

        echo '<nav class="lcfa-steps lcfa-steps--streamlined" aria-label="' . esc_attr__('Setup progress', 'livecanvas-forge-ai') . '">';
        foreach ($steps as $step => $data) {
            $classes = ['lcfa-step'];
            if ($step === $current_step) {
                $classes[] = 'is-current';
            }
            if (!empty($data['done'])) {
                $classes[] = 'is-done';
            }

            $content = '<span class="lcfa-step-icon-wrap">' . $this->get_icon_svg((string) $data['icon']) . '</span>'
                . '<span>' . esc_html(sprintf(__('%1$d. %2$s', 'livecanvas-forge-ai'), $step, (string) $data['label'])) . '</span>';

            if (!empty($data['locked'])) {
                echo '<span class="' . esc_attr(implode(' ', $classes)) . '" aria-disabled="true">' . $content . '</span>';
            } else {
                echo '<a class="' . esc_attr(implode(' ', $classes)) . '" href="' . esc_url(admin_url('admin.php?page=lcfa-dashboard&tab=setup&step=' . $step)) . '">' . $content . '</a>';
            }
        }
        echo '</nav>';
    }

    private function render_streamlined_profile_step(array $settings, array $snapshot): void {
        $framework = $this->normalize_supported_framework((string) ($settings['framework'] ?: ($snapshot['detected_framework'] ?? '')));
        if ($framework === '') {
            $framework = $this->has_picowind_stack($snapshot) ? 'picowind' : 'picostrap';
        }

        $site_mode = sanitize_key((string) ($settings['site_mode'] ?: ($snapshot['site_mode'] ?? 'local')));
        if (!in_array($site_mode, ['local', 'remote', 'hybrid'], true)) {
            $site_mode = 'local';
        }

        $ai_tool = sanitize_key((string) ($settings['ai_tool'] ?: 'codex'));
        if ($ai_tool === 'claude-code') {
            $ai_tool = 'claude';
        }
        if (!in_array($ai_tool, ['codex', 'opencode', 'claude', 'cursor', 'other'], true)) {
            $ai_tool = 'codex';
        }

        $full_access = (string) ($settings['permission_profile'] ?? '') === 'advanced_templates'
            || !empty($settings['allow_file_fallback']);

        echo '<section class="lcfa-card lcfa-setup-panel">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('sliders');
        echo '<div><h2>' . esc_html__('Check your project settings', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('AI Bridge filled these in from your site. Review each choice, then save and continue.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<div class="lcfa-setup-detected">';
        echo '<strong>' . esc_html__('Detected now', 'livecanvas-forge-ai') . '</strong>';
        echo '<span>' . esc_html(sprintf(__('Theme: %s', 'livecanvas-forge-ai'), (string) ($snapshot['current_theme_name'] ?? $snapshot['current_theme_stylesheet'] ?? __('Unknown', 'livecanvas-forge-ai')))) . '</span>';
        echo '<span>' . esc_html(sprintf(__('WordPress: %s', 'livecanvas-forge-ai'), (string) ($snapshot['wordpress_version'] ?? get_bloginfo('version')))) . '</span>';
        echo '</div>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form lcfa-setup-profile-form" data-lcfa-setup-profile-form>';
        wp_nonce_field('lcfa_setup');
        echo '<input type="hidden" name="action" value="lcfa_setup">';
        echo '<input type="hidden" name="step" value="20">';

        $picostrap_help = __('Choose Bootstrap when your pages and theme use Picostrap. WindPress is not needed.', 'livecanvas-forge-ai');
        $picowind_help = $this->get_framework_submit_note('picowind', $snapshot);
        $framework_help = $framework === 'picowind' ? $picowind_help : $picostrap_help;

        echo '<div class="lcfa-setup-field-grid">';
        echo '<label class="lcfa-setup-field"><span class="lcfa-setup-field__label">' . esc_html__('Frontend framework', 'livecanvas-forge-ai') . '</span>';
        echo '<span class="lcfa-select-control"><select name="framework" data-lcfa-profile-framework>';
        echo '<option value="picostrap" data-lcfa-framework-help="' . esc_attr($picostrap_help) . '"' . selected($framework, 'picostrap', false) . '>' . esc_html__('Picostrap / Bootstrap', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="picowind" data-lcfa-framework-help="' . esc_attr($picowind_help) . '"' . selected($framework, 'picowind', false) . '>' . esc_html__('Picowind / Tailwind + WindPress', 'livecanvas-forge-ai') . '</option>';
        echo '</select></span><small data-lcfa-profile-framework-help>' . esc_html($framework_help) . '</small></label>';

        echo '<label class="lcfa-setup-field"><span class="lcfa-setup-field__label">' . esc_html__('Where WordPress runs', 'livecanvas-forge-ai') . '</span>';
        echo '<span class="lcfa-select-control"><select name="site_mode">';
        echo '<option value="local"' . selected($site_mode, 'local', false) . '>' . esc_html__('Local or private site', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="remote"' . selected($site_mode, 'remote', false) . '>' . esc_html__('Online HTTPS site', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="hybrid"' . selected($site_mode, 'hybrid', false) . '>' . esc_html__('Both local and online targets', 'livecanvas-forge-ai') . '</option>';
        echo '</select></span><small>' . esc_html__('This only changes how the coding agent connects. Your WordPress address stays the same.', 'livecanvas-forge-ai') . '</small></label>';

        echo '<label class="lcfa-setup-field"><span class="lcfa-setup-field__label">' . esc_html__('Coding agent', 'livecanvas-forge-ai') . '</span>';
        echo '<span class="lcfa-select-control"><select name="ai_tool">';
        echo '<option value="codex"' . selected($ai_tool, 'codex', false) . '>' . esc_html__('Codex (recommended)', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="opencode"' . selected($ai_tool, 'opencode', false) . '>' . esc_html__('OpenCode', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="claude"' . selected($ai_tool, 'claude', false) . '>' . esc_html__('Claude', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="cursor"' . selected($ai_tool, 'cursor', false) . '>' . esc_html__('Cursor', 'livecanvas-forge-ai') . '</option>';
        echo '<option value="other"' . selected($ai_tool, 'other', false) . '>' . esc_html__('Other MCP client', 'livecanvas-forge-ai') . '</option>';
        echo '</select></span><small>' . esc_html__('Choose the app you want to connect first. You can add another one later.', 'livecanvas-forge-ai') . '</small></label>';
        echo '</div>';

        echo '<label class="lcfa-checkbox lcfa-setup-access">';
        echo '<input type="checkbox" name="enable_full_access" value="1"' . checked($full_access, true, false) . '>';
        echo '<span class="lcfa-setup-access__copy"><strong>' . esc_html__('Let the coding agent make changes', 'livecanvas-forge-ai') . '</strong><small>' . esc_html__('Turn this on when you want the agent to build or edit the site. AI Bridge verifies the site, previews supported changes, and keeps a backup so you can undo them.', 'livecanvas-forge-ai') . '</small></span>';
        echo '</label>';

        echo '<div class="lcfa-setup-submit">';
        echo '<button class="button button-primary" type="submit">' . esc_html__('Save project and continue', 'livecanvas-forge-ai') . '</button>';
        echo '<span>' . esc_html__('Next: connect the selected coding agent.', 'livecanvas-forge-ai') . '</span>';
        echo '</div>';
        echo '</form>';
        echo '</section>';
    }

    private function render_streamlined_finish_step(array $settings, array $snapshot): void {
        $framework = (string) ($settings['framework'] ?: ($snapshot['detected_framework'] ?? __('Unknown', 'livecanvas-forge-ai')));
        $site_mode = (string) ($settings['site_mode'] ?: ($snapshot['site_mode'] ?? 'local'));
        $ai_tool = (string) ($settings['ai_tool'] ?: 'codex');
        $full_access = (string) ($settings['permission_profile'] ?? '') === 'advanced_templates';

        echo '<section class="lcfa-card lcfa-setup-panel">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('plug');
        echo '<div><h2>' . esc_html__('Project setup is ready', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Finish setup to open the connection screen. WordPress will then show one action at a time for the selected coding agent.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<dl class="lcfa-setup-review">';
        echo '<div><dt>' . esc_html__('Framework', 'livecanvas-forge-ai') . '</dt><dd>' . esc_html($this->get_framework_display_name($framework)) . '</dd></div>';
        echo '<div><dt>' . esc_html__('Site type', 'livecanvas-forge-ai') . '</dt><dd>' . esc_html(ucfirst($site_mode)) . '</dd></div>';
        echo '<div><dt>' . esc_html__('Coding agent', 'livecanvas-forge-ai') . '</dt><dd>' . esc_html(ucfirst(str_replace('-', ' ', $ai_tool))) . '</dd></div>';
        echo '<div><dt>' . esc_html__('Write tools', 'livecanvas-forge-ai') . '</dt><dd>' . esc_html($full_access ? __('Enabled with guardrails', 'livecanvas-forge-ai') : __('Preview only', 'livecanvas-forge-ai')) . '</dd></div>';
        echo '</dl>';

        echo '<div class="lcfa-next-action">';
        echo '<strong>' . esc_html__('Next action', 'livecanvas-forge-ai') . '</strong>';
        echo '<p>' . esc_html(sprintf(__('Connect %s, verify the site identity, and run the smoke test.', 'livecanvas-forge-ai'), ucfirst(str_replace('-', ' ', $ai_tool)))) . '</p>';
        echo '</div>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('lcfa_setup');
        echo '<input type="hidden" name="action" value="lcfa_setup">';
        echo '<input type="hidden" name="step" value="6">';
        echo '<button class="button button-primary" type="submit">' . esc_html__('Finish setup and open Connections', 'livecanvas-forge-ai') . '</button>';
        echo '</form>';
        echo '</section>';
    }

    private function render_preflight_step(array $snapshot): void {
        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('shield-check');
        echo '<div><h2>' . esc_html__('Check this WordPress site', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('AI Bridge needs an active LiveCanvas license and a compatible theme stack. The checks below do not change content.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<div class="lcfa-status-list">';
        $this->render_status_row(
            __('LiveCanvas plugin and license active', 'livecanvas-forge-ai'),
            !empty($snapshot['livecanvas_installed']) && !empty($snapshot['livecanvas_active']) && !empty($snapshot['livecanvas_license_active']),
            !empty($snapshot['livecanvas_license_active'])
                ? __('Plugin active with license/API key detected.', 'livecanvas-forge-ai')
                : __('Plugin or license/API key missing.', 'livecanvas-forge-ai')
        );
        $theme_stack_ready = $this->has_livecanvas_theme_stack($snapshot);
        $this->render_status_row(
            __('Compatible LiveCanvas theme', 'livecanvas-forge-ai'),
            $theme_stack_ready ? true : null,
            $theme_stack_ready
                ? $this->get_preflight_theme_summary($snapshot)
                : __('No compatible theme is installed. Continue below, then choose Picostrap or Picowind.', 'livecanvas-forge-ai'),
            __('Choose theme', 'livecanvas-forge-ai'),
            'layers'
        );

        if ($this->has_picowind_stack($snapshot)) {
            $this->render_status_row(
                __('WindPress active for Picowind', 'livecanvas-forge-ai'),
                !empty($snapshot['windpress_installed']) && !empty($snapshot['windpress_active']) ? true : null,
                !empty($snapshot['windpress_active'])
                    ? __('WindPress is active.', 'livecanvas-forge-ai')
                    : __('AI Bridge will install or activate WindPress when Picowind is confirmed.', 'livecanvas-forge-ai')
            );
        }
        echo '</div>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form">';
        wp_nonce_field('lcfa_setup');
        echo '<input type="hidden" name="action" value="lcfa_setup">';
        echo '<input type="hidden" name="step" value="1">';

        if (!$snapshot['livecanvas_installed']) {
            echo '<div class="notice notice-error inline"><p>' . esc_html__('LiveCanvas is not installed. The wizard stops here until the primary plugin is installed.', 'livecanvas-forge-ai') . '</p></div>';
        } elseif (!$snapshot['livecanvas_active']) {
            echo '<p>' . esc_html__('LiveCanvas is installed but inactive. You can activate it directly from this screen.', 'livecanvas-forge-ai') . '</p>';
            echo '<button class="button button-primary" name="activate_livecanvas" value="1">' . esc_html__('Activate LiveCanvas', 'livecanvas-forge-ai') . '</button>';
        } elseif (!$this->is_preflight_ready($snapshot)) {
            echo '<div class="notice notice-error inline"><p>' . esc_html($this->get_preflight_blocking_message($snapshot)) . '</p></div>';
        } else {
            $ready_copy = $theme_stack_ready
                ? __('Core requirements passed. Confirm the detected project settings next.', 'livecanvas-forge-ai')
                : __('LiveCanvas is ready. Next, choose the frontend stack AI Bridge should install.', 'livecanvas-forge-ai');
            echo '<p>' . esc_html($ready_copy) . '</p>';
            $continue_label = $theme_stack_ready
                ? __('Review project settings', 'livecanvas-forge-ai')
                : __('Choose frontend framework', 'livecanvas-forge-ai');
            echo '<button class="button button-primary lcfa-button-with-icon">' . $this->get_icon_svg('layers') . '<span>' . esc_html($continue_label) . '</span></button>';
        }

        echo '</form>';
        echo '</section>';
    }

    private function render_framework_step(array $settings, array $snapshot): void {
        $selected = $settings['framework'] ?: $snapshot['detected_framework'];

        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('layers');
        echo '<div><h2>' . esc_html__('Step 2. Frontend framework', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Confirm whether this site should run on Picostrap or Picowind. The wizard detects the current theme and can switch to the correct stack.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form" data-lcfa-framework-form>';
        wp_nonce_field('lcfa_setup');
        echo '<input type="hidden" name="action" value="lcfa_setup">';
        echo '<input type="hidden" name="step" value="2">';

        echo '<div class="lcfa-choice-grid">';
        $this->render_framework_choice(
            'picostrap',
            __('Picostrap / Bootstrap', 'livecanvas-forge-ai'),
            __('Recommended for classic Bootstrap-based LiveCanvas flows and Picostrap child themes.', 'livecanvas-forge-ai'),
            $selected,
            $snapshot['picostrap_candidates'],
            $snapshot
        );
        $this->render_framework_choice(
            'picowind',
            __('Picowind / Tailwind + WindPress', 'livecanvas-forge-ai'),
            __('Recommended for Tailwind-first builds, Picowind child themes, and WindPress-managed styling.', 'livecanvas-forge-ai'),
            $selected,
            $snapshot['picowind_candidates'],
            $snapshot
        );
        echo '</div>';

        $has_selection = in_array($selected, ['picostrap', 'picowind'], true);
        $submit_label = $has_selection
            ? $this->get_framework_submit_label($selected, $snapshot)
            : __('Choose a framework above', 'livecanvas-forge-ai');
        $submit_note = $has_selection
            ? $this->get_framework_submit_note($selected, $snapshot)
            : __('Select one stack to see exactly what AI Bridge will install or activate.', 'livecanvas-forge-ai');
        echo '<div class="lcfa-framework-submit">';
        echo '<p data-lcfa-framework-submit-note>' . esc_html($submit_note) . '</p>';
        echo '<button class="button button-primary lcfa-button-with-icon" data-lcfa-framework-submit type="submit"' . ($has_selection ? '' : ' disabled') . '>';
        echo $this->get_icon_svg('layers');
        echo '<span data-lcfa-framework-submit-label>' . esc_html($submit_label) . '</span>';
        echo '</button>';
        echo '</div>';
        echo '</form>';
        echo '</section>';
    }

    private function render_site_mode_step(array $settings, array $snapshot): void {
        $selected = $settings['site_mode'] ?: $snapshot['site_mode'];

        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('globe');
        echo '<div><h2>' . esc_html__('Step 3. Site profile', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('This decision does not change the core plugin. It changes the connection guide and the recommended auth flow shown to AI clients.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form">';
        wp_nonce_field('lcfa_setup');
        echo '<input type="hidden" name="action" value="lcfa_setup">';
        echo '<input type="hidden" name="step" value="3">';

        echo '<div class="lcfa-radio-group lcfa-radio-group--inline">';
        $this->render_radio('site_mode', 'local', __('This WordPress runs locally', 'livecanvas-forge-ai'), $selected, 'laptop');
        $this->render_radio('site_mode', 'remote', __('This WordPress runs remotely', 'livecanvas-forge-ai'), $selected, 'cloud');
        $this->render_radio('site_mode', 'hybrid', __('I will use both local and remote targets', 'livecanvas-forge-ai'), $selected, 'shuffle');
        echo '</div>';

        echo '<button class="button button-primary">' . esc_html__('Save site profile', 'livecanvas-forge-ai') . '</button>';
        echo '</form>';
        echo '</section>';
    }

    private function render_ai_tool_step(array $settings): void {
        $selected  = $settings['ai_tool'] ?: 'codex';
        if ($selected === 'claude-code') {
            $selected = 'claude';
        }
        $site_mode = LCFA_Settings::get()['site_mode'] ?: 'local';

        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('command');
        echo '<div><h2>' . esc_html__('Step 4. AI Coding Agent', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Choose the main coding agent you want to use first. The setup guide adapts to the current site profile and connection strategy.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form">';
        wp_nonce_field('lcfa_setup');
        echo '<input type="hidden" name="action" value="lcfa_setup">';
        echo '<input type="hidden" name="step" value="4">';
        echo '<div class="lcfa-radio-group lcfa-radio-group--inline">';
        $this->render_radio('ai_tool', 'codex', __('Codex', 'livecanvas-forge-ai'), $selected, 'stars');
        $this->render_radio('ai_tool', 'opencode', __('OpenCode', 'livecanvas-forge-ai'), $selected, 'braces');
        $this->render_radio('ai_tool', 'claude', __('Claude', 'livecanvas-forge-ai'), $selected, 'cpu');
        $this->render_radio('ai_tool', 'cursor', __('Cursor', 'livecanvas-forge-ai'), $selected, 'cursor');
        $this->render_radio('ai_tool', 'other', __('Other compatible client', 'livecanvas-forge-ai'), $selected, 'plug');
        echo '</div>';
        echo '<button class="button button-primary">' . esc_html__('Save AI Coding Agent', 'livecanvas-forge-ai') . '</button>';
        echo '</form>';

        $guides = $this->get_tool_guides($site_mode);
        $guide  = $guides[$selected] ?? ($selected === 'claude-code' ? ($guides['claude'] ?? $guides['other']) : $guides['other']);

        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('Configuration guide', 'livecanvas-forge-ai') . '</h3>';
        echo '<p>' . esc_html($guide['summary']) . '</p>';
        echo '<ul class="lcfa-bullets">';
        foreach ($guide['steps'] as $line) {
            echo '<li>' . esc_html($line) . '</li>';
        }
        echo '</ul>';
        echo '</div>';
        echo '</section>';
    }

    private function render_permissions_step(array $settings): void {
        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('shield-lock');
        echo '<div><h2>' . esc_html__('Step 5. Enable Full Access', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Continue only if you want AI Bridge to operate with the broadest execution scope for this project.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-form">';
        wp_nonce_field('lcfa_setup');
        echo '<input type="hidden" name="action" value="lcfa_setup">';
        echo '<input type="hidden" name="step" value="5">';

        echo '<p>' . esc_html__('This grants the companion the broadest operating scope: it can create and update pages, sections, templates, headers, footers, and other advanced outputs without stopping on intermediate policy choices.', 'livecanvas-forge-ai') . '</p>';
        echo '<ul class="lcfa-bullets">';
        echo '<li>' . esc_html__('Advanced template actions are enabled immediately.', 'livecanvas-forge-ai') . '</li>';
        echo '<li>' . esc_html__('Theme or PHP file fallback is allowed only as a last resort when the active stack requires it.', 'livecanvas-forge-ai') . '</li>';
        echo '<li>' . esc_html__('By continuing, you are explicitly authorizing AI Bridge to operate with these permissions on this site.', 'livecanvas-forge-ai') . '</li>';
        echo '</ul>';

        echo '<button class="button button-primary">' . esc_html__('Continue', 'livecanvas-forge-ai') . '</button>';
        echo '</form>';
        echo '</section>';
    }

    private function render_finish_step(array $settings, array $snapshot): void {
        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('rocket');
        echo '<div><h2>' . esc_html__('Step 6. Finish setup', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('The stack is profiled. The next useful move is to open Connections, verify the coding agent link, then save the project brief when you want a reusable build plan.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<ul class="lcfa-bullets">';
        echo '<li>' . esc_html(sprintf(__('Confirmed framework: %s.', 'livecanvas-forge-ai'), $settings['framework'] ?: $snapshot['detected_framework'])) . '</li>';
        echo '<li>' . esc_html(sprintf(__('Site profile: %s.', 'livecanvas-forge-ai'), $settings['site_mode'] ?: $snapshot['site_mode'])) . '</li>';
        echo '<li>' . esc_html(sprintf(__('Primary AI client: %s.', 'livecanvas-forge-ai'), $settings['ai_tool'] ?: 'codex')) . '</li>';
        echo '<li>' . esc_html__('Access mode: Full access enabled.', 'livecanvas-forge-ai') . '</li>';
        echo '<li>' . esc_html__('Fallback policy: theme or PHP file fallback is available only as a last resort.', 'livecanvas-forge-ai') . '</li>';
        echo '</ul>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('lcfa_setup');
        echo '<input type="hidden" name="action" value="lcfa_setup">';
        echo '<input type="hidden" name="step" value="6">';
        echo '<button class="button button-primary">' . esc_html__('Complete Bridge Setup', 'livecanvas-forge-ai') . '</button>';
        echo '</form>';
        echo '</section>';
    }

    private function render_setup_reset_panel(): void {
        echo '<details class="lcfa-technical-details lcfa-reset-setup">';
        echo '<summary>' . esc_html__('Reset setup', 'livecanvas-forge-ai') . '</summary>';
        echo '<div class="lcfa-technical-details__body">';
        echo '<p>' . esc_html__('Reset clears the connection state and rotates the MCP token. It keeps WordPress content, the project brief, command history, and existing workspace files.', 'livecanvas-forge-ai') . '</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
        wp_nonce_field('lcfa_reset_setup');
        echo '<input type="hidden" name="action" value="lcfa_reset_setup">';
        echo '<button class="button" type="submit">' . esc_html__('Reset setup and start again', 'livecanvas-forge-ai') . '</button>';
        echo '</form>';
        echo '</div>';
        echo '</details>';
    }

    private function render_step_nav(int $current_step, array $settings, array $snapshot): void {
        $steps = [
            1 => ['label' => __('Preflight', 'livecanvas-forge-ai'), 'icon' => 'shield-check'],
            2 => ['label' => __('Framework', 'livecanvas-forge-ai'), 'icon' => 'layers'],
            3 => ['label' => __('Site', 'livecanvas-forge-ai'), 'icon' => 'globe'],
            4 => ['label' => __('AI Coding Agent', 'livecanvas-forge-ai'), 'icon' => 'command'],
            5 => ['label' => __('Access', 'livecanvas-forge-ai'), 'icon' => 'shield-lock'],
            6 => ['label' => __('Finish', 'livecanvas-forge-ai'), 'icon' => 'rocket'],
        ];

        echo '<nav class="lcfa-steps">';

        foreach ($steps as $step => $data) {
            $is_locked = $step > 1 && !$snapshot['livecanvas_active'];
            $classes   = ['lcfa-step'];
            $label     = $step . '. ' . $data['label'];

            if ($step === $current_step) {
                $classes[] = 'is-current';
            }

            if ((int) $settings['last_completed_step'] >= $step) {
                $classes[] = 'is-done';
            }

            $content = '<span class="lcfa-step-icon-wrap">' . $this->get_icon_svg($data['icon']) . '</span><span>' . esc_html($label) . '</span>';

            if ($is_locked) {
                echo '<span class="' . esc_attr(implode(' ', $classes)) . '">' . $content . '</span>';
                continue;
            }

            echo '<a class="' . esc_attr(implode(' ', $classes)) . '" href="' . esc_url(admin_url('admin.php?page=lcfa-dashboard&tab=setup&step=' . $step)) . '">' . $content . '</a>';
        }

        echo '</nav>';
    }

    private function render_snapshot_card(array $snapshot, array $settings): void {
        $is_picostrap = (string) ($snapshot['detected_framework'] ?? '') === 'picostrap';
        $windpress_caption = $is_picostrap
            ? (!empty($snapshot['windpress_active'])
                ? __('Active, not used by Picostrap', 'livecanvas-forge-ai')
                : __('Not required by Picostrap', 'livecanvas-forge-ai'))
            : (!empty($snapshot['windpress_active'])
                ? __('Active', 'livecanvas-forge-ai')
                : (!empty($snapshot['windpress_installed']) ? __('Installed', 'livecanvas-forge-ai') : __('Not installed', 'livecanvas-forge-ai')));

        echo '<section class="lcfa-card lcfa-snapshot-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('activity');
        echo '<div><h2>' . esc_html__('Stack snapshot', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Live runtime, active theme, and editor profile as detected right now.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<div class="lcfa-brand-grid">';
        $this->render_brand_tile(
            __('LiveCanvas', 'livecanvas-forge-ai'),
            $this->get_partner_logo('livecanvas-micro'),
            $snapshot['livecanvas_active'] ? __('Active', 'livecanvas-forge-ai') : __('Missing or inactive', 'livecanvas-forge-ai'),
            $snapshot['livecanvas_active'] ? 'active' : 'other'
        );
        $this->render_brand_tile(
            $snapshot['detected_framework'] === 'picowind' ? __('Picowind', 'livecanvas-forge-ai') : __('Bootstrap', 'livecanvas-forge-ai'),
            $snapshot['detected_framework'] === 'picowind' ? $this->get_icon_svg('wind') : $this->get_partner_logo('bootstrap'),
            $snapshot['framework_slug'] ?: __('No editor config detected', 'livecanvas-forge-ai'),
            'other'
        );
        $this->render_brand_tile(
            __('WindPress', 'livecanvas-forge-ai'),
            $this->get_partner_logo('windpress'),
            $windpress_caption,
            !$is_picostrap && !empty($snapshot['windpress_active']) ? 'active' : 'other'
        );
        echo '</div>';

        echo '<ul class="lcfa-facts">';
        $this->render_fact_row(__('Theme', 'livecanvas-forge-ai'), $snapshot['current_theme_name'], 'active');
        $this->render_fact_row(__('Detected framework', 'livecanvas-forge-ai'), $snapshot['detected_framework'], $snapshot['detected_framework'] !== 'unknown' ? 'active' : 'other');
        $this->render_fact_row(__('Editor config', 'livecanvas-forge-ai'), $snapshot['framework_slug'] ?: 'n/a', $snapshot['framework_slug'] ? 'active' : 'other');
        $this->render_fact_row(__('Site profile', 'livecanvas-forge-ai'), $settings['site_mode'] ?: $snapshot['site_mode'], !empty($settings['site_mode']) ? 'active' : 'other');
        $this->render_fact_row(__('Tangible', 'livecanvas-forge-ai'), $snapshot['tangible_available'] ? __('Available', 'livecanvas-forge-ai') : __('Unavailable', 'livecanvas-forge-ai'), $snapshot['tangible_available'] ? 'active' : 'other');
        $this->render_fact_row(__('WooCommerce', 'livecanvas-forge-ai'), $snapshot['woocommerce_active'] ? __('Detected', 'livecanvas-forge-ai') : __('Not detected', 'livecanvas-forge-ai'), $snapshot['woocommerce_active'] ? 'active' : 'other');
        $this->render_fact_row(__('ACF', 'livecanvas-forge-ai'), $snapshot['acf_active'] ? __('Detected', 'livecanvas-forge-ai') : __('Not detected', 'livecanvas-forge-ai'), $snapshot['acf_active'] ? 'active' : 'other');
        echo '</ul>';
        echo '</section>';
    }

    private function render_framework_choice(string $value, string $title, string $description, string $selected, array $candidates, array $snapshot = []): void {
        $logo_markup = $value === 'picowind'
            ? $this->get_partner_logo('windpress')
            : $this->get_partner_logo('bootstrap');
        $candidate_summary = $candidates
            ? sprintf(__('Detected theme candidates: %s', 'livecanvas-forge-ai'), implode(', ', wp_list_pluck($candidates, 'stylesheet')))
            : __('No installed themes were detected for this family yet.', 'livecanvas-forge-ai');

        $submit_label = $this->get_framework_submit_label($value, $snapshot);
        $submit_note = $this->get_framework_submit_note($value, $snapshot);

        echo '<label class="lcfa-choice-card">';
        echo '<input type="radio" name="framework" value="' . esc_attr($value) . '" data-lcfa-framework-label="' . esc_attr($submit_label) . '" data-lcfa-framework-note="' . esc_attr($submit_note) . '" data-lcfa-framework-progress="' . esc_attr(sprintf(__('Preparing %s...', 'livecanvas-forge-ai'), $this->get_framework_display_name($value))) . '"' . checked($selected, $value, false) . '>';
        echo '<span class="lcfa-choice-copy">';
        echo '<span class="lcfa-choice-media">' . $logo_markup . '</span>';
        echo '<strong>' . esc_html($title) . '</strong>';
        echo '<span>' . esc_html($description) . '</span>';
        echo '<small>' . esc_html($candidate_summary) . '</small>';

        if ($value === 'picowind' && (!$candidates || empty($snapshot['windpress_active']))) {
            $windpress_ready = !empty($snapshot['windpress_active']);
            $picowind_ready = !empty($candidates);
            echo '<span class="lcfa-framework-plan">';
            echo '<strong>' . esc_html__('Automatic setup order', 'livecanvas-forge-ai') . '</strong>';
            $this->render_framework_plan_step(
                1,
                __('WindPress plugin', 'livecanvas-forge-ai'),
                $windpress_ready
                    ? __('Active', 'livecanvas-forge-ai')
                    : (!empty($snapshot['windpress_installed']) ? __('Activate first', 'livecanvas-forge-ai') : __('Install first from WordPress.org', 'livecanvas-forge-ai')),
                $windpress_ready
            );
            $this->render_framework_plan_step(
                2,
                __('Picowind theme', 'livecanvas-forge-ai'),
                $picowind_ready ? __('Installed', 'livecanvas-forge-ai') : __('Download second from GitHub', 'livecanvas-forge-ai'),
                $picowind_ready
            );
            $this->render_framework_plan_step(
                3,
                __('Activate Picowind', 'livecanvas-forge-ai'),
                (string) ($snapshot['detected_framework'] ?? '') === 'picowind'
                    ? __('Current theme', 'livecanvas-forge-ai')
                    : __('Final step', 'livecanvas-forge-ai'),
                (string) ($snapshot['detected_framework'] ?? '') === 'picowind'
            );
            echo '</span>';
        }

        echo '</span>';
        echo '</label>';
    }

    private function render_framework_plan_step(int $number, string $label, string $status, bool $complete): void {
        echo '<span class="lcfa-framework-plan__step' . ($complete ? ' is-complete' : '') . '">';
        echo '<span class="lcfa-framework-plan__marker">' . ($complete ? $this->get_icon_svg('check-circle') : esc_html((string) $number)) . '</span>';
        echo '<span class="lcfa-framework-plan__copy"><b>' . esc_html($label) . '</b><small>' . esc_html($status) . '</small></span>';
        echo '</span>';
    }

    private function get_framework_submit_label(string $framework, array $snapshot): string {
        if ($framework === 'picowind') {
            $windpress_active = !empty($snapshot['windpress_active']);
            $windpress_installed = !empty($snapshot['windpress_installed']);
            $picowind_installed = !empty($snapshot['picowind_candidates']);

            if (!$windpress_active) {
                $windpress_action = $windpress_installed ? __('Activate WindPress', 'livecanvas-forge-ai') : __('Install WindPress', 'livecanvas-forge-ai');

                return $picowind_installed
                    ? sprintf(__('%s and use Picowind', 'livecanvas-forge-ai'), $windpress_action)
                    : sprintf(__('%s + Picowind', 'livecanvas-forge-ai'), $windpress_action);
            }

            return $picowind_installed
                ? __('Use Picowind', 'livecanvas-forge-ai')
                : __('Install and activate Picowind', 'livecanvas-forge-ai');
        }

        return !empty($snapshot['picostrap_candidates'])
            ? __('Use Picostrap', 'livecanvas-forge-ai')
            : __('Set up Picostrap', 'livecanvas-forge-ai');
    }

    private function get_framework_submit_note(string $framework, array $snapshot): string {
        if ($framework === 'picowind') {
            $windpress_active = !empty($snapshot['windpress_active']);
            $picowind_installed = !empty($snapshot['picowind_candidates']);

            if (!$windpress_active && !$picowind_installed) {
                return __('AI Bridge installs and activates WindPress from WordPress.org first, then downloads and activates Picowind from GitHub.', 'livecanvas-forge-ai');
            }

            if (!$windpress_active) {
                return __('AI Bridge activates WindPress before switching to the installed Picowind theme.', 'livecanvas-forge-ai');
            }

            if (!$picowind_installed) {
                return __('WindPress is ready. AI Bridge will download and activate Picowind from GitHub.', 'livecanvas-forge-ai');
            }

            return __('WindPress and Picowind are ready. AI Bridge will activate the selected stack.', 'livecanvas-forge-ai');
        }

        return !empty($snapshot['picostrap_candidates'])
            ? __('AI Bridge will activate the installed Picostrap stack. WindPress is not required.', 'livecanvas-forge-ai')
            : __('AI Bridge will use the configured Picostrap package source. WindPress is not required.', 'livecanvas-forge-ai');
    }

    private function render_status_row(string $label, ?bool $status, string $detail = '', string $pending_label = '', string $pending_icon = ''): void {
        $status_class = $status === true ? 'ok' : ($status === false ? 'ko' : 'pending');
        $status_icon = $status === true ? 'check-circle' : ($status === false ? 'x-circle' : ($pending_icon ?: 'activity'));
        $status_label = $status === true
            ? __('OK', 'livecanvas-forge-ai')
            : ($status === false ? __('Fix', 'livecanvas-forge-ai') : ($pending_label ?: __('Action required', 'livecanvas-forge-ai')));
        echo '<div class="lcfa-status-row">';
        echo '<span class="lcfa-status-copy">';
        echo '<span class="lcfa-status-label">' . esc_html($label) . '</span>';
        if ($detail !== '') {
            echo '<small>' . esc_html($detail) . '</small>';
        }
        echo '</span>';
        echo '<strong class="' . esc_attr($status_class) . '">' . $this->get_icon_svg($status_icon) . '<span>' . esc_html($status_label) . '</span></strong>';
        echo '</div>';
    }

    private function is_preflight_ready(array $snapshot): bool {
        if (empty($snapshot['livecanvas_installed']) || empty($snapshot['livecanvas_active']) || empty($snapshot['livecanvas_license_active'])) {
            return false;
        }

        return true;
    }

    private function get_preflight_blocking_message(array $snapshot): string {
        if (empty($snapshot['livecanvas_installed'])) {
            return __('LiveCanvas is not installed. The wizard stops here until the primary plugin is installed.', 'livecanvas-forge-ai');
        }

        if (empty($snapshot['livecanvas_active'])) {
            return __('LiveCanvas is installed but inactive. Activate it before continuing.', 'livecanvas-forge-ai');
        }

        if (empty($snapshot['livecanvas_license_active'])) {
            return __('LiveCanvas is active, but its license/API key is not active. Activate LiveCanvas before continuing.', 'livecanvas-forge-ai');
        }

        return __('Complete the LiveCanvas preflight before continuing.', 'livecanvas-forge-ai');
    }

    private function has_livecanvas_theme_stack(array $snapshot): bool {
        if (!empty($snapshot['picostrap_candidates']) || !empty($snapshot['picowind_candidates'])) {
            return true;
        }

        return in_array((string) ($snapshot['detected_framework'] ?? ''), ['picostrap', 'picowind'], true);
    }

    private function has_picowind_stack(array $snapshot): bool {
        return !empty($snapshot['picowind_candidates']) || (string) ($snapshot['detected_framework'] ?? '') === 'picowind';
    }

    private function normalize_supported_framework(string $framework): string {
        $framework = $this->sanitize_key_compat($framework);

        return in_array($framework, ['picostrap', 'picowind'], true) ? $framework : '';
    }

    private function get_framework_display_name(string $framework): string {
        $framework = $this->normalize_supported_framework($framework);

        if ($framework === 'picowind') {
            return __('Picowind / Tailwind + WindPress', 'livecanvas-forge-ai');
        }

        if ($framework === 'picostrap') {
            return __('Picostrap / Bootstrap', 'livecanvas-forge-ai');
        }

        return ucfirst(str_replace('-', ' ', $framework));
    }

    private function get_preflight_theme_summary(array $snapshot): string {
        $groups = [];
        $picostrap = $this->format_theme_candidate_names((array) ($snapshot['picostrap_candidates'] ?? []));
        $picowind = $this->format_theme_candidate_names((array) ($snapshot['picowind_candidates'] ?? []));

        if ($picostrap !== '') {
            $groups[] = sprintf(__('Picostrap: %s', 'livecanvas-forge-ai'), $picostrap);
        }

        if ($picowind !== '') {
            $groups[] = sprintf(__('Picowind: %s', 'livecanvas-forge-ai'), $picowind);
        }

        if ($groups) {
            return implode(' · ', $groups);
        }

        $detected = (string) ($snapshot['detected_framework'] ?? '');
        if (in_array($detected, ['picostrap', 'picowind'], true)) {
            return sprintf(__('Active stack detected as %s, but no installed theme candidate list was returned.', 'livecanvas-forge-ai'), $detected);
        }

        return __('No Picostrap or Picowind themes detected.', 'livecanvas-forge-ai');
    }

    private function format_theme_candidate_names(array $candidates): string {
        $names = [];

        foreach ($candidates as $candidate) {
            if (!is_array($candidate)) {
                continue;
            }

            $name = trim((string) ($candidate['stylesheet'] ?? ''));
            if ($name === '') {
                $name = trim((string) ($candidate['name'] ?? ''));
            }

            if ($name !== '') {
                $names[] = $name;
            }
        }

        $names = array_values(array_unique($names));

        return implode(', ', $names);
    }

    private function render_radio(string $name, string $value, string $label, string $selected, string $icon, string $description = ''): void {
        echo '<label class="lcfa-radio">';
        echo '<input class="lcfa-radio-input" type="radio" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '"' . checked($selected, $value, false) . '>';
        echo '<span class="lcfa-radio-icon">' . $this->get_radio_icon_markup($name, $value, $icon) . '</span>';
        echo '<span class="lcfa-radio-copy">' . esc_html($label);
        if ($description !== '') {
            echo '<small>' . esc_html($description) . '</small>';
        }
        echo '</span>';
        echo '</label>';
    }

    private function render_notice(?array $notice): void {
        if (!$notice) {
            return;
        }

        $class = $notice['type'] === 'error' ? 'notice notice-error' : 'notice notice-success';
        echo '<div class="' . esc_attr($class) . '"><p>' . esc_html($notice['message']) . '</p></div>';
    }

    private function render_page_header(string $tab, array $snapshot, array $settings): void {
        $hero = $this->admin_hero_presenter->build($tab, $snapshot, $settings);

        echo '<header class="lcfa-hero">';
        echo '<div class="lcfa-hero-main">';
        echo '<div class="lcfa-hero-copy">';
        echo '<div class="lcfa-product-id">';
        echo '<span class="lcfa-product-id__brand" aria-hidden="true">' . $this->get_partner_logo('livecanvas') . '</span>';
        echo '<strong>' . esc_html__('AI Bridge', 'livecanvas-forge-ai') . '</strong>';
        echo '</div>';
        echo '<h1>' . esc_html((string) ($hero['title'] ?? '')) . '</h1>';
        echo '<p class="lcfa-lead">' . esc_html((string) ($hero['subtitle'] ?? '')) . '</p>';
        echo '</div>';
        echo '<div class="lcfa-hero-meta">';
        echo '<div class="lcfa-hero-stack">';
        foreach ((array) ($hero['marks'] ?? []) as $mark) {
            if (!is_array($mark)) {
                continue;
            }

            $this->render_admin_hero_mark($mark);
        }
        echo '</div>';
        echo '<dl class="lcfa-hero-chips" aria-label="' . esc_attr__('Project context', 'livecanvas-forge-ai') . '">';
        foreach ((array) ($hero['chips'] ?? []) as $chip) {
            if (!is_array($chip)) {
                continue;
            }

            $this->render_admin_hero_chip($chip);
        }
        echo '</dl>';
        echo '<details class="lcfa-hero-details-panel">';
        echo '<summary class="lcfa-hero-details-toggle" aria-label="' . esc_attr__('Details', 'livecanvas-forge-ai') . '"><span class="lcfa-hero-details-toggle__icon" aria-hidden="true">i</span><span class="screen-reader-text">' . esc_html__('Details', 'livecanvas-forge-ai') . '</span></summary>';
        echo '<div class="lcfa-hero-details">';
        foreach ((array) ($hero['details'] ?? []) as $detail) {
            if (!is_array($detail)) {
                continue;
            }

            echo '<div class="lcfa-hero-detail">';
            echo '<span class="lcfa-hero-detail-label">' . esc_html((string) ($detail['label'] ?? '')) . '</span>';
            echo '<strong class="lcfa-hero-detail-value">' . esc_html((string) ($detail['value'] ?? '')) . '</strong>';
            echo '</div>';
        }
        echo '</div>';
        echo '</details>';
        echo '</div>';
        echo '</header>';
    }

    private function render_admin_hero_mark(array $mark): void {
        $asset = (string) ($mark['asset'] ?? '');
        $label = (string) ($mark['label'] ?? '');
        $active = !empty($mark['active']);
        $type = (string) ($mark['type'] ?? 'partner');
        $media = $type === 'icon'
            ? $this->get_icon_svg($asset ?: 'stars')
            : $this->get_partner_logo($asset ?: 'livecanvas-micro');

        echo '<span class="lcfa-hero-mark' . ($active ? ' is-active' : '') . '" aria-label="' . esc_attr($label) . '" title="' . esc_attr($label) . '">';
        echo '<span class="lcfa-hero-mark-media">' . $media . '</span>';
        echo '</span>';
    }

    private function render_admin_hero_chip(array $chip): void {
        $tone = in_array((string) ($chip['tone'] ?? 'other'), ['active', 'other'], true) ? (string) $chip['tone'] : 'other';
        $label = (string) ($chip['label'] ?? '');
        $value = (string) ($chip['value'] ?? '');
        $client = (string) ($chip['client'] ?? '');

        echo '<div class="lcfa-hero-chip is-' . esc_attr($tone) . '">';
        if ($client !== '') {
            echo '<span class="lcfa-hero-chip-media">' . $this->get_agent_icon_markup($client, $this->get_client_fallback_icon($client), 'lcfa-agent-icon lcfa-agent-icon--sm') . '</span>';
        }
        echo '<dt>' . esc_html($label) . '</dt>';
        echo '<dd>' . esc_html($value) . '</dd>';
        echo '</div>';
    }

    private function render_brand_tile(string $title, string $logo_markup, string $caption, string $tone = 'other'): void {
        $tone_class = in_array($tone, ['active', 'other'], true) ? $tone : 'other';

        echo '<div class="lcfa-brand-tile is-' . esc_attr($tone_class) . '">';
        echo '<div class="lcfa-brand-logo">' . $logo_markup . '</div>';
        echo '<strong>' . esc_html($title) . '</strong>';
        echo '<span class="lcfa-brand-caption">' . esc_html($caption) . '</span>';
        echo '</div>';
    }

    private function render_fact_row(string $label, string $value, string $tone = 'other'): void {
        $tone_class = in_array($tone, ['active', 'other'], true) ? $tone : 'other';

        echo '<li><strong>' . esc_html($label) . ':</strong> <span class="lcfa-fact-value is-' . esc_attr($tone_class) . '">' . esc_html($value) . '</span></li>';
    }

    private function render_badge(string $label, string $value, string $tone = 'other'): void {
        $tone_class = in_array($tone, ['active', 'other'], true) ? $tone : 'other';

        echo '<span class="lcfa-badge is-' . esc_attr($tone_class) . '"><strong>' . esc_html($label) . '</strong><span>' . esc_html($value) . '</span></span>';
    }

    private function render_command_thread_panel(array $current_thread, array $thread_summaries, array $command_context = []): void {
        $current_thread_id = (string) ($current_thread['id'] ?? 'default');
        $messages = array_reverse((array) ($current_thread['messages'] ?? []));

        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('activity');
        echo '<div><h2>' . esc_html__('Command thread', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('Keep requests, execution notes, and results in one persistent thread instead of losing them between runs.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        echo '<div class="lcfa-thread-toolbar">';
        echo '<div class="lcfa-chip-row">';
        foreach (array_slice($thread_summaries, 0, 8) as $thread_summary) {
            if (!is_array($thread_summary)) {
                continue;
            }

            $thread_id = (string) ($thread_summary['id'] ?? '');
            $thread_url_args = [
                'thread_id' => $thread_id,
            ];

            if (!empty($command_context['context_post_id'])) {
                $thread_url_args['post_id'] = absint($command_context['context_post_id']);
            }

            if (!empty($command_context['genesis_task_id'])) {
                $thread_url_args['genesis_task_id'] = sanitize_key((string) $command_context['genesis_task_id']);
            }

            if (!empty($command_context['user_prompt'])) {
                $thread_url_args['user_prompt'] = sanitize_textarea_field((string) $command_context['user_prompt']);
            }

            $thread_url = $this->get_command_url($thread_url_args);

            echo '<a class="lcfa-thread-switch' . ($thread_id === $current_thread_id ? ' is-current' : '') . '" href="' . esc_url($thread_url) . '">';
            echo '<strong>' . esc_html((string) ($thread_summary['title'] ?? __('Thread', 'livecanvas-forge-ai'))) . '</strong>';
            echo '<span>' . esc_html(sprintf(_n('%d message', '%d messages', (int) ($thread_summary['message_count'] ?? 0), 'livecanvas-forge-ai'), (int) ($thread_summary['message_count'] ?? 0))) . '</span>';
            echo '</a>';
        }
        echo '</div>';

        echo '<details class="lcfa-command-details" data-lcfa-command-thread-tools>';
        echo '<summary>' . esc_html__('Thread tools', 'livecanvas-forge-ai') . '</summary>';
        echo '<div class="lcfa-command-details__body">';
        echo '<div class="lcfa-cta-row">';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-thread-form">';
        wp_nonce_field('lcfa_command');
        echo '<input type="hidden" name="action" value="lcfa_command">';
        echo '<input type="hidden" name="thread_operation" value="create">';
        echo '<input type="hidden" name="thread_id" value="' . esc_attr($current_thread_id) . '">';
        $this->render_command_thread_context_inputs($command_context);
        echo '<input type="text" name="thread_title" value="" placeholder="' . esc_attr__('New thread title', 'livecanvas-forge-ai') . '">';
        echo '<button class="button" type="submit">' . esc_html__('New thread', 'livecanvas-forge-ai') . '</button>';
        echo '</form>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
        wp_nonce_field('lcfa_command');
        echo '<input type="hidden" name="action" value="lcfa_command">';
        echo '<input type="hidden" name="thread_operation" value="duplicate">';
        echo '<input type="hidden" name="thread_id" value="' . esc_attr($current_thread_id) . '">';
        $this->render_command_thread_context_inputs($command_context);
        echo '<button class="button" type="submit">' . esc_html__('Duplicate current', 'livecanvas-forge-ai') . '</button>';
        echo '</form>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-thread-form">';
        wp_nonce_field('lcfa_command');
        echo '<input type="hidden" name="action" value="lcfa_command">';
        echo '<input type="hidden" name="thread_operation" value="rename">';
        echo '<input type="hidden" name="thread_id" value="' . esc_attr($current_thread_id) . '">';
        $this->render_command_thread_context_inputs($command_context);
        echo '<input type="text" name="thread_title" value="' . esc_attr((string) ($current_thread['title'] ?? '')) . '" placeholder="' . esc_attr__('Rename current thread', 'livecanvas-forge-ai') . '">';
        echo '<button class="button" type="submit">' . esc_html__('Rename current', 'livecanvas-forge-ai') . '</button>';
        echo '</form>';

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
        wp_nonce_field('lcfa_command');
        echo '<input type="hidden" name="action" value="lcfa_command">';
        echo '<input type="hidden" name="thread_operation" value="clear">';
        echo '<input type="hidden" name="thread_id" value="' . esc_attr($current_thread_id) . '">';
        $this->render_command_thread_context_inputs($command_context);
        echo '<button class="button" type="submit">' . esc_html__('Clear current', 'livecanvas-forge-ai') . '</button>';
        echo '</form>';

        if ($current_thread_id !== 'default') {
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form">';
            wp_nonce_field('lcfa_command');
            echo '<input type="hidden" name="action" value="lcfa_command">';
            echo '<input type="hidden" name="thread_operation" value="delete">';
            echo '<input type="hidden" name="thread_id" value="' . esc_attr($current_thread_id) . '">';
            $this->render_command_thread_context_inputs($command_context);
            echo '<button class="button" type="submit">' . esc_html__('Delete current', 'livecanvas-forge-ai') . '</button>';
            echo '</form>';
        }

        echo '</div>';
        echo '</div>';
        echo '</details>';
        echo '</div>';

        if (!empty($command_context['context_post_id']) || !empty($command_context['genesis_task_id']) || !empty($command_context['user_prompt'])) {
            echo '<div class="lcfa-guide">';
            echo '<h3>' . esc_html__('Current context', 'livecanvas-forge-ai') . '</h3>';
            echo '<div class="lcfa-chip-row">';

            if (!empty($command_context['context_post_id'])) {
                echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Post %d', 'livecanvas-forge-ai'), absint($command_context['context_post_id']))) . '</span>';
            }

            if (!empty($command_context['genesis_task_id'])) {
                echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Genesis task %s', 'livecanvas-forge-ai'), sanitize_key((string) $command_context['genesis_task_id']))) . '</span>';
            }

            if (!empty($command_context['user_prompt'])) {
                echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Prompt: %s', 'livecanvas-forge-ai'), sanitize_textarea_field((string) $command_context['user_prompt']))) . '</span>';
            }

            echo '</div>';
            echo '</div>';
        }

        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html((string) ($current_thread['title'] ?? __('Thread', 'livecanvas-forge-ai'))) . '</h3>';
        echo '<p>' . esc_html(sprintf(
            __('Current thread ID: %1$s. Messages are persisted and reused across previews and apply runs.', 'livecanvas-forge-ai'),
            $current_thread_id
        )) . '</p>';
        echo '</div>';

        if (!$messages) {
            echo '<p class="lcfa-empty">' . esc_html__('No messages in this thread yet. Start with a request, then run a command to capture the result here.', 'livecanvas-forge-ai') . '</p>';
            echo '</section>';

            return;
        }

        echo '<div class="lcfa-thread-log">';
        foreach (array_slice($messages, -24) as $message) {
            if (!is_array($message)) {
                continue;
            }

            $this->render_command_thread_message($message);
        }
        echo '</div>';
        echo '</section>';
    }

    private function render_command_thread_context_inputs(array $command_context): void {
        if (!empty($command_context['context_post_id'])) {
            echo '<input type="hidden" name="context_post_id" value="' . esc_attr((string) absint($command_context['context_post_id'])) . '">';
        }

        if (!empty($command_context['genesis_task_id'])) {
            echo '<input type="hidden" name="genesis_task_id" value="' . esc_attr((string) sanitize_key((string) $command_context['genesis_task_id'])) . '">';
        }

        if (!empty($command_context['user_prompt'])) {
            echo '<input type="hidden" name="user_prompt" value="' . esc_attr((string) sanitize_textarea_field((string) $command_context['user_prompt'])) . '">';
        }
    }

    private function render_command_thread_message(array $message): void {
        $thread_id = LCFA_Settings::normalize_thread_id((string) ($_GET['thread_id'] ?? 'default'));
        $message = LCFA_Thread_Message_Actions::decorate_message($message, [
            'thread_id' => $thread_id,
            'command_url_builder' => [$this, 'get_command_url'],
        ]);
        $role = in_array($message['role'] ?? '', ['user', 'assistant', 'suggestion_result', 'system', 'tool_result'], true) ? (string) $message['role'] : 'assistant';
        $time = !empty($message['time'])
            ? get_date_from_gmt((string) $message['time'], get_option('date_format') . ' ' . get_option('time_format'))
            : '';
        $label = (string) ($message['label'] ?? '');
        $content = trim((string) ($message['content'] ?? ''));
        $meta = is_array($message['meta'] ?? null) ? $message['meta'] : [];

        echo '<article class="lcfa-thread-message is-' . esc_attr($role) . '">';
        echo '<div class="lcfa-thread-message__head">';
        echo '<strong>' . esc_html($label !== '' ? $label : ucfirst($role)) . '</strong>';
        if ($time !== '') {
            echo '<span>' . esc_html($time) . '</span>';
        }
        echo '</div>';
        if ($content !== '') {
            echo '<div class="lcfa-thread-message__body"><pre>' . esc_html($content) . '</pre></div>';
        }
        $actions = $this->get_thread_message_actions($message);
        if ($actions) {
            $this->render_command_message_actions($actions, $thread_id);
        }
        $meta_badges = $this->get_thread_message_meta_badges($meta);
        if ($meta_badges) {
            echo '<div class="lcfa-chip-row">';
            foreach ($meta_badges as $badge) {
                echo '<span class="lcfa-chip">' . esc_html($badge) . '</span>';
            }
            echo '</div>';
        }
        echo '</article>';
    }

    private function get_thread_message_meta_badges(array $meta): array {
        $badges = [];

        if (!empty($meta['processed_by'])) {
            $badges[] = sprintf(__('Processed by: %s', 'livecanvas-forge-ai'), $this->get_provenance_label('processed_by', (string) $meta['processed_by']));
        }

        if (!empty($meta['origin'])) {
            $badges[] = sprintf(__('Origin: %s', 'livecanvas-forge-ai'), $this->get_provenance_label('origin', (string) $meta['origin']));
        }

        if (!empty($meta['agent'])) {
            $badges[] = sprintf(__('Agent: %s', 'livecanvas-forge-ai'), $this->get_provenance_label('agent', (string) $meta['agent']));
        }

        if (!empty($meta['transport'])) {
            $badges[] = sprintf(__('Transport: %s', 'livecanvas-forge-ai'), $this->get_provenance_label('transport', (string) $meta['transport']));
        }

        if (!empty($meta['action'])) {
            $badges[] = sprintf(__('Action: %s', 'livecanvas-forge-ai'), sanitize_key((string) $meta['action']));
        }

        if (!empty($meta['execution_target'])) {
            $badges[] = sprintf(__('Execution: %s', 'livecanvas-forge-ai'), sanitize_key((string) $meta['execution_target']));
        }

        if (!empty($meta['mode'])) {
            $badges[] = sprintf(__('Mode: %s', 'livecanvas-forge-ai'), sanitize_key((string) $meta['mode']));
        }

        if (!empty($meta['genesis_task_id'])) {
            $badges[] = sprintf(__('Genesis task: %s', 'livecanvas-forge-ai'), sanitize_key((string) $meta['genesis_task_id']));
        }

        if (!empty($meta['confidence'])) {
            $badges[] = sprintf(__('Confidence: %s', 'livecanvas-forge-ai'), sanitize_text_field((string) $meta['confidence']));
        }

        if (!empty($meta['target_type'])) {
            $badges[] = sprintf(__('Target: %s', 'livecanvas-forge-ai'), sanitize_key((string) $meta['target_type']));
        }

        if (!empty($meta['target_title'])) {
            $badges[] = sprintf(__('Label: %s', 'livecanvas-forge-ai'), sanitize_text_field((string) $meta['target_title']));
        }

        if (!empty($meta['target_id'])) {
            $badges[] = sprintf(__('ID: %d', 'livecanvas-forge-ai'), absint($meta['target_id']));
        }

        if (!empty($meta['warnings']) && is_array($meta['warnings'])) {
            $badges[] = sprintf(__('Warnings: %d', 'livecanvas-forge-ai'), count($meta['warnings']));
        }

        if (!empty($meta['reasons']) && is_array($meta['reasons'])) {
            $badges[] = sprintf(__('Reasons: %d', 'livecanvas-forge-ai'), count($meta['reasons']));
        }

        return $badges;
    }

    private function get_provenance_label(string $type, string $value): string {
        $value = sanitize_key($value);
        $labels = [
            'processed_by' => [
                'forge_local_rules' => __('AI Bridge local rules', 'livecanvas-forge-ai'),
                'codex_mcp'         => __('Codex via MCP', 'livecanvas-forge-ai'),
                'opencode_mcp'      => __('OpenCode via MCP', 'livecanvas-forge-ai'),
                'claude_mcp'        => __('Claude via MCP', 'livecanvas-forge-ai'),
                'cursor_mcp'        => __('Cursor via MCP', 'livecanvas-forge-ai'),
                'generic_mcp'       => __('Generic MCP client', 'livecanvas-forge-ai'),
                'remote_companion'  => __('Remote companion', 'livecanvas-forge-ai'),
            ],
            'origin' => [
                'frontend_bridge'    => __('Frontend bridge', 'livecanvas-forge-ai'),
                'admin_command_deck' => __('Command Deck', 'livecanvas-forge-ai'),
                'mcp_agent'          => __('MCP agent', 'livecanvas-forge-ai'),
                'remote_companion'   => __('Remote companion', 'livecanvas-forge-ai'),
                'api'                => __('API', 'livecanvas-forge-ai'),
            ],
            'agent' => [
                'forge'    => __('AI Bridge', 'livecanvas-forge-ai'),
                'codex'    => __('Codex', 'livecanvas-forge-ai'),
                'opencode' => __('OpenCode', 'livecanvas-forge-ai'),
                'claude'   => __('Claude', 'livecanvas-forge-ai'),
                'cursor'   => __('Cursor', 'livecanvas-forge-ai'),
                'generic'  => __('Generic', 'livecanvas-forge-ai'),
            ],
            'transport' => [
                'browser_rest' => __('Browser REST', 'livecanvas-forge-ai'),
                'mcp_stdio'    => __('MCP stdio', 'livecanvas-forge-ai'),
                'mcp_bridge'   => __('MCP bridge', 'livecanvas-forge-ai'),
                'remote_rest'  => __('Remote REST', 'livecanvas-forge-ai'),
                'api'          => __('API', 'livecanvas-forge-ai'),
            ],
        ];

        return (string) ($labels[$type][$value] ?? $value);
    }

    private function render_command_thread_apply_form(array $action, string $thread_id): void {
        $payload = $this->prepare_command_thread_action_payload((array) ($action['payload'] ?? []));
        $request_context = $this->get_current_command_request_context();
        $context_post_id = absint($request_context['context_post_id'] ?? 0);
        $genesis_task_id = sanitize_key((string) ($request_context['genesis_task_id'] ?? ''));
        $user_prompt = sanitize_textarea_field((string) ($request_context['user_prompt'] ?? ''));

        if (empty($payload['action'])) {
            return;
        }

        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="lcfa-inline-form lcfa-inline-form--compact">';
        if (function_exists('wp_nonce_field')) {
            wp_nonce_field('lcfa_command');
        } else {
            echo '<input type="hidden" name="_wpnonce" value="">';
        }
        echo '<input type="hidden" name="action" value="lcfa_command">';
        echo '<input type="hidden" name="thread_id" value="' . esc_attr($thread_id) . '">';
        echo '<input type="hidden" name="command_payload_json" value="' . esc_attr(wp_json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) . '">';
        if ($context_post_id > 0) {
            echo '<input type="hidden" name="context_post_id" value="' . esc_attr((string) $context_post_id) . '">';
        }
        if ($genesis_task_id !== '') {
            echo '<input type="hidden" name="genesis_task_id" value="' . esc_attr($genesis_task_id) . '">';
        }
        if ($user_prompt !== '') {
            echo '<input type="hidden" name="user_prompt" value="' . esc_attr($user_prompt) . '">';
        }
        echo '<button class="button button-small" type="submit">' . esc_html((string) ($action['label'] ?? __('Apply', 'livecanvas-forge-ai'))) . '</button>';
        echo '</form>';
    }

    private function render_command_message_actions(array $actions, string $thread_id): void {
        if (!$actions) {
            return;
        }

        echo '<div class="lcfa-target-actions">';
        foreach ($actions as $action) {
            if (($action['kind'] ?? 'url') === 'apply' && !empty($action['payload'])) {
                $this->render_command_thread_apply_form((array) $action, $thread_id);
                continue;
            }

            echo '<a class="button button-small" href="' . esc_url((string) ($action['url'] ?? '')) . '" target="_blank" rel="noreferrer noopener">' . esc_html((string) ($action['label'] ?? '')) . '</a>';
        }
        echo '</div>';
    }

    private function build_thread_result_message(array $result, array $payload): array {
        $lines = [];
        $summary = trim((string) ($result['summary'] ?? ''));
        $message = trim((string) ($result['message'] ?? ''));
        $execution_target = sanitize_key((string) ($payload['execution_target'] ?? 'local'));
        $target_type = (string) ($result['target_type'] ?? '');
        $provenance = $this->get_payload_provenance(is_array($result['provenance'] ?? null) ? (array) $result['provenance'] : $payload, 'admin_command_deck', 'forge_local_rules');

        if ($summary !== '') {
            $lines[] = $summary;
        }

        if ($message !== '' && $message !== $summary) {
            $lines[] = $message;
        }

        if (!empty($result['target_title'])) {
            $lines[] = sprintf(__('Target label: %s', 'livecanvas-forge-ai'), (string) $result['target_title']);
        } elseif (!empty($result['target_type'])) {
            $lines[] = sprintf(__('Target type: %s', 'livecanvas-forge-ai'), (string) $result['target_type']);
        }

        if (!empty($result['data']['backup_file'])) {
            $lines[] = sprintf(__('Backup captured before write: %s', 'livecanvas-forge-ai'), (string) $result['data']['backup_file']);
        }

        if (!empty($result['data']['restored_from_backup']['backup_id'])) {
            $lines[] = sprintf(__('Restored from backup: %s', 'livecanvas-forge-ai'), (string) $result['data']['restored_from_backup']['backup_id']);
        }

        $message = [
            'role'    => 'tool_result',
            'label'   => !empty($result['ok']) ? __('Execution result', 'livecanvas-forge-ai') : __('Execution error', 'livecanvas-forge-ai'),
            'content' => implode("\n", array_filter($lines)),
            'meta'    => [
                'action'           => (string) ($result['action'] ?? ''),
                'mode'             => (string) ($result['mode'] ?? ''),
                'execution_target' => $execution_target,
                'genesis_task_id'  => sanitize_key((string) ($payload['genesis_task_id'] ?? '')),
                'ok'               => !empty($result['ok']),
                'target_type'      => $target_type,
                'target_id'        => (int) ($result['target_id'] ?? 0),
                'target_title'     => (string) ($result['target_title'] ?? ''),
            ] + $provenance,
            'actions' => LCFA_Thread_Message_Actions::build_result_actions($result, $payload, [
                'thread_id' => LCFA_Settings::normalize_thread_id((string) ($payload['thread_id'] ?? '')),
                'command_url_builder' => [$this, 'get_command_url'],
            ]),
        ];

        return LCFA_Thread_Message_Actions::decorate_message($message, [
            'thread_id' => LCFA_Settings::normalize_thread_id((string) ($payload['thread_id'] ?? '')),
            'command_url_builder' => [$this, 'get_command_url'],
        ]);
    }

    private function get_thread_message_actions(array $message): array {
        $decorated = LCFA_Thread_Message_Actions::decorate_message($message, [
            'thread_id' => LCFA_Settings::normalize_thread_id((string) ($_GET['thread_id'] ?? 'default')),
            'command_url_builder' => [$this, 'get_command_url'],
        ]);

        return LCFA_Thread_Message_Actions::sanitize_actions((array) ($decorated['actions'] ?? []));
    }

    private function prepare_command_thread_action_payload(array $payload): array {
        $prepared = $payload;

        if (empty($prepared['context_post_id']) && !empty($_GET['post_id'])) {
            $prepared['context_post_id'] = absint($_GET['post_id']);
        }

        if (empty($prepared['genesis_task_id']) && !empty($_GET['genesis_task_id'])) {
            $prepared['genesis_task_id'] = sanitize_key((string) $_GET['genesis_task_id']);
        }

        return $prepared;
    }

    private function get_current_command_request_context(): array {
        $context = [];
        $post_id = absint($_GET['post_id'] ?? 0);
        $genesis_task_id = sanitize_key((string) ($_GET['genesis_task_id'] ?? ''));
        $user_prompt = sanitize_textarea_field((string) ($_GET['user_prompt'] ?? ''));

        if ($post_id > 0) {
            $context['post_id'] = $post_id;
            $context['context_post_id'] = $post_id;
        }

        if ($genesis_task_id !== '') {
            $context['genesis_task_id'] = $genesis_task_id;
        }

        if ($user_prompt !== '') {
            $context['user_prompt'] = $user_prompt;
        }

        return $context;
    }

    private function render_command_result(?array $result): void {
        if (!$result) {
            return;
        }

        $is_success = !empty($result['ok']);
        $status_icon = $is_success ? 'check-circle' : 'x-circle';
        $status_label = __('Support details', 'livecanvas-forge-ai');

        echo '<section class="lcfa-card lcfa-command-result' . ($is_success ? ' is-success' : ' is-error') . '">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg($status_icon);
        echo '<div><h2>' . esc_html($status_label) . '</h2><p>' . esc_html($result['summary'] ?: $result['message']) . '</p></div>';
        echo '</div>';
        echo '<p class="lcfa-result-message">' . esc_html__('The thread above is the primary execution log. Use this panel for structured payloads, diffs, and supporting inspection details.', 'livecanvas-forge-ai') . '</p>';

        if (!empty($result['message']) && $result['message'] !== ($result['summary'] ?? '')) {
            echo '<p class="lcfa-result-message">' . esc_html($result['message']) . '</p>';
        }

        if (!empty($result['inventory']) && is_array($result['inventory'])) {
            echo '<details class="lcfa-command-details" data-lcfa-command-details="inventory">';
            echo '<summary>' . esc_html__('Audit inventory', 'livecanvas-forge-ai') . '</summary>';
            echo '<div class="lcfa-command-details__body">';
            echo '<div class="lcfa-guide">';
            echo '<h3>' . esc_html__('Audit inventory', 'livecanvas-forge-ai') . '</h3>';
            $this->render_inventory_panel($result['inventory']);
            echo '</div>';
            echo '</div>';
            echo '</details>';
        }

        if (!empty($result['data']) && is_array($result['data'])) {
            echo '<details class="lcfa-command-details" data-lcfa-command-details="payload">';
            echo '<summary>' . esc_html__('Structured payload', 'livecanvas-forge-ai') . '</summary>';
            echo '<div class="lcfa-command-details__body">';
            echo '<div class="lcfa-result-panel">';
            echo '<h3>' . esc_html__('Structured payload', 'livecanvas-forge-ai') . '</h3>';
            $this->render_code_block(wp_json_encode($result['data'], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), [
                'language'   => 'json',
                'label'      => __('JSON', 'livecanvas-forge-ai'),
                'copy_label' => __('Copy payload', 'livecanvas-forge-ai'),
            ]);
            echo '</div>';
            echo '</div>';
            echo '</details>';
        }

        if (!empty($result['diff_html']) || $result['existing_html'] !== '' || $result['proposed_html'] !== '') {
            echo '<details class="lcfa-command-details" data-lcfa-command-details="preview">';
            echo '<summary>' . esc_html__('Markup preview', 'livecanvas-forge-ai') . '</summary>';
            echo '<div class="lcfa-command-details__body">';
            echo '<div class="lcfa-result-grid">';

            if (!empty($result['diff_html'])) {
                echo '<div class="lcfa-result-panel lcfa-diff-panel">';
                echo '<h3>' . esc_html__('Diff preview', 'livecanvas-forge-ai') . '</h3>';
                echo '<div class="lcfa-diff">' . $result['diff_html'] . '</div>';
                echo '</div>';
            }

            if ($result['existing_html'] !== '') {
                echo '<div class="lcfa-result-panel">';
                echo '<h3>' . esc_html__('Current content', 'livecanvas-forge-ai') . '</h3>';
                $this->render_code_block($result['existing_html'], [
                    'language'   => 'markup',
                    'label'      => __('HTML', 'livecanvas-forge-ai'),
                    'copy_label' => __('Copy current HTML', 'livecanvas-forge-ai'),
                ]);
                echo '</div>';
            }

            if ($result['proposed_html'] !== '') {
                echo '<div class="lcfa-result-panel">';
                echo '<h3>' . esc_html__('Proposed content', 'livecanvas-forge-ai') . '</h3>';
                $this->render_code_block($result['proposed_html'], [
                    'language'   => 'markup',
                    'label'      => __('HTML', 'livecanvas-forge-ai'),
                    'copy_label' => __('Copy proposed HTML', 'livecanvas-forge-ai'),
                ]);
                echo '</div>';
            }

            echo '</div>';
            echo '</div>';
            echo '</details>';
        }

        echo '</section>';
    }

    private function render_command_suggestion(?array $suggestion): void {
        if (!$suggestion) {
            return;
        }

        $is_success = !empty($suggestion['ok']);
        $status_icon = $is_success ? 'stars' : 'x-circle';
        $status_label = __('Support details', 'livecanvas-forge-ai');
        $payload = is_array($suggestion['suggested_payload'] ?? null) ? $suggestion['suggested_payload'] : [];
        $preflight = is_array($suggestion['preflight'] ?? null) ? $suggestion['preflight'] : [];
        $workflow = is_array($suggestion['workflow'] ?? null) ? $suggestion['workflow'] : [];
        $reasons = is_array($suggestion['reasons'] ?? null) ? $suggestion['reasons'] : [];
        $warnings = is_array($suggestion['warnings'] ?? null) ? $suggestion['warnings'] : [];

        echo '<section class="lcfa-card lcfa-command-result' . ($is_success ? ' is-success' : ' is-error') . '">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg($status_icon);
        echo '<div><h2>' . esc_html($status_label) . '</h2><p>' . esc_html((string) ($suggestion['summary'] ?? $suggestion['message'] ?? '')) . '</p></div>';
        echo '</div>';
        echo '<p class="lcfa-result-message">' . esc_html__('The thread above is the primary suggestion log. Use this panel for reasoning, warnings, workflow, and payload inspection.', 'livecanvas-forge-ai') . '</p>';

        if (!empty($payload['action'])) {
            $thread_id = LCFA_Settings::normalize_thread_id((string) ($_GET['thread_id'] ?? 'default'));
            $suggestion_actions = LCFA_Thread_Message_Actions::build_suggestion_actions($payload, $this->get_current_command_request_context(), [
                'thread_id'           => $thread_id,
                'command_url_builder' => [$this, 'get_command_url'],
            ]);

            $this->render_command_message_actions($suggestion_actions, $thread_id);
        }

        if ($reasons) {
            echo '<details class="lcfa-command-details" data-lcfa-command-details="reasons">';
            echo '<summary>' . esc_html__('Why this was suggested', 'livecanvas-forge-ai') . '</summary>';
            echo '<div class="lcfa-command-details__body">';
            echo '<div class="lcfa-guide">';
            echo '<h3>' . esc_html__('Why this was suggested', 'livecanvas-forge-ai') . '</h3>';
            echo '<ul class="lcfa-bullets">';
            foreach ($reasons as $reason) {
                echo '<li>' . esc_html((string) $reason) . '</li>';
            }
            echo '</ul>';
            echo '</div>';
            echo '</div>';
            echo '</details>';
        }

        if ($warnings) {
            echo '<details class="lcfa-command-details" data-lcfa-command-details="warnings">';
            echo '<summary>' . esc_html__('Warnings', 'livecanvas-forge-ai') . '</summary>';
            echo '<div class="lcfa-command-details__body">';
            echo '<div class="lcfa-guide">';
            echo '<h3>' . esc_html__('Warnings', 'livecanvas-forge-ai') . '</h3>';
            echo '<ul class="lcfa-bullets">';
            foreach ($warnings as $warning) {
                echo '<li>' . esc_html((string) $warning) . '</li>';
            }
            echo '</ul>';
            echo '</div>';
            echo '</div>';
            echo '</details>';
        }

        if ($workflow) {
            echo '<details class="lcfa-command-details" data-lcfa-command-details="workflow">';
            echo '<summary>' . esc_html__('Recommended workflow', 'livecanvas-forge-ai') . '</summary>';
            echo '<div class="lcfa-command-details__body">';
            echo '<div class="lcfa-guide">';
            echo '<h3>' . esc_html__('Recommended workflow', 'livecanvas-forge-ai') . '</h3>';
            echo '<ol class="lcfa-bullets">';
            foreach ($workflow as $step) {
                $action = (string) ($step['action'] ?? '');
                $phase = (string) ($step['phase'] ?? '');
                $execution_target = (string) ($step['execution_target'] ?? '');
                $parts = array_values(array_filter([
                    $phase !== '' ? ucfirst($phase) : '',
                    $action !== '' ? $action : '',
                    $execution_target !== '' ? sprintf(__('execution %s', 'livecanvas-forge-ai'), $execution_target) : '',
                ]));
                echo '<li>' . esc_html(implode(' · ', $parts)) . '</li>';
            }
            echo '</ol>';
            echo '</div>';
            echo '</div>';
            echo '</details>';
        }

        if ($preflight) {
            echo '<details class="lcfa-command-details" data-lcfa-command-details="preflight">';
            echo '<summary>' . esc_html__('Recommended preflight payload', 'livecanvas-forge-ai') . '</summary>';
            echo '<div class="lcfa-command-details__body">';
            echo '<div class="lcfa-result-panel">';
            echo '<h3>' . esc_html__('Recommended preflight payload', 'livecanvas-forge-ai') . '</h3>';
            $this->render_code_block(wp_json_encode($preflight, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), [
                'language'   => 'json',
                'label'      => __('JSON', 'livecanvas-forge-ai'),
                'copy_label' => __('Copy preflight', 'livecanvas-forge-ai'),
            ]);
            echo '</div>';
            echo '</div>';
            echo '</details>';
        }

        if ($payload) {
            echo '<div class="lcfa-result-panel">';
            echo '<h3>' . esc_html__('Suggested payload', 'livecanvas-forge-ai') . '</h3>';
            $this->render_code_block(wp_json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), [
                'language'   => 'json',
                'label'      => __('JSON', 'livecanvas-forge-ai'),
                'copy_label' => __('Copy payload', 'livecanvas-forge-ai'),
            ]);
            echo '</div>';
        }

        echo '</section>';
    }

    private function render_connection_test_result(?array $result): void {
        if (!$result) {
            return;
        }

        $is_success = !empty($result['ok']);
        $status_icon = $is_success ? 'check-circle' : 'x-circle';
        $status_label = $is_success ? __('Connection checks', 'livecanvas-forge-ai') : __('Connection issues', 'livecanvas-forge-ai');
        $checks = is_array($result['checks'] ?? null) ? $result['checks'] : [];

        echo '<section class="lcfa-card lcfa-command-result' . ($is_success ? ' is-success' : ' is-error') . '">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg($status_icon);
        echo '<div><h2>' . esc_html($status_label) . '</h2><p>' . esc_html((string) ($result['summary'] ?? '')) . '</p></div>';
        echo '</div>';

        if (!empty($result['checked_at'])) {
            echo '<p class="lcfa-result-message">' . esc_html(sprintf(
                __('Checked at %s.', 'livecanvas-forge-ai'),
                get_date_from_gmt((string) $result['checked_at'], get_option('date_format') . ' ' . get_option('time_format'))
            )) . '</p>';
        }

        if (!$checks) {
            echo '</section>';
            return;
        }

        echo '<div class="lcfa-history-list">';
        foreach ($checks as $check) {
            if (!is_array($check)) {
                continue;
            }

            $chip_class = !empty($check['ok']) ? ' is-positive' : (!empty($check['skipped']) ? '' : ' is-negative');
            $chip_label = !empty($check['ok'])
                ? __('OK', 'livecanvas-forge-ai')
                : (!empty($check['skipped']) ? __('Skipped', 'livecanvas-forge-ai') : __('Error', 'livecanvas-forge-ai'));

            echo '<div class="lcfa-history-item">';
            echo '<div class="lcfa-history-copy">';
            echo '<strong>' . esc_html((string) ($check['label'] ?? __('Connection test', 'livecanvas-forge-ai'))) . '</strong>';
            echo '<span>' . esc_html((string) ($check['message'] ?? '')) . '</span>';
            echo '</div>';
            echo '<div class="lcfa-chip-row">';
            echo '<span class="lcfa-chip' . esc_attr($chip_class) . '">' . esc_html($chip_label) . '</span>';
            if (!empty($check['details']['status_code'])) {
                echo '<span class="lcfa-chip">' . esc_html(sprintf(__('HTTP %d', 'livecanvas-forge-ai'), (int) $check['details']['status_code'])) . '</span>';
            }
            if (!empty($check['details']['node_version'])) {
                echo '<span class="lcfa-chip">' . esc_html((string) $check['details']['node_version']) . '</span>';
            }
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';

        echo '<div class="lcfa-result-panel">';
        echo '<h3>' . esc_html__('Structured payload', 'livecanvas-forge-ai') . '</h3>';
        $this->render_code_block(wp_json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), [
            'language'   => 'json',
            'label'      => __('JSON', 'livecanvas-forge-ai'),
            'copy_label' => __('Copy payload', 'livecanvas-forge-ai'),
        ]);
        echo '</div>';
        echo '</section>';
    }

    private function render_code_block(string $code, array $options = []): void {
        $language = sanitize_html_class((string) ($options['language'] ?? 'bash'));
        if ($language === '') {
            $language = 'bash';
        }

        $label = (string) ($options['label'] ?? $this->get_code_block_label($language));
        $copy_text = (string) ($options['copy_text'] ?? $code);
        $copy_label = (string) ($options['copy_label'] ?? __('Copy', 'livecanvas-forge-ai'));
        $copied_label = (string) ($options['copied_label'] ?? __('Copied', 'livecanvas-forge-ai'));

        echo '<div class="lcfa-code-block" data-lcfa-code-language="' . esc_attr($language) . '">';
        echo '<div class="lcfa-code-block__head">';
        echo '<span class="lcfa-code-block__label">' . esc_html($label) . '</span>';
        if ($copy_text !== '') {
            echo '<button class="lcfa-code-block__copy" type="button" data-lcfa-copy-text="' . esc_attr($copy_text) . '" data-lcfa-copy-label="' . esc_attr($copy_label) . '" data-lcfa-copied-label="' . esc_attr($copied_label) . '">' . esc_html($copy_label) . '</button>';
        }
        echo '</div>';
        echo '<pre class="language-' . esc_attr($language) . '"><code class="language-' . esc_attr($language) . '">' . esc_html($code) . '</code></pre>';
        echo '</div>';
    }

    private function get_code_block_label(string $language): string {
        switch ($language) {
            case 'json':
                return __('JSON', 'livecanvas-forge-ai');
            case 'markup':
                return __('HTML', 'livecanvas-forge-ai');
            case 'bash':
            default:
                return __('Shell', 'livecanvas-forge-ai');
        }
    }

    private function render_inventory_panel(array $inventory): void {
        $summary = $inventory['summary'] ?? [];
        $summary_items = [
            'pages'             => __('Pages', 'livecanvas-forge-ai'),
            'headers'           => __('Headers', 'livecanvas-forge-ai'),
            'footers'           => __('Footers', 'livecanvas-forge-ai'),
            'dynamic_templates' => __('Dynamic templates', 'livecanvas-forge-ai'),
            'blocks'            => __('Blocks', 'livecanvas-forge-ai'),
            'sections'          => __('Sections', 'livecanvas-forge-ai'),
        ];

        echo '<div class="lcfa-summary-grid">';
        foreach ($summary_items as $key => $label) {
            echo '<div class="lcfa-summary-tile">';
            echo '<span>' . esc_html($label) . '</span>';
            echo '<strong>' . esc_html((string) ($summary[$key] ?? 0)) . '</strong>';
            echo '</div>';
        }
        echo '</div>';

        $groups = [
            'livecanvas_pages'  => __('LiveCanvas pages', 'livecanvas-forge-ai'),
            'header_partials'   => __('Header partials', 'livecanvas-forge-ai'),
            'footer_partials'   => __('Footer partials', 'livecanvas-forge-ai'),
            'other_partials'    => __('Other partials', 'livecanvas-forge-ai'),
            'dynamic_templates' => __('Dynamic templates', 'livecanvas-forge-ai'),
            'blocks'            => __('Blocks', 'livecanvas-forge-ai'),
            'sections'          => __('Sections', 'livecanvas-forge-ai'),
        ];

        echo '<div class="lcfa-inventory-groups">';
        foreach ($groups as $key => $label) {
            $items = isset($inventory[$key]) && is_array($inventory[$key]) ? $inventory[$key] : [];
            $this->render_inventory_group($key, $label, $items);
        }
        echo '</div>';

        $custom_post_types = isset($inventory['custom_post_types']) && is_array($inventory['custom_post_types']) ? $inventory['custom_post_types'] : [];

        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('Custom post types', 'livecanvas-forge-ai') . '</h3>';
        if (!$custom_post_types) {
            echo '<p class="lcfa-empty">' . esc_html__('No custom post types detected beyond WordPress core and LiveCanvas internals.', 'livecanvas-forge-ai') . '</p>';
        } else {
            echo '<div class="lcfa-chip-row">';
            foreach ($custom_post_types as $post_type) {
                $label = $post_type['label'] ?: $post_type['name'];
                $flags = [];
                if (!empty($post_type['has_archive'])) {
                    $flags[] = __('archive', 'livecanvas-forge-ai');
                }
                if (!empty($post_type['show_in_rest'])) {
                    $flags[] = __('rest', 'livecanvas-forge-ai');
                }

                echo '<span class="lcfa-chip">';
                echo esc_html($label . ' (' . $post_type['name'] . ')');
                if ($flags) {
                    echo ' · ' . esc_html(implode(', ', $flags));
                }
                echo '</span>';
            }
            echo '</div>';
        }
        echo '</div>';
    }

    private function render_theme_files_panel(?array $roots, ?array $templates): void {
        if (!empty($roots['error'])) {
            echo '<p class="lcfa-empty">' . esc_html((string) $roots['error']) . '</p>';
            return;
        }

        if (!is_array($roots) || empty($roots['roots'])) {
            echo '<p class="lcfa-empty">' . esc_html__('Theme roots are not available for this site.', 'livecanvas-forge-ai') . '</p>';
            return;
        }

        echo '<div class="lcfa-chip-row">';
        foreach ((array) $roots['roots'] as $root) {
            if (!is_array($root)) {
                continue;
            }

            echo '<span class="lcfa-chip">';
            echo esc_html(sprintf('%1$s: %2$s', strtoupper((string) ($root['key'] ?? 'theme')), (string) ($root['label'] ?? '')));
            echo '</span>';
        }
        echo '</div>';

        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('Writable fallback layer', 'livecanvas-forge-ai') . '</h3>';
        echo '<p>' . esc_html__('Use these files when LiveCanvas dynamic tags or shortcodes are not enough and the companion needs a real Twig, Latte, PHP, CSS, or JS fallback.', 'livecanvas-forge-ai') . '</p>';
        echo '</div>';

        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('Quick actions', 'livecanvas-forge-ai') . '</h3>';
        echo '<div class="lcfa-cta-row">';
        echo '<a class="button button-primary" href="' . esc_url($this->get_command_url(['suggest_action' => 'theme_files_audit'])) . '">' . esc_html__('Inspect files', 'livecanvas-forge-ai') . '</a>';
        echo '<a class="button" href="' . esc_url($this->get_command_url(['suggest_action' => 'theme_backups_audit'])) . '">' . esc_html__('Inspect backups', 'livecanvas-forge-ai') . '</a>';
        echo '</div>';
        echo '</div>';

        $items = is_array($templates['files'] ?? null) ? $templates['files'] : [];
        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('Templates', 'livecanvas-forge-ai') . '</h3>';
        if (!$items) {
            echo '<p class="lcfa-empty">' . esc_html__('No template files were detected in the common theme template directories.', 'livecanvas-forge-ai') . '</p>';
        } else {
            echo '<ul class="lcfa-target-list">';
            foreach ($items as $item) {
                if (!is_array($item)) {
                    continue;
                }

                $forge_url = $this->get_command_url([
                    'suggest_action' => 'write_theme_template',
                    'file_path'      => (string) ($item['relative_path'] ?? ''),
                    'root_scope'     => (string) ($item['root'] ?? 'active'),
                ]);

                echo '<li class="lcfa-target-item">';
                echo '<div class="lcfa-target-copy">';
                echo '<strong>' . esc_html((string) ($item['relative_path'] ?? '')) . '</strong>';
                echo '<span>' . esc_html(sprintf('%1$s · %2$s', (string) ($item['theme'] ?? ''), (string) ($item['kind'] ?? 'template'))) . '</span>';
                echo '</div>';
                echo '<div class="lcfa-target-actions">';
                echo '<a class="button button-small button-primary" href="' . esc_url($forge_url) . '">' . esc_html__('AI Bridge', 'livecanvas-forge-ai') . '</a>';
                echo '</div>';
                echo '</li>';
            }
            echo '</ul>';
        }
        echo '</div>';

        try {
            $backups = $this->theme_files_bridge->list_backups([
                'limit' => 6,
            ]);
        } catch (Throwable $throwable) {
            $backups = [
                'error' => $throwable->getMessage(),
            ];
        }

        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('Recent backups', 'livecanvas-forge-ai') . '</h3>';
        echo '<p>' . esc_html__('Every overwrite in the fallback layer creates a backup. Use restore to rehydrate a previous version with the same preview/apply flow as any other command.', 'livecanvas-forge-ai') . '</p>';

        if (!empty($backups['error'])) {
            echo '<p class="lcfa-empty">' . esc_html((string) $backups['error']) . '</p>';
            echo '</div>';

            return;
        }

        $backup_items = is_array($backups['backups'] ?? null) ? $backups['backups'] : [];

        if (!$backup_items) {
            echo '<p class="lcfa-empty">' . esc_html__('No backups have been captured yet.', 'livecanvas-forge-ai') . '</p>';
            echo '</div>';

            return;
        }

        echo '<ul class="lcfa-target-list">';
        foreach ($backup_items as $backup_item) {
            if (!is_array($backup_item)) {
                continue;
            }

            $created_at = !empty($backup_item['created_at'])
                ? get_date_from_gmt((string) $backup_item['created_at'], get_option('date_format') . ' ' . get_option('time_format'))
                : '';
            $restore_url = $this->get_command_url([
                'suggest_action' => 'restore_theme_backup',
                'backup_id'      => (string) ($backup_item['backup_id'] ?? ''),
                'file_path'      => (string) ($backup_item['relative_path'] ?? ''),
                'root_scope'     => (string) ($backup_item['root'] ?? 'stylesheet'),
            ]);

            echo '<li class="lcfa-target-item">';
            echo '<div class="lcfa-target-copy">';
            echo '<strong>' . esc_html((string) ($backup_item['relative_path'] ?? (string) ($backup_item['backup_id'] ?? ''))) . '</strong>';
            echo '<span>' . esc_html(implode(' · ', array_filter([
                (string) ($backup_item['theme'] ?? ''),
                (string) ($backup_item['root'] ?? ''),
                $created_at,
            ]))) . '</span>';
            echo '</div>';
            echo '<div class="lcfa-target-actions">';
            echo '<a class="button button-small" href="' . esc_url($restore_url) . '">' . esc_html__('Restore', 'livecanvas-forge-ai') . '</a>';
            echo '</div>';
            echo '</li>';
        }
        echo '</ul>';
        echo '</div>';
    }

    private function render_windpress_panel(array $windpress, array $local_bridge): void {
        $providers       = is_array($windpress['providers'] ?? null) ? $windpress['providers'] : [];
        $handlers        = is_array($windpress['volume_handlers'] ?? null) ? $windpress['volume_handlers'] : [];
        $css_cache       = is_array($windpress['cache']['css'] ?? null) ? $windpress['cache']['css'] : [];
        $theme_json_cache= is_array($windpress['cache']['theme_json'] ?? null) ? $windpress['cache']['theme_json'] : [];
        $default_ids     = $this->get_default_windpress_provider_ids($providers);
        $reset_entries   = ['main.css', 'tailwind.config.js', 'wizard.css', 'wizard.js'];

        if (empty($windpress['available'])) {
            echo '<p class="lcfa-empty">' . esc_html__('WindPress is not active on this site. This panel becomes operational when Picowind + WindPress are running.', 'livecanvas-forge-ai') . '</p>';

            if (!empty($local_bridge['message'])) {
                echo '<div class="lcfa-guide">';
                echo '<h3>' . esc_html__('Local bridge status', 'livecanvas-forge-ai') . '</h3>';
                echo '<p>' . esc_html((string) $local_bridge['message']) . '</p>';
                echo '</div>';
            }

            return;
        }

        echo '<div class="lcfa-summary-grid">';
        $this->render_summary_tile(__('Providers', 'livecanvas-forge-ai'), (string) count($providers));
        $this->render_summary_tile(__('Handlers', 'livecanvas-forge-ai'), (string) count($handlers));
        $this->render_summary_tile(__('CSS cache', 'livecanvas-forge-ai'), $this->format_file_size_label((int) ($css_cache['bytes'] ?? 0)));
        $this->render_summary_tile(__('theme.json', 'livecanvas-forge-ai'), $this->format_file_size_label((int) ($theme_json_cache['bytes'] ?? 0)));
        echo '</div>';

        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('Quick actions', 'livecanvas-forge-ai') . '</h3>';
        echo '<div class="lcfa-cta-row">';
        echo '<a class="button button-primary" href="' . esc_url($this->get_command_url(['suggest_action' => 'windpress_audit'])) . '">' . esc_html__('Run audit', 'livecanvas-forge-ai') . '</a>';

        if (!empty($local_bridge['build_available'])) {
            echo '<a class="button" href="' . esc_url($this->get_command_url([
                'suggest_action' => 'build_windpress_cache',
                'provider_id'    => $default_ids,
            ])) . '">' . esc_html__('Build local cache', 'livecanvas-forge-ai') . '</a>';
        }

        echo '<a class="button" href="' . esc_url($this->get_command_url(['suggest_action' => 'windpress_flush_cache'])) . '">' . esc_html__('Flush cache', 'livecanvas-forge-ai') . '</a>';
        echo '</div>';

        echo '<div class="lcfa-chip-row">';
        echo '<span class="lcfa-chip' . (!empty($windpress['active']) ? ' is-positive' : '') . '">' . esc_html(!empty($windpress['active']) ? __('Active', 'livecanvas-forge-ai') : __('Inactive', 'livecanvas-forge-ai')) . '</span>';
        if (!empty($windpress['tailwind_version'])) {
            echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Tailwind v%d', 'livecanvas-forge-ai'), (int) $windpress['tailwind_version'])) . '</span>';
        }
        if (!empty($windpress['performance_mode'])) {
            echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Mode: %s', 'livecanvas-forge-ai'), (string) $windpress['performance_mode'])) . '</span>';
        }
        if (!empty($local_bridge['node_version'])) {
            echo '<span class="lcfa-chip">' . esc_html(sprintf(__('Node: %s', 'livecanvas-forge-ai'), (string) $local_bridge['node_version'])) . '</span>';
        }
        echo '</div>';
        echo '</div>';

        if (!empty($local_bridge['message'])) {
            echo '<div class="lcfa-guide">';
            echo '<h3>' . esc_html__('Local build runtime', 'livecanvas-forge-ai') . '</h3>';
            echo '<p>' . esc_html((string) $local_bridge['message']) . '</p>';
            echo '</div>';
        }

        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('Providers', 'livecanvas-forge-ai') . '</h3>';
        if (!$providers) {
            echo '<p class="lcfa-empty">' . esc_html__('No WindPress providers were returned by the runtime.', 'livecanvas-forge-ai') . '</p>';
        } else {
            echo '<ul class="lcfa-target-list">';
            foreach ($providers as $provider) {
                if (!is_array($provider)) {
                    continue;
                }

                $provider_id = (string) ($provider['id'] ?? '');
                $meta = array_filter([
                    (string) ($provider['type'] ?? ''),
                    !empty($provider['enabled']) ? __('enabled', 'livecanvas-forge-ai') : __('disabled', 'livecanvas-forge-ai'),
                    array_key_exists('installed', $provider) && $provider['installed'] !== null
                        ? (!empty($provider['installed']) ? __('installed', 'livecanvas-forge-ai') : __('missing', 'livecanvas-forge-ai'))
                        : '',
                ]);

                echo '<li class="lcfa-target-item">';
                echo '<div class="lcfa-target-copy">';
                echo '<strong>' . esc_html((string) ($provider['name'] ?? $provider_id)) . '</strong>';
                echo '<span>' . esc_html(implode(' · ', $meta)) . '</span>';
                echo '</div>';
                echo '<div class="lcfa-target-actions">';
                echo '<a class="button button-small" href="' . esc_url($this->get_command_url([
                    'suggest_action' => 'windpress_scan_provider',
                    'provider_id'    => $provider_id,
                ])) . '">' . esc_html__('Scan', 'livecanvas-forge-ai') . '</a>';

                if (!empty($local_bridge['build_available'])) {
                    echo '<a class="button button-small button-primary" href="' . esc_url($this->get_command_url([
                        'suggest_action' => 'build_windpress_cache',
                        'provider_id'    => $provider_id,
                    ])) . '">' . esc_html__('Build', 'livecanvas-forge-ai') . '</a>';
                }
                echo '</div>';
                echo '</li>';
            }
            echo '</ul>';
        }
        echo '</div>';

        echo '<div class="lcfa-guide">';
        echo '<h3>' . esc_html__('Internal entries', 'livecanvas-forge-ai') . '</h3>';
        echo '<ul class="lcfa-target-list">';
        foreach ($reset_entries as $entry) {
            echo '<li class="lcfa-target-item">';
            echo '<div class="lcfa-target-copy">';
            echo '<strong>' . esc_html($entry) . '</strong>';
            echo '<span>' . esc_html__('Reset one internal WindPress cache entry.', 'livecanvas-forge-ai') . '</span>';
            echo '</div>';
            echo '<div class="lcfa-target-actions">';
            echo '<a class="button button-small" href="' . esc_url($this->get_command_url([
                'suggest_action' => 'windpress_reset_entry',
                'relative_path'  => $entry,
            ])) . '">' . esc_html__('Reset', 'livecanvas-forge-ai') . '</a>';
            echo '</div>';
            echo '</li>';
        }
        echo '</ul>';
        echo '</div>';
    }

    private function render_inventory_group(string $group_key, string $label, array $items): void {
        echo '<div class="lcfa-inventory-group">';
        echo '<h3>' . esc_html($label) . '</h3>';

        if (!$items) {
            echo '<p class="lcfa-empty">' . esc_html__('Nothing detected yet for this target type.', 'livecanvas-forge-ai') . '</p>';
            echo '</div>';

            return;
        }

        $visible_items = array_slice($items, 0, 12);

        echo '<ul class="lcfa-target-list">';
        foreach ($visible_items as $item) {
            $meta_parts = [
                '#' . (int) $item['id'],
                $item['status'],
            ];

            if (!empty($item['slug'])) {
                $meta_parts[] = $item['slug'];
            }

            echo '<li class="lcfa-target-item">';
            echo '<div class="lcfa-target-copy">';
            echo '<strong>' . esc_html($item['title']) . '</strong>';
            echo '<span>' . esc_html(implode(' · ', array_filter($meta_parts))) . '</span>';
            echo '</div>';
            echo '<div class="lcfa-target-actions">';
            $forge_url = $this->get_inventory_item_command_url($group_key, $item);
            if ($forge_url) {
                echo '<a class="button button-small button-primary" href="' . esc_url($forge_url) . '">' . esc_html__('AI Bridge', 'livecanvas-forge-ai') . '</a>';
            }
            if (!empty($item['edit_url'])) {
                echo '<a class="button button-small" href="' . esc_url($item['edit_url']) . '">' . esc_html__('Edit', 'livecanvas-forge-ai') . '</a>';
            }
            if (!empty($item['view_url'])) {
                echo '<a class="button button-small" href="' . esc_url($item['view_url']) . '" target="_blank" rel="noreferrer noopener">' . esc_html__('View', 'livecanvas-forge-ai') . '</a>';
            }
            echo '</div>';
            echo '</li>';
        }
        echo '</ul>';

        if (count($items) > count($visible_items)) {
            echo '<p class="lcfa-empty">' . esc_html(sprintf(__('Showing %1$d of %2$d entries.', 'livecanvas-forge-ai'), count($visible_items), count($items))) . '</p>';
        }

        echo '</div>';
    }

    private function render_summary_tile(string $label, string $value): void {
        echo '<div class="lcfa-summary-tile">';
        echo '<span>' . esc_html($label) . '</span>';
        echo '<strong>' . esc_html($value) . '</strong>';
        echo '</div>';
    }

    private function render_history_panel(array $history): void {
        echo '<section class="lcfa-card">';
        echo '<div class="lcfa-card-head">';
        echo $this->get_icon_svg('activity');
        echo '<div><h2>' . esc_html__('Recent runs', 'livecanvas-forge-ai') . '</h2><p>' . esc_html__('The last preview or apply operations executed through the companion.', 'livecanvas-forge-ai') . '</p></div>';
        echo '</div>';

        if (!$history) {
            echo '<p class="lcfa-empty">' . esc_html__('No command history yet.', 'livecanvas-forge-ai') . '</p>';
            echo '</section>';

            return;
        }

        echo '<div class="lcfa-history-list">';
        foreach (array_slice($history, 0, 10) as $entry) {
            $time = !empty($entry['time'])
                ? get_date_from_gmt($entry['time'], get_option('date_format') . ' ' . get_option('time_format'))
                : '';

            echo '<div class="lcfa-history-item">';
            echo '<div class="lcfa-history-copy">';
            echo '<strong>' . esc_html($entry['summary'] ?: ($entry['message'] ?? __('Unnamed operation', 'livecanvas-forge-ai'))) . '</strong>';
            if ($time !== '') {
                echo '<span>' . esc_html($time) . '</span>';
            }
            echo '</div>';
            echo '<div class="lcfa-chip-row">';
            if (!empty($entry['action'])) {
                echo '<span class="lcfa-chip">' . esc_html($entry['action']) . '</span>';
            }
            if (!empty($entry['mode'])) {
                echo '<span class="lcfa-chip">' . esc_html($entry['mode']) . '</span>';
            }
            if (!empty($entry['execution_target'])) {
                echo '<span class="lcfa-chip">' . esc_html((string) $entry['execution_target']) . '</span>';
            }
            echo '<span class="lcfa-chip' . (!empty($entry['ok']) ? ' is-positive' : ' is-negative') . '">' . esc_html(!empty($entry['ok']) ? __('OK', 'livecanvas-forge-ai') : __('Error', 'livecanvas-forge-ai')) . '</span>';
            if (!empty($entry['target_id'])) {
                echo '<span class="lcfa-chip">' . esc_html(sprintf(__('#%d', 'livecanvas-forge-ai'), (int) $entry['target_id'])) . '</span>';
            }
            if (!empty($entry['audit_id'])) {
                echo '<span class="lcfa-chip">' . esc_html((string) $entry['audit_id']) . '</span>';
            }
            if (!empty($entry['rollback_available'])) {
                echo '<span class="lcfa-chip is-positive">' . esc_html__('Rollback ready', 'livecanvas-forge-ai') . '</span>';
                if (($entry['execution_target'] ?? 'local') === 'local' && !empty($entry['audit_id'])) {
                    echo '<a class="button button-small" href="' . esc_url($this->get_command_url([
                        'suggest_action' => 'restore_audit_rollback',
                        'audit_id'       => (string) $entry['audit_id'],
                    ])) . '">' . esc_html__('Restore', 'livecanvas-forge-ai') . '</a>';
                }
            }
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';
        echo '</section>';
    }

    private function get_tool_guides(string $site_mode): array {
        $remote_suffix = $site_mode === 'remote' || $site_mode === 'hybrid'
            ? __('Use a dedicated WordPress user with an Application Password and the minimum viable permissions.', 'livecanvas-forge-ai')
            : __('Use the local companion bridge first, then add MCP only where it provides a real benefit.', 'livecanvas-forge-ai');

        return [
            'codex' => [
                'summary' => __('Codex is the first-class client for the initial integration. The plugin will expose a local or REST bridge first, with MCP kept optional.', 'livecanvas-forge-ai'),
                'steps'   => [
                    __('Open the WordPress workspace in Codex.', 'livecanvas-forge-ai'),
                    __('Point the client to the companion bridge or to the REST surface when it becomes available.', 'livecanvas-forge-ai'),
                    $remote_suffix,
                ],
            ],
            'opencode' => [
                'summary' => __('OpenCode should use the same operational contract as the companion: context, plan, diff, preview, and controlled apply.', 'livecanvas-forge-ai'),
                'steps'   => [
                    __('Configure the target endpoint and credentials for the selected WordPress instance.', 'livecanvas-forge-ai'),
                    __('Keep preview and confirmation enabled for sensitive writes.', 'livecanvas-forge-ai'),
                    $remote_suffix,
                ],
            ],
            'claude' => [
                'summary' => __('Claude can talk through the same MCP or REST bridge and should follow the same permission matrix.', 'livecanvas-forge-ai'),
                'steps'   => [
                    __('Configure the companion MCP server when available.', 'livecanvas-forge-ai'),
                    __('If MCP is not in place yet, use REST plus Application Passwords.', 'livecanvas-forge-ai'),
                    $remote_suffix,
                ],
            ],
            'cursor' => [
                'summary' => __('Cursor should be treated as an advanced client. The guide should stay explicit about endpoints, auth, diff flow, and confirmation checkpoints.', 'livecanvas-forge-ai'),
                'steps'   => [
                    __('Open the site workspace and connect Cursor to the companion contract.', 'livecanvas-forge-ai'),
                    __('Keep diff-first execution enabled before any apply action.', 'livecanvas-forge-ai'),
                    $remote_suffix,
                ],
            ],
            'other' => [
                'summary' => __('Any client that supports MCP or REST can be attached, as long as it respects the companion contract and permission model.', 'livecanvas-forge-ai'),
                'steps'   => [
                    __('Choose the transport first: MCP or REST.', 'livecanvas-forge-ai'),
                    __('Then configure the endpoint, credentials, and operational policy.', 'livecanvas-forge-ai'),
                    $remote_suffix,
                ],
            ],
        ];
    }

    private function get_partner_logo(string $type): string {
        switch ($type) {
            case 'livecanvas':
                $logo = $this->get_plugin_asset_url('livecanvas', 'images/lc-logo.svg');

                if ($logo) {
                    return '<img src="' . esc_url($logo) . '" alt="' . esc_attr__('LiveCanvas', 'livecanvas-forge-ai') . '" class="lcfa-logo lcfa-logo-livecanvas">';
                }

                return '<span class="lcfa-fallback-logo">LC</span>';

            case 'livecanvas-micro':
                $logo = $this->get_plugin_asset_url('livecanvas', 'images/lc-micrologo.svg');

                if ($logo) {
                    return '<img src="' . esc_url($logo) . '" alt="' . esc_attr__('LiveCanvas', 'livecanvas-forge-ai') . '" class="lcfa-logo lcfa-logo-livecanvas-micro">';
                }

                return '<span class="lcfa-fallback-logo lcfa-fallback-logo-micro">LC</span>';

            case 'windpress':
                $logo = $this->get_plugin_asset_url('windpress', 'windpress.svg');

                if ($logo) {
                    return '<img src="' . esc_url($logo) . '" alt="' . esc_attr__('WindPress', 'livecanvas-forge-ai') . '" class="lcfa-logo lcfa-logo-windpress">';
                }

                return '<span class="lcfa-fallback-logo">WP</span>';

            case 'bootstrap':
                return '<img src="' . esc_url('https://getbootstrap.com/docs/5.3/assets/brand/bootstrap-logo-shadow@2x.png') . '" alt="' . esc_attr__('Bootstrap', 'livecanvas-forge-ai') . '" class="lcfa-logo lcfa-logo-bootstrap-image">';

            default:
                return '<span class="lcfa-fallback-logo">AI</span>';
        }
    }

    private function get_command_form_context(array $actions): array {
        $defaults = [
            'action'        => 'site_audit',
            'execution_target' => 'local',
            'thread_id'     => 'default',
            'genesis_task_id' => '',
            'context_post_id' => '',
            'target_id'     => '',
            'variant'       => '1',
            'title'         => '',
            'slug'          => '',
            'provider_id'   => '',
            'relative_path' => '',
            'root_scope'    => 'stylesheet',
            'file_path'     => '',
            'backup_id'     => '',
            'audit_id'      => '',
            'status'        => 'draft',
            'user_prompt'   => '',
            'content'       => '',
            'dry_run'       => true,
            'context_label' => '',
        ];

        $requested_action = sanitize_key($_GET['suggest_action'] ?? '');
        if ($requested_action !== '' && isset($actions[$requested_action])) {
            $defaults['action'] = $requested_action;
        }

        $requested_execution_target = sanitize_key($_GET['execution_target'] ?? 'local');
        if (in_array($requested_execution_target, ['local', 'remote'], true)) {
            $defaults['execution_target'] = $requested_execution_target;
        }

        $defaults['thread_id']     = LCFA_Settings::normalize_thread_id((string) ($_GET['thread_id'] ?? 'default'));
        $defaults['genesis_task_id'] = sanitize_key((string) ($_GET['genesis_task_id'] ?? ''));
        $defaults['context_post_id'] = absint($_GET['post_id'] ?? 0) ?: '';
        $defaults['target_id']     = absint($_GET['target_id'] ?? 0) ?: '';
        $defaults['variant']       = sanitize_text_field($_GET['variant'] ?? '1');
        $defaults['title']         = sanitize_text_field($_GET['title'] ?? '');
        $defaults['slug']          = sanitize_title($_GET['slug'] ?? '');
        $defaults['provider_id']   = sanitize_text_field($_GET['provider_id'] ?? '');
        $defaults['relative_path'] = sanitize_text_field($_GET['relative_path'] ?? '');
        $defaults['root_scope']    = sanitize_key($_GET['root_scope'] ?? 'stylesheet');
        $defaults['file_path']     = sanitize_text_field($_GET['file_path'] ?? '');
        $defaults['backup_id']     = sanitize_text_field($_GET['backup_id'] ?? '');
        $defaults['audit_id']      = sanitize_key((string) ($_GET['audit_id'] ?? ''));
        $defaults['status']        = sanitize_key($_GET['status'] ?? 'draft');
        $defaults['user_prompt']   = sanitize_textarea_field((string) ($_GET['user_prompt'] ?? ''));

        $post_id = absint($_GET['post_id'] ?? 0);
        if ($post_id) {
            $post = get_post($post_id);

            if ($post instanceof WP_Post) {
                $context = $this->get_command_context_for_post($post);
                if (!empty($context['action']) && isset($actions[$context['action']])) {
                    $defaults['action'] = $context['action'];
                }
                if (!empty($context['target_id'])) {
                    $defaults['target_id'] = (string) $context['target_id'];
                }
                if (!empty($context['variant'])) {
                    $defaults['variant'] = (string) $context['variant'];
                }

                $defaults['context_label'] = sprintf(
                    __('Imported from LiveCanvas editor: %1$s (#%2$d, %3$s). Suggested action: %4$s.', 'livecanvas-forge-ai'),
                    get_the_title($post->ID) ?: __('Untitled', 'livecanvas-forge-ai'),
                    (int) $post->ID,
                    $post->post_type,
                    $this->get_action_label($defaults['action'])
                );
            }
        }

        if ($defaults['genesis_task_id'] !== '') {
            $plan = LCFA_Settings::get_genesis_plan();
            $tasks = is_array($plan['tasks'] ?? null) ? $plan['tasks'] : [];

            foreach ($tasks as $task) {
                if (!is_array($task) || sanitize_key((string) ($task['id'] ?? '')) !== $defaults['genesis_task_id']) {
                    continue;
                }

                if ($defaults['user_prompt'] === '' && !empty($task['user_prompt'])) {
                    $defaults['user_prompt'] = sanitize_textarea_field((string) $task['user_prompt']);
                }

                if (is_array($task['payload'] ?? null)) {
                    $defaults = $this->apply_genesis_task_payload_to_command_context($defaults, (array) $task['payload']);
                }

                if ($defaults['context_label'] === '') {
                    $defaults['context_label'] = sprintf(
                        __('Genesis task loaded: %1$s. Suggested action: %2$s.', 'livecanvas-forge-ai'),
                        (string) ($task['label'] ?? __('Genesis task', 'livecanvas-forge-ai')),
                        $this->get_action_label((string) ($defaults['action'] ?? 'site_audit'))
                    );
                }

                break;
            }
        }

        return $this->hydrate_command_form_context($defaults);
    }

    private function apply_genesis_task_payload_to_command_context(array $context, array $payload): array {
        $scalar_keys = [
            'action',
            'execution_target',
            'target_id',
            'variant',
            'title',
            'slug',
            'provider_id',
            'relative_path',
            'root_scope',
            'file_path',
            'backup_id',
            'audit_id',
            'status',
            'template_target',
            'native_key',
            'specialty',
        ];

        foreach ($scalar_keys as $key) {
            if (!array_key_exists($key, $payload) || $payload[$key] === '' || $payload[$key] === null) {
                continue;
            }

            switch ($key) {
                case 'action':
                case 'execution_target':
                case 'root_scope':
                case 'status':
                    $context[$key] = sanitize_key((string) $payload[$key]);
                    break;

                case 'target_id':
                    $context[$key] = absint($payload[$key]) ?: '';
                    break;

                case 'slug':
                    $context[$key] = sanitize_title((string) $payload[$key]);
                    break;

                default:
                    $context[$key] = sanitize_text_field((string) $payload[$key]);
                    break;
            }
        }

        if (!empty($payload['dry_run'])) {
            $context['dry_run'] = true;
        }

        if (!empty($payload['content']) && is_string($payload['content']) && $context['content'] === '') {
            $context['content'] = (string) $payload['content'];
            return $context;
        }

        $structured_payload = [];
        foreach ([
            'header_html',
            'header_html_lines',
            'footer_html',
            'footer_html_lines',
            'body_html',
            'body_html_lines',
            'footer_script',
            'footer_script_lines',
            'pages',
            'design_system',
            'template_assignment',
            'template_target',
            'native_key',
            'specialty',
            'colors',
            'typography',
            'radius',
            'buttons',
            'font_assets',
        ] as $key) {
            if (array_key_exists($key, $payload)) {
                $structured_payload[$key] = $payload[$key];
            }
        }

        if ($structured_payload && $context['content'] === '') {
            $context['content'] = (string) wp_json_encode($structured_payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        }

        return $context;
    }

    private function hydrate_command_form_context(array $context): array {
        $action = (string) ($context['action'] ?? '');
        $target = [
            'post'    => null,
            'content' => '',
        ];

        switch ($action) {
            case 'page_upsert':
            case 'update_page':
                if (!empty($context['target_id'])) {
                    $target = $this->inventory->get_target_content('page', (int) $context['target_id']);
                }
                break;

            case 'update_dynamic_template':
                if (!empty($context['target_id'])) {
                    $target = $this->inventory->get_target_content('dynamic_template', (int) $context['target_id']);
                }
                break;

            case 'update_partial':
                if (!empty($context['target_id'])) {
                    $target = $this->inventory->get_target_content('partial', (int) $context['target_id']);
                }
                break;

            case 'update_header':
                $target = $this->inventory->get_target_content('header', 0, (string) ($context['variant'] ?? '1'));
                break;

            case 'update_footer':
                $target = $this->inventory->get_target_content('footer', 0, (string) ($context['variant'] ?? '1'));
                break;

            case 'write_theme_template':
                if (!empty($context['file_path'])) {
                    try {
                        $target = $this->theme_files_bridge->read_template_file([
                            'root_scope' => (string) ($context['root_scope'] ?? 'active'),
                            'path'       => (string) $context['file_path'],
                        ]);
                    } catch (Throwable $throwable) {
                        $target = [
                            'content' => '',
                        ];
                    }
                }
                break;

            case 'write_theme_file':
                if (!empty($context['file_path'])) {
                    try {
                        $target = $this->theme_files_bridge->read_file([
                            'root_scope' => (string) ($context['root_scope'] ?? 'active'),
                            'path'       => (string) $context['file_path'],
                        ]);
                    } catch (Throwable $throwable) {
                        $target = [
                            'content' => '',
                        ];
                    }
                }
                break;

            case 'restore_theme_backup':
                if (!empty($context['backup_id'])) {
                    try {
                        $backup = $this->theme_files_bridge->read_backup([
                            'backup_id' => (string) $context['backup_id'],
                        ]);

                        if ($context['file_path'] === '') {
                            $context['file_path'] = (string) ($backup['relative_path'] ?? '');
                        }

                        if (($context['root_scope'] ?? 'stylesheet') === 'stylesheet' && !empty($backup['root'])) {
                            $context['root_scope'] = (string) $backup['root'];
                        }

                        if ($context['content'] === '') {
                            $context['content'] = (string) ($backup['content'] ?? '');
                        }

                        if ($context['context_label'] === '') {
                            $context['context_label'] = sprintf(
                                __('Backup selected: %1$s (%2$s). Suggested action: %3$s.', 'livecanvas-forge-ai'),
                                (string) ($backup['relative_path'] ?? (string) $context['backup_id']),
                                (string) ($backup['created_at'] ?? __('time unknown', 'livecanvas-forge-ai')),
                                $this->get_action_label($action)
                            );
                        }
                    } catch (Throwable $throwable) {
                        $target = [
                            'content' => '',
                        ];
                    }
                }
                break;
        }

        if (!empty($target['post']) && is_array($target['post'])) {
            if ($context['title'] === '') {
                $context['title'] = (string) ($target['post']['title'] ?? '');
            }
            if ($context['slug'] === '') {
                $context['slug'] = (string) ($target['post']['slug'] ?? '');
            }
            if ($context['status'] === 'draft' && !empty($target['post']['status'])) {
                $context['status'] = (string) $target['post']['status'];
            }
            if ($context['content'] === '') {
                $context['content'] = (string) ($target['content'] ?? '');
            }
            if ($context['target_id'] === '' && !empty($target['post']['id'])) {
                $context['target_id'] = (string) (int) $target['post']['id'];
            }
        }

        if ($context['content'] === '' && !empty($target['content']) && is_string($target['content'])) {
            $context['content'] = $target['content'];
        }

        return $context;
    }

    private function build_command_redirect_args(array $payload): array {
        $redirect_args = [];

        if (!empty($payload['action'])) {
            $redirect_args['suggest_action'] = sanitize_key((string) $payload['action']);
        }

        if (!empty($payload['execution_target'])) {
            $redirect_args['execution_target'] = sanitize_key((string) $payload['execution_target']);
        }

        if (!empty($payload['target_id'])) {
            $redirect_args['target_id'] = absint($payload['target_id']);
        }

        if (!empty($payload['variant'])) {
            $redirect_args['variant'] = sanitize_text_field((string) $payload['variant']);
        }

        if (!empty($payload['title'])) {
            $redirect_args['title'] = sanitize_text_field((string) $payload['title']);
        }

        if (!empty($payload['slug'])) {
            $redirect_args['slug'] = sanitize_title((string) $payload['slug']);
        }

        if (!empty($payload['provider_id'])) {
            $redirect_args['provider_id'] = sanitize_text_field((string) $payload['provider_id']);
        }

        if (!empty($payload['relative_path'])) {
            $redirect_args['relative_path'] = sanitize_text_field((string) $payload['relative_path']);
        }

        if (!empty($payload['root_scope'])) {
            $redirect_args['root_scope'] = sanitize_key((string) $payload['root_scope']);
        }

        if (!empty($payload['file_path'])) {
            $redirect_args['file_path'] = sanitize_text_field((string) $payload['file_path']);
        }

        if (!empty($payload['backup_id'])) {
            $redirect_args['backup_id'] = sanitize_text_field((string) $payload['backup_id']);
        }

        if (!empty($payload['audit_id'])) {
            $redirect_args['audit_id'] = sanitize_key((string) $payload['audit_id']);
        }

        if (!empty($payload['status'])) {
            $redirect_args['status'] = sanitize_key((string) $payload['status']);
        }

        return $redirect_args;
    }

    private function get_command_context_for_post(WP_Post $post): array {
        $context = [
            'action'    => '',
            'target_id' => (int) $post->ID,
            'variant'   => '1',
        ];

        if ($post->post_type === 'lc_dynamic_template') {
            $context['action'] = 'update_dynamic_template';
            return $context;
        }

        if ($post->post_type === 'lc_partial') {
            $header_variant = (string) get_post_meta($post->ID, 'is_header', true);
            $footer_variant = (string) get_post_meta($post->ID, 'is_footer', true);

            if ($header_variant !== '') {
                $context['action']  = 'update_header';
                $context['variant'] = $header_variant ?: '1';
                return $context;
            }

            if ($footer_variant !== '') {
                $context['action']  = 'update_footer';
                $context['variant'] = $footer_variant ?: '1';
                return $context;
            }

            $context['action'] = 'update_partial';
            return $context;
        }

        if (get_post_meta($post->ID, '_lc_livecanvas_enabled', true) === '1' || $post->post_type === 'page') {
            $context['action'] = 'page_upsert';
        }

        return $context;
    }

    private function get_editor_bridge_actions(WP_Post $post, array $context): array {
        $actions = [];
        $current_action = !empty($context['action']) ? (string) $context['action'] : 'site_audit';
        $mcp_status = $this->context_builder->get_mcp_status();
        $local_bridge = is_array($mcp_status['local_bridge'] ?? null) ? $mcp_status['local_bridge'] : [];

        $actions[] = [
            'label' => __('Current target', 'livecanvas-forge-ai'),
            'icon'  => 'command',
            'tone'  => 'primary',
            'url'   => $this->get_command_url([
                'post_id'        => $post->ID,
                'suggest_action' => $current_action,
                'target_id'      => (int) ($context['target_id'] ?? 0),
                'variant'        => (string) ($context['variant'] ?? '1'),
            ]),
        ];

        $actions[] = [
            'label' => __('Site audit', 'livecanvas-forge-ai'),
            'icon'  => 'activity',
            'tone'  => 'neutral',
            'url'   => $this->get_command_url([
                'suggest_action' => 'site_audit',
            ]),
        ];

        $inventory = method_exists($this->inventory, 'get_inventory') ? $this->inventory->get_inventory() : [];
        $header_partial = $this->get_first_inventory_partial((array) ($inventory['header_partials'] ?? []), 'header');
        $footer_partial = $this->get_first_inventory_partial((array) ($inventory['footer_partials'] ?? []), 'footer');

        if (!$header_partial && method_exists($this->inventory, 'resolve_partial_post_id')) {
            $header_id = (int) $this->inventory->resolve_partial_post_id('is_header', '1');
            if ($header_id > 0) {
                $header_partial = [
                    'id'           => $header_id,
                    'partial_type' => 'header',
                    'variant'      => '1',
                ];
            }
        }

        if (!$footer_partial && method_exists($this->inventory, 'resolve_partial_post_id')) {
            $footer_id = (int) $this->inventory->resolve_partial_post_id('is_footer', '1');
            if ($footer_id > 0) {
                $footer_partial = [
                    'id'           => $footer_id,
                    'partial_type' => 'footer',
                    'variant'      => '1',
                ];
            }
        }

        if ($header_partial) {
            $actions[] = [
                'label' => sprintf(__('Header partial v%s', 'livecanvas-forge-ai'), (string) ($header_partial['variant'] ?: '1')),
                'icon'  => 'layers',
                'tone'  => 'neutral',
                'url'   => $this->get_command_url([
                    'suggest_action' => 'update_header',
                    'target_id'      => (int) ($header_partial['id'] ?? 0),
                    'variant'        => (string) ($header_partial['variant'] ?: '1'),
                ]),
            ];
        }

        if ($footer_partial) {
            $actions[] = [
                'label' => sprintf(__('Footer partial v%s', 'livecanvas-forge-ai'), (string) ($footer_partial['variant'] ?: '1')),
                'icon'  => 'layers',
                'tone'  => 'neutral',
                'url'   => $this->get_command_url([
                    'suggest_action' => 'update_footer',
                    'target_id'      => (int) ($footer_partial['id'] ?? 0),
                    'variant'        => (string) ($footer_partial['variant'] ?: '1'),
                ]),
            ];
        }

        $actions[] = [
            'label' => __('WindPress audit', 'livecanvas-forge-ai'),
            'icon'  => 'wind',
            'tone'  => 'secondary',
            'url'   => $this->get_command_url([
                'suggest_action' => 'windpress_audit',
            ]),
        ];

        if (!empty($local_bridge['build_available'])) {
            $actions[] = [
                'label' => __('Build Tailwind', 'livecanvas-forge-ai'),
                'icon'  => 'rocket',
                'tone'  => 'secondary',
                'url'   => $this->get_command_url([
                    'suggest_action' => 'build_windpress_cache',
                ]),
            ];
        }

        $actions[] = [
            'label' => __('Connections', 'livecanvas-forge-ai'),
            'icon'  => 'plug',
            'tone'  => 'secondary',
            'url'   => $this->get_dashboard_url([
                'tab' => 'connections',
            ]),
        ];

        return array_slice($actions, 0, 7);
    }

    private function get_first_inventory_partial(array $partials, string $type): array {
        foreach ($partials as $partial) {
            if (!is_array($partial)) {
                continue;
            }

            if ((string) ($partial['partial_type'] ?? $type) !== $type) {
                continue;
            }

            return $partial + [
                'id'      => 0,
                'variant' => '1',
            ];
        }

        return [];
    }

    private function get_default_windpress_provider_ids(array $providers): string {
        $selected = [];

        foreach ($providers as $provider) {
            if (!is_array($provider) || empty($provider['id'])) {
                continue;
            }

            if (!empty($provider['enabled']) && (!array_key_exists('installed', $provider) || !empty($provider['installed']))) {
                $selected[] = (string) $provider['id'];
            }
        }

        if (!$selected && !empty($providers[0]['id'])) {
            $selected[] = (string) $providers[0]['id'];
        }

        return implode(',', array_values(array_unique($selected)));
    }

    private function format_file_size_label(int $bytes): string {
        return $bytes > 0 ? size_format($bytes) : __('0 B', 'livecanvas-forge-ai');
    }

    private function get_editor_target_summary(WP_Post $post, array $context): string {
        $variant = !empty($context['variant']) ? (string) $context['variant'] : '1';
        $label   = $this->get_editor_target_type_label($post, $context);

        if (($label === __('Header partial', 'livecanvas-forge-ai') || $label === __('Footer partial', 'livecanvas-forge-ai')) && $variant !== '1') {
            return sprintf(__('Target: %1$s · variant %2$s', 'livecanvas-forge-ai'), $label, $variant);
        }

        return sprintf(__('Target: %s', 'livecanvas-forge-ai'), $label);
    }

    private function get_editor_connection_status_label(string $client, string $state): string {
        $client = sanitize_key($client);

        if ($client === '') {
            return __('No agent connected', 'livecanvas-forge-ai');
        }

        $label = ucfirst(str_replace(['-', '_'], ' ', $client));

        if ($state === 'connected') {
            return sprintf(__('%s connected', 'livecanvas-forge-ai'), $label);
        }

        return sprintf(__('%s not connected', 'livecanvas-forge-ai'), $label);
    }

    private function get_editor_target_type_label(WP_Post $post, array $context): string {
        $action = !empty($context['action']) ? (string) $context['action'] : 'site_audit';

        if ($action === 'update_header') {
            return __('Header partial', 'livecanvas-forge-ai');
        }

        if ($action === 'update_footer') {
            return __('Footer partial', 'livecanvas-forge-ai');
        }

        if ($action === 'update_partial') {
            return __('Generic partial', 'livecanvas-forge-ai');
        }

        if ($post->post_type === 'lc_partial') {
            if ((string) get_post_meta($post->ID, 'is_header', true) === '1') {
                return __('Header partial', 'livecanvas-forge-ai');
            }

            if ((string) get_post_meta($post->ID, 'is_footer', true) === '1') {
                return __('Footer partial', 'livecanvas-forge-ai');
            }

            return __('Partial', 'livecanvas-forge-ai');
        }

        if ($post->post_type === 'lc_dynamic_template') {
            return __('Dynamic template', 'livecanvas-forge-ai');
        }

        if ($post->post_type === 'page') {
            return __('Page', 'livecanvas-forge-ai');
        }

        return ucwords(str_replace(['-', '_'], ' ', (string) $post->post_type));
    }

    private function get_editor_initial_conversation_state(array $messages): string {
        $latest_message = null;

        foreach (array_reverse($messages) as $message) {
            if (is_array($message)) {
                $latest_message = $message;
                break;
            }
        }

        if (!is_array($latest_message)) {
            return 'idle';
        }

        $role = (string) ($latest_message['role'] ?? '');
        $meta = is_array($latest_message['meta'] ?? null) ? $latest_message['meta'] : [];

        if ($role === 'suggestion_result') {
            return 'suggested';
        }

        if ($role === 'tool_result') {
            if (array_key_exists('ok', $meta) && empty($meta['ok'])) {
                return 'failed';
            }

            $mode = sanitize_key((string) ($meta['mode'] ?? ''));

            if (in_array($mode, ['preview', 'dry_run'], true)) {
                return 'previewed';
            }

            return 'applied';
        }

        return 'idle';
    }

    private function get_editor_conversation_state_label(string $state): string {
        switch ($state) {
            case 'thinking':
                return __('Sending request...', 'livecanvas-forge-ai');
            case 'queueing':
                return __('Queued for inline execution.', 'livecanvas-forge-ai');
            case 'running':
                return __('Running inline execution...', 'livecanvas-forge-ai');
            case 'suggested':
                return __('Request prepared.', 'livecanvas-forge-ai');
            case 'previewed':
                return __('Preview ready. Review the support details below.', 'livecanvas-forge-ai');
            case 'applied':
                return __('Change applied inline.', 'livecanvas-forge-ai');
            case 'failed':
                return __('The current request failed. Review the support details below.', 'livecanvas-forge-ai');
            case 'idle':
            default:
                return __('Ready for a new request.', 'livecanvas-forge-ai');
        }
    }

    private function render_editor_bridge_thread_message(array $message): void {
        $message = LCFA_Thread_Message_Actions::decorate_message($message, [
            'thread_id' => LCFA_Settings::normalize_thread_id((string) ($_GET['thread_id'] ?? 'default')),
            'command_url_builder' => [$this, 'get_command_url'],
        ]);
        $role = in_array((string) ($message['role'] ?? ''), ['user', 'assistant', 'suggestion_result', 'system', 'tool_result'], true)
            ? (string) $message['role']
            : 'assistant';

        if ($role === 'suggestion_result') {
            return;
        }

        echo '<article class="lcfa-editor-thread-message is-' . esc_attr($role) . '">';
        echo '<div class="lcfa-editor-thread-message__head">';
        echo '<span>' . esc_html((string) ($message['label'] ?? ucfirst($role))) . '</span>';
        echo '<span>' . esc_html((string) ($message['time'] ?? '')) . '</span>';
        echo '</div>';
        echo '<pre class="lcfa-editor-thread-message__body">' . esc_html((string) ($message['content'] ?? '')) . '</pre>';
        $attachments = is_array($message['attachments'] ?? null) ? (array) $message['attachments'] : [];
        if ($attachments) {
            echo '<div class="lcfa-editor-thread-message__attachments">';
            foreach ($attachments as $attachment) {
                if (!is_array($attachment) || ($attachment['kind'] ?? '') !== 'image' || empty($attachment['data_url'])) {
                    continue;
                }

                echo '<figure class="lcfa-editor-thread-message__attachment">';
                echo '<img class="lcfa-editor-thread-message__attachment-image" src="' . esc_attr((string) $attachment['data_url']) . '" alt="">';
                $attachment_copy = trim(implode(' • ', array_filter([
                    (string) ($attachment['name'] ?? ''),
                    (string) ($attachment['caption'] ?? ''),
                ])));
                if ($attachment_copy !== '') {
                    echo '<figcaption class="lcfa-editor-thread-message__attachment-copy">' . esc_html($attachment_copy) . '</figcaption>';
                }
                echo '</figure>';
            }
            echo '</div>';
        }
        $meta_badges = $this->get_thread_message_meta_badges(is_array($message['meta'] ?? null) ? (array) $message['meta'] : []);
        if ($meta_badges) {
            echo '<div class="lcfa-editor-thread-message__meta">';
            foreach ($meta_badges as $badge) {
                echo '<span class="lcfa-editor-thread-message__chip">' . esc_html($badge) . '</span>';
            }
            echo '</div>';
        }
        $actions = LCFA_Thread_Message_Actions::sanitize_actions((array) ($message['actions'] ?? []));
        if ($actions && $role !== 'suggestion_result') {
            echo '<div class="lcfa-editor-thread-message__actions">';
            foreach ($actions as $action) {
                if (($action['kind'] ?? 'url') === 'apply' && !empty($action['payload'])) {
                    echo '<button type="button" class="lcfa-editor-thread-message__link" data-lcfa-editor-thread-apply="' . esc_attr(wp_json_encode($action['payload'])) . '">' . esc_html((string) $action['label']) . '</button>';
                    continue;
                }

                echo '<a class="lcfa-editor-thread-message__link" href="' . esc_url((string) ($action['url'] ?? '')) . '" target="_blank" rel="noreferrer noopener">' . esc_html((string) $action['label']) . '</a>';
            }
            echo '</div>';
        }
        echo '</article>';
    }

    private function get_action_label(string $action): string {
        $actions = $this->command_deck->get_actions();

        return isset($actions[$action]['label']) ? (string) $actions[$action]['label'] : $action;
    }

    private function get_inventory_item_command_url(string $group_key, array $item): string {
        $post = !empty($item['id']) ? get_post((int) $item['id']) : null;

        if (!$post instanceof WP_Post) {
            return '';
        }

        $context = $this->get_command_context_for_post($post);

        if ($group_key === 'header_partials') {
            $context['action'] = 'update_header';
        } elseif ($group_key === 'footer_partials') {
            $context['action'] = 'update_footer';
        } elseif ($group_key === 'dynamic_templates') {
            $context['action'] = 'update_dynamic_template';
        } elseif ($group_key === 'livecanvas_pages') {
            $context['action'] = 'page_upsert';
        }

        if (empty($context['action'])) {
            return '';
        }

        return $this->get_command_url([
            'post_id'        => $post->ID,
            'suggest_action' => $context['action'] ?? '',
            'target_id'      => $context['target_id'] ?? 0,
            'variant'        => $context['variant'] ?? '',
        ]);
    }

    private function get_command_url(array $args = []): string {
        $defaults = [
            'tab' => 'command',
        ];
        $current_thread_id = LCFA_Settings::normalize_thread_id((string) ($_GET['thread_id'] ?? ''));

        if ($current_thread_id !== 'default' && !array_key_exists('thread_id', $args)) {
            $defaults['thread_id'] = $current_thread_id;
        }

        return $this->get_dashboard_url(array_merge($defaults, $args));
    }

    private function get_dashboard_url(array $args = []): string {
        return add_query_arg(array_merge([
            'page' => 'lcfa-dashboard',
        ], $args), admin_url('admin.php'));
    }

    private function get_plugin_asset_url(string $slug, string $relative_path): string {
        $plugin_file = $this->environment->find_plugin_file_by_slug($slug);

        if (!$plugin_file) {
            return '';
        }

        return plugins_url($relative_path, WP_PLUGIN_DIR . '/' . $plugin_file);
    }

    private function get_agent_icon_url(string $client): string {
        $map = [
            'codex'    => 'assets/agent-icons/codex-color.svg',
            'opencode' => 'assets/agent-icons/opencode.svg',
            'cursor'   => 'assets/agent-icons/cursor.svg',
            'claude'   => 'assets/agent-icons/claude-color.svg',
        ];

        if ($client === 'claude-code') {
            $client = 'claude';
        }

        if (empty($map[$client])) {
            return '';
        }

        $asset_relative_path = $map[$client];
        $asset_absolute_path = LCFA_DIR . $asset_relative_path;

        if (!file_exists($asset_absolute_path)) {
            return '';
        }

        return LCFA_URL . $asset_relative_path;
    }

    private function get_agent_icon_markup(string $client, string $fallback_icon = 'plug', string $class = 'lcfa-agent-icon'): string {
        $icon_url = $this->get_agent_icon_url($client);

        if ($icon_url !== '') {
            return '<img src="' . esc_url($icon_url) . '" alt="" class="' . esc_attr($class) . '" loading="lazy">';
        }

        return $this->get_icon_svg($fallback_icon);
    }

    private function get_radio_icon_markup(string $name, string $value, string $fallback_icon): string {
        if (in_array($name, ['ai_tool', 'preferred_client'], true)) {
            return $this->get_agent_icon_markup($value, $fallback_icon);
        }

        return $this->get_icon_svg($fallback_icon);
    }

    private function get_client_fallback_icon(string $client): string {
        $map = [
            'codex' => 'stars',
            'opencode' => 'braces',
            'claude' => 'cpu',
            'claude-code' => 'cpu',
            'cursor' => 'cursor',
            'generic' => 'plug',
        ];

        return $map[$client] ?? 'plug';
    }

    private function get_icon_svg(string $name): string {
        $icons = [
            'activity' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M6 2a.5.5 0 0 1 .47.329L8.708 8H11.5a.5.5 0 0 1 .39.812l-2.5 3A.5.5 0 0 1 9 12H6.292l-1.823 1.823A.5.5 0 0 1 3.646 13H1.5a.5.5 0 0 1 0-1h1.793l1.854-1.854A.5.5 0 0 1 5.5 10H8.77l1.667-2H8.292a.5.5 0 0 1-.47-.329L5.59 2.53A.5.5 0 0 1 6 2Z"/></svg>',
            'braces' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M6.114 2.68a.5.5 0 0 1-.496.444c-.694.049-1.198.292-1.546.721-.35.43-.54 1.09-.54 1.955v.662c0 .97-.19 1.683-.582 2.18-.194.246-.44.44-.734.58.294.14.54.334.734.58.392.497.582 1.21.582 2.18v.661c0 .865.19 1.526.54 1.955.348.43.852.672 1.546.721a.5.5 0 0 1-.07.998c-.93-.066-1.715-.404-2.252-1.066-.537-.662-.764-1.57-.764-2.608v-.661c0-.839-.161-1.326-.37-1.592C1.832 10.542 1.5 10.386 1 10.386v-.772c.5 0 .832-.156 1.178-.596.209-.266.37-.753.37-1.592v-.662c0-1.038.227-1.946.764-2.608.537-.662 1.322-1 2.252-1.066a.5.5 0 0 1 .55.49Zm3.772 0a.5.5 0 0 1 .55-.49c.93.066 1.715.404 2.252 1.066.537.662.764 1.57.764 2.608v.662c0 .839.161 1.326.37 1.592.346.44.678.596 1.178.596v.772c-.5 0-.832.156-1.178.596-.209.266-.37.753-.37 1.592v.661c0 1.038-.227 1.946-.764 2.608-.537.662-1.322 1-2.252 1.066a.5.5 0 0 1-.07-.998c.694-.049 1.198-.292 1.546-.721.35-.43.54-1.09.54-1.955v-.661c0-.97.19-1.683.582-2.18.194-.246.44-.44.734-.58-.294-.14-.54-.334-.734-.58-.392-.497-.582-1.21-.582-2.18v-.662c0-.865-.19-1.526-.54-1.955-.348-.43-.852-.672-1.546-.721a.5.5 0 0 1-.496-.444Z"/></svg>',
            'check-circle' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0ZM6.97 11.03a.75.75 0 0 0 1.08.022l3.992-4.99a.75.75 0 0 0-1.172-.938L7.404 9.462 5.383 7.44a.75.75 0 1 0-1.06 1.06l2.647 2.53Z"/></svg>',
            'check2-square' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M14 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h12ZM2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2Z"/><path fill="currentColor" d="M10.854 5.146a.5.5 0 0 1 0 .708l-3.5 3.5a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7 8.293l3.146-3.147a.5.5 0 0 1 .708 0Z"/></svg>',
            'cloud' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M4.406 2.342A5.53 5.53 0 0 1 8 1c2.453 0 4.512 1.59 5.258 3.787A4.5 4.5 0 0 1 13.5 13h-9A4.5 4.5 0 0 1 4.406 2.342Z"/></svg>',
            'command' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M7.5 2a1.5 1.5 0 0 0-3 0V4h-2A1.5 1.5 0 0 0 1 5.5v1A1.5 1.5 0 0 0 2.5 8h2v2h-2A1.5 1.5 0 0 0 1 11.5v1A1.5 1.5 0 0 0 2.5 14h1A1.5 1.5 0 0 0 5 12.5V10h2v2.5A1.5 1.5 0 0 0 8.5 14h1a1.5 1.5 0 0 0 1.5-1.5V10h2a1.5 1.5 0 0 0 1.5-1.5v-1A1.5 1.5 0 0 0 13.5 6h-2V3.5A1.5 1.5 0 0 0 10 2h-1A1.5 1.5 0 0 0 7.5 3.5V6h-2V3.5A1.5 1.5 0 0 0 4 2h1A1.5 1.5 0 0 1 6.5 3.5V6h3V3.5A1.5 1.5 0 0 0 8 2h-.5Z"/></svg>',
            'cpu' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M5 0a.5.5 0 0 1 .5.5V1h5V.5a.5.5 0 0 1 1 0V1h.5A1.5 1.5 0 0 1 13.5 2.5V3h.5a.5.5 0 0 1 0 1h-.5v2h.5a.5.5 0 0 1 0 1h-.5v2h.5a.5.5 0 0 1 0 1h-.5v.5A1.5 1.5 0 0 1 12 12h-.5v.5a.5.5 0 0 1-1 0V12h-5v.5a.5.5 0 0 1-1 0V12H4A1.5 1.5 0 0 1 2.5 10.5V10H2a.5.5 0 0 1 0-1h.5V7H2a.5.5 0 0 1 0-1h.5V4H2a.5.5 0 0 1 0-1h.5v-.5A1.5 1.5 0 0 1 4 1h.5V.5A.5.5 0 0 1 5 0Zm-1 2a.5.5 0 0 0-.5.5v8A.5.5 0 0 0 4 11h8a.5.5 0 0 0 .5-.5v-8A.5.5 0 0 0 12 2H4Zm2 2h4v4H6V4Zm1 1v2h2V5H7Z"/></svg>',
            'cursor' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M5.884.511a.5.5 0 0 1 .624.307l4.61 12.905a.5.5 0 0 1-.663.636L7.93 13.25l-1.762 2.817a.5.5 0 0 1-.9-.042L.53 1.836A.5.5 0 0 1 1.16 1.16L5.884.511Z"/></svg>',
            'eye' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M16 8s-3-5.5-8-5.5S0 8 0 8s3 5.5 8 5.5S16 8 16 8Zm-8 4a4 4 0 1 1 0-8 4 4 0 0 1 0 8Zm0-1.5A2.5 2.5 0 1 0 8 5.5a2.5 2.5 0 0 0 0 5Z"/></svg>',
            'file-earmark' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M14 4.5V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5L14 4.5ZM9.5 3A1.5 1.5 0 0 0 11 4.5H13L9.5 1v2Z"/></svg>',
            'globe' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0Zm4.96 7H9.6a13.45 13.45 0 0 0-.48-3.03A6.52 6.52 0 0 1 12.96 7ZM8 1.04c.83 0 1.84 1.23 2.27 3.46H5.73C6.16 2.27 7.17 1.04 8 1.04ZM3.04 7a6.52 6.52 0 0 1 3.84-3.03A13.45 13.45 0 0 0 6.4 7H3.04Zm0 2H6.4c.07 1.09.24 2.12.48 3.03A6.52 6.52 0 0 1 3.04 9Zm4.96 5.96c-.83 0-1.84-1.23-2.27-3.46h4.54c-.43 2.23-1.44 3.46-2.27 3.46ZM9.12 12.03c.24-.91.41-1.94.48-3.03h3.36a6.52 6.52 0 0 1-3.84 3.03Z"/></svg>',
            'laptop' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M13.5 3h-11A1.5 1.5 0 0 0 1 4.5v6A1.5 1.5 0 0 0 2.5 12h11a1.5 1.5 0 0 0 1.5-1.5v-6A1.5 1.5 0 0 0 13.5 3ZM2 4.5a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-6ZM0 13.5a.5.5 0 0 1 .5-.5h15a.5.5 0 0 1 0 1H.5a.5.5 0 0 1-.5-.5Z"/></svg>',
            'layers' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M8.235 1.559a.5.5 0 0 0-.47 0l-6.5 3.25a.5.5 0 0 0 0 .894l6.5 3.25a.5.5 0 0 0 .47 0l6.5-3.25a.5.5 0 0 0 0-.894l-6.5-3.25ZM2.33 5.5 8 2.665 13.67 5.5 8 8.335 2.33 5.5Zm-1.565 2.54a.5.5 0 0 1 .67-.224L8 10.835l6.565-3.019a.5.5 0 0 1 .447.894l-6.8 3.125a.5.5 0 0 1-.424 0l-6.8-3.125a.5.5 0 0 1-.224-.67Zm0 3a.5.5 0 0 1 .67-.224L8 13.835l6.565-3.019a.5.5 0 0 1 .447.894l-6.8 3.125a.5.5 0 0 1-.424 0l-6.8-3.125a.5.5 0 0 1-.224-.67Z"/></svg>',
            'moon-stars' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M6 0a.5.5 0 0 1 .5.5V2H8a.5.5 0 0 1 0 1H6.5v1.5a.5.5 0 0 1-1 0V3H4a.5.5 0 0 1 0-1h1.5V.5A.5.5 0 0 1 6 0Zm7 3a.5.5 0 0 1 .5.5V4H14a.5.5 0 0 1 0 1h-.5v.5a.5.5 0 0 1-1 0V5H12a.5.5 0 0 1 0-1h.5v-.5A.5.5 0 0 1 13 3Zm-4.36 1.5a.5.5 0 0 1 .363.648A5.5 5.5 0 1 0 12.852 12a.5.5 0 0 1 .648.363.5.5 0 0 1-.32.61A6.5 6.5 0 1 1 8.03 4.18a.5.5 0 0 1 .61.32Z"/></svg>',
            'plug' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M6 0a.5.5 0 0 1 .5.5V3H8V.5a.5.5 0 0 1 1 0V3h1.5V.5a.5.5 0 0 1 1 0V3h.5A1.5 1.5 0 0 1 13.5 4.5v2A1.5 1.5 0 0 1 12 8h-.5v1A3.5 3.5 0 0 1 8 12.5V15a1 1 0 0 1-2 0v-2.5A3.5 3.5 0 0 1 2.5 9V8H2A1.5 1.5 0 0 1 .5 6.5v-2A1.5 1.5 0 0 1 2 3h.5V.5A.5.5 0 0 1 3 0h3Z"/></svg>',
            'power' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M7.25 1.5a.75.75 0 0 1 1.5 0v5.25a.75.75 0 0 1-1.5 0V1.5Z"/><path fill="currentColor" d="M4.11 2.89a.75.75 0 0 1 1.06 1.06A5.25 5.25 0 1 0 12.83 4a.75.75 0 1 1 1.06-1.06 6.75 6.75 0 1 1-9.78-.05Z"/></svg>',
            'rocket' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M8 0C5.613 2.016 4.5 4.515 4.5 7c0 1.377.268 2.486.67 3.311L2 13.48V16h2.52l3.17-3.17A6.37 6.37 0 0 0 9 13.5c2.485 0 4.984-1.113 7-3.5C16 5.582 14.418 0 8 0ZM5.5 6.5A1.5 1.5 0 1 1 8 5a1.5 1.5 0 0 1-2.5 1.5ZM3 9.5 0 13l3 3v-2.5l2.5-2.5L3 9.5Z"/></svg>',
            'shield-check' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M5.072.21a17.598 17.598 0 0 1 5.856 0A1 1 0 0 1 11.81 1l.39 2.924a16.99 16.99 0 0 1-.23 5.082A7.962 7.962 0 0 1 8 14.548a7.962 7.962 0 0 1-3.97-5.542 16.99 16.99 0 0 1-.23-5.082L4.19 1a1 1 0 0 1 .882-.79ZM10.854 5.146a.5.5 0 0 0-.708 0L7.5 7.793 6.354 6.646a.5.5 0 1 0-.708.708l1.5 1.5a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0 0-.708Z"/></svg>',
            'shield-lock' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M5.072.21a17.598 17.598 0 0 1 5.856 0A1 1 0 0 1 11.81 1l.39 2.924a16.99 16.99 0 0 1-.23 5.082A7.962 7.962 0 0 1 8 14.548a7.962 7.962 0 0 1-3.97-5.542 16.99 16.99 0 0 1-.23-5.082L4.19 1a1 1 0 0 1 .882-.79ZM8 8a1 1 0 0 0-1 1v1h2V9a1 1 0 0 0-1-1Zm2 2V9a2 2 0 1 0-4 0v1a1 1 0 0 0-1 1v1.5A1.5 1.5 0 0 0 6.5 14h3A1.5 1.5 0 0 0 11 12.5V11a1 1 0 0 0-1-1Z"/></svg>',
            'shuffle' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M9.5 3a.5.5 0 0 1 .5-.5h3A.5.5 0 0 1 13.5 3v3a.5.5 0 0 1-1 0V4.707l-2.646 2.647a.5.5 0 0 1-.708-.708L11.793 4H10a.5.5 0 0 1-.5-.5Zm-3 0a.5.5 0 0 1 .354.146l2 2a.5.5 0 1 1-.708.708l-2-2A.5.5 0 0 1 6.5 3Zm2.354 5.146a.5.5 0 0 1 0 .708l-2 2a.5.5 0 0 1-.708-.708l2-2a.5.5 0 0 1 .708 0ZM9.5 10a.5.5 0 0 1 .5-.5h1.793L9.146 6.854a.5.5 0 1 1 .708-.708L12.5 8.793V7.5a.5.5 0 0 1 1 0v3a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5Z"/><path fill="currentColor" d="M3.5 4A1.5 1.5 0 0 0 2 5.5v5A1.5 1.5 0 0 0 3.5 12h1a.5.5 0 0 0 0-1h-1a.5.5 0 0 1-.5-.5v-5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 0 0-1h-1Z"/></svg>',
            'stars' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M7.247 4.86 8 3l.753 1.86L10.613 5l-1.86.753L8 7.613 7.247 5.753 5.387 5l1.86-.14Zm6.192 3.332L14 7l.56 1.192L15.753 9l-1.193.808L14 11l-.56-1.192L12.247 9l1.192-.808ZM3.5 10.5 4 9l.5 1.5L6 11l-1.5.5L4 13l-.5-1.5L2 11l1.5-.5ZM8 8l1.09 2.91L12 12l-2.91 1.09L8 16l-1.09-2.91L4 12l2.91-1.09L8 8Z"/></svg>',
            'wind' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M6 1.5A2.5 2.5 0 1 1 8.5 4H1.5a.5.5 0 0 1 0-1h7a1.5 1.5 0 1 0-1.5-1.5.5.5 0 0 1-1 0Zm4 4A2.5 2.5 0 1 1 12.5 8H1.5a.5.5 0 0 1 0-1h11a1.5 1.5 0 1 0-1.5-1.5.5.5 0 0 1-1 0ZM4 9a2.5 2.5 0 1 1 2.45 3H1.5a.5.5 0 0 1 0-1h4.95A1.5 1.5 0 1 0 5 9.5a.5.5 0 0 1-1 0Z"/></svg>',
            'window-stack' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M3 1a2 2 0 0 0-2 2v7h1V3a1 1 0 0 1 1-1h8V1H3Zm2 3a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2H5Zm0 1h8a1 1 0 0 1 1 1v1H4V6a1 1 0 0 1 1-1Zm-1 3h10v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V8Z"/></svg>',
            'x-circle' => '<svg viewBox="0 0 16 16" aria-hidden="true"><path fill="currentColor" d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0ZM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646Z"/></svg>',
        ];

        $svg = $icons[$name] ?? $icons['stars'];

        return '<span class="lcfa-icon lcfa-icon-' . esc_attr($name) . '">' . $svg . '</span>';
    }

    private function sanitize_key_compat(string $value): string {
        if (function_exists('sanitize_key')) {
            return sanitize_key($value);
        }

        $value = strtolower($value);
        $value = preg_replace('/[^a-z0-9_-]/', '', $value);

        return is_string($value) ? $value : '';
    }

    private function redirect_to_step(int $step): void {
        wp_safe_redirect(admin_url('admin.php?page=lcfa-dashboard&tab=setup&step=' . $step));
        exit;
    }
}
