<?php

defined('ABSPATH') || exit;

require_once __DIR__ . '/class-lcfa-agent-registry.php';
require_once __DIR__ . '/class-lcfa-connection-attempt.php';
if (!class_exists('LCFA_Session_Store', false)) require_once __DIR__ . '/class-lcfa-session-store.php';

final class LCFA_MCP_Session_Manager {
    private static array $current_session = [];
    private const SESSIONS_OPTION_KEY = 'lcfa_mcp_sessions';
    private const PAIRINGS_OPTION_KEY = 'lcfa_mcp_pairings';
    private const PAIRING_INDEX_OPTION_KEY = 'lcfa_mcp_pairing_index';
    private const PAIRING_TRANSIENT_PREFIX = 'lcfa_mcp_pairing_';
    private const PAIRING_RATE_PREFIX = 'lcfa_mcp_pairing_rate_';
    private const PAIRING_ADMIN_ANCHOR = 'lcfa-secure-codex-pairing-sessions';
    private const PAIRING_TTL = 600;
    private const SESSION_TTL = 2592000;

    public static function start_pairing(array $payload, ?WP_REST_Request $request = null) {
        $rate_limited = self::is_pairing_rate_limited($request);
        if ($rate_limited instanceof WP_Error) {
            return $rate_limited;
        }

        $site_fingerprint = sanitize_text_field((string) ($payload['site_fingerprint'] ?? ''));
        $expected_fingerprint = self::get_site_fingerprint();
        if ($site_fingerprint !== '' && $expected_fingerprint !== '' && !hash_equals($expected_fingerprint, $site_fingerprint)) {
            return new WP_Error(
                'lcfa_pairing_site_mismatch',
                __('This pairing request targets a different AI Bridge site fingerprint.', 'livecanvas-forge-ai'),
                ['status' => 403]
            );
        }

        $now = time();
        $client = self::sanitize_client((string) ($payload['client'] ?? 'codex'));
        $connection_mode = self::sanitize_connection_mode((string) ($payload['connection_mode'] ?? 'remote'));
        $client_label = self::get_client_label($client);
        $project_label = sanitize_text_field((string) ($payload['project_label'] ?? ''));
        if ($project_label === '') {
            $project_label = $client_label . ' project';
        }
        $pairing_id = 'pair_' . strtolower(self::random_url_token(12));
        $device_secret = 'lcfa_dev_' . self::random_url_token(32);
        $user_code = self::generate_user_code();
        $record = [
            'pairing_id'         => $pairing_id,
            'user_code'          => $user_code,
            'client'             => $client,
            'connection_mode'    => $connection_mode,
            'project_label'      => $project_label,
            'site_fingerprint'   => $site_fingerprint !== '' ? $site_fingerprint : $expected_fingerprint,
            'scopes'             => self::sanitize_scopes((array) ($payload['scopes'] ?? ['read', 'preview', 'write'])),
            'status'             => 'pending',
            'device_secret_hash' => self::hash_token($device_secret),
            'session_id'         => '',
            'created_at'         => gmdate('c', $now),
            'expires_at'         => gmdate('c', $now + self::PAIRING_TTL),
            'approved_at'        => '',
            'consumed_at'        => '',
        ];

        $attempt_id = (string) ($payload['connection_attempt'] ?? '');
        if ($attempt_id !== '') {
            if (!LCFA_Connection_Attempt::bind_pairing($attempt_id, $record)) {
                return new WP_Error('lcfa_connection_attempt_mismatch', __('This connection request expired, was already used, or belongs to another client. Start a new connection in WordPress.', 'livecanvas-forge-ai'), ['status' => 409]);
            }
            $record['connection_attempt'] = $attempt_id;
        }

        self::save_pairing_record($pairing_id, $record);
        self::index_pairing($pairing_id);

        return [
            'ok'               => true,
            'pairing_id'       => $pairing_id,
            'device_secret'    => $device_secret,
            'user_code'        => $user_code,
            'verification_url' => self::get_verification_url($attempt_id),
            'expires_at'       => $record['expires_at'],
            'client'           => $client,
            'connection_mode'  => $connection_mode,
            'project_label'    => $project_label,
            'site_fingerprint' => (string) $record['site_fingerprint'],
            'scopes'           => (array) $record['scopes'],
            'message'          => sprintf(
                __('Approve this %s pairing request in LiveCanvas AI Bridge.', 'livecanvas-forge-ai'),
                self::get_client_label((string) $record['client'])
            ),
        ];
    }

    public static function get_pairing_status(string $pairing_id, string $device_secret) {
        $pairing_id = sanitize_key($pairing_id);
        $record = self::get_pairing_record($pairing_id);
        if (!$record) {
            return [
                'ok'      => false,
                'status'  => 'expired',
                'message' => __('The pairing request expired or was not found.', 'livecanvas-forge-ai'),
            ];
        }

        if (!hash_equals((string) ($record['device_secret_hash'] ?? ''), self::hash_token($device_secret))) {
            return new WP_Error(
                'lcfa_pairing_forbidden',
                __('The pairing device secret is invalid.', 'livecanvas-forge-ai'),
                ['status' => 403]
            );
        }

        if (self::is_expired((string) ($record['expires_at'] ?? ''))) {
            self::delete_pairing($pairing_id);
            return [
                'ok'      => false,
                'status'  => 'expired',
                'message' => __('The pairing request expired.', 'livecanvas-forge-ai'),
            ];
        }

        if (($record['status'] ?? '') !== 'approved') {
            $client_label = self::get_client_label((string) ($record['client'] ?? 'codex'));
            return [
                'ok'          => true,
                'status'      => (string) ($record['status'] ?? 'pending'),
                'pairing_id'  => $pairing_id,
                'user_code'   => (string) ($record['user_code'] ?? ''),
                'expires_at'  => (string) ($record['expires_at'] ?? ''),
                'message'     => sprintf(
                    __('Waiting for a WordPress admin to approve this %s pairing request.', 'livecanvas-forge-ai'),
                    $client_label
                ),
            ];
        }

        $session_token = (string) ($record['session_token'] ?? '');
        if ($session_token === '') {
            return [
                'ok'         => true,
                'status'     => 'consumed',
                'session_id' => (string) ($record['session_id'] ?? ''),
                'message'    => __('The pairing token was already consumed. Restart the MCP server if the session was cached, or create a new pairing request.', 'livecanvas-forge-ai'),
            ];
        }

        unset($record['session_token']);
        $record['status'] = 'consumed';
        $record['consumed_at'] = gmdate('c');
        self::save_pairing_record($pairing_id, $record);

        $client_label = self::get_client_label((string) ($record['client'] ?? 'codex'));

        return [
            'ok'            => true,
            'status'        => 'approved',
            'session_id'    => (string) ($record['session_id'] ?? ''),
            'session_token' => $session_token,
            'expires_at'    => self::get_session_expires_at((string) ($record['session_id'] ?? '')),
            'client'        => self::sanitize_client((string) ($record['client'] ?? 'codex')),
            'connection_mode' => self::sanitize_connection_mode((string) ($record['connection_mode'] ?? 'remote')),
            'project_label' => sanitize_text_field((string) ($record['project_label'] ?? '')),
            'site_fingerprint' => sanitize_text_field((string) ($record['site_fingerprint'] ?? '')),
            'scopes'        => self::sanitize_scopes((array) ($record['scopes'] ?? [])),
            'message'       => sprintf(
                __('%s pairing approved. The AI Bridge session token was issued once.', 'livecanvas-forge-ai'),
                $client_label
            ),
        ];
    }

    public static function approve_pairing(string $pairing_id): array {
        $pairing_id = sanitize_key($pairing_id);
        $record = self::get_pairing_record($pairing_id);
        if (!$record || self::is_expired((string) ($record['expires_at'] ?? ''))) {
            self::delete_pairing($pairing_id);
            return [
                'ok'      => false,
                'message' => __('The pairing request expired or was not found.', 'livecanvas-forge-ai'),
            ];
        }

        if (($record['status'] ?? '') !== 'pending') {
            return ['ok' => false, 'message' => __('This pairing request has already been processed.', 'livecanvas-forge-ai')];
        }
        $attempt_id = (string) ($record['connection_attempt'] ?? '');
        $owner_id = function_exists('get_current_user_id') ? get_current_user_id() : 0;
        if ($attempt_id !== '' && !LCFA_Connection_Attempt::can_approve($attempt_id, $pairing_id, $owner_id)) {
            return ['ok' => false, 'message' => __('Sign in as the administrator who started this connection, or start a new connection.', 'livecanvas-forge-ai')];
        }
        if ($attempt_id !== '' && !self::owner_can_authorize_full_access($owner_id)) {
            return ['ok' => false, 'message' => __('Your WordPress role cannot grant Full Access. Use manual setup with limited scopes, or ask a site administrator to connect.', 'livecanvas-forge-ai')];
        }

        $session_token = 'lcfa_sess_' . self::random_url_token(40);
        $session_id = 'sess_' . strtolower(self::random_url_token(12));
        $now = time();
        $client = self::sanitize_client((string) ($record['client'] ?? 'codex'));
        $client_label = self::get_client_label($client);
        $project_label = sanitize_text_field((string) ($record['project_label'] ?? ''));
        if ($project_label === '') {
            $project_label = $client_label . ' project';
        }
        $session = [
            'session_id'       => $session_id,
            'client'           => $client,
            'connection_mode'  => self::sanitize_connection_mode((string) ($record['connection_mode'] ?? 'remote')),
            'project_label'    => $project_label,
            'site_fingerprint' => sanitize_text_field((string) ($record['site_fingerprint'] ?? self::get_site_fingerprint())),
            'scopes'           => self::sanitize_scopes((array) ($record['scopes'] ?? ['read', 'preview', 'write'])),
            'created_at'       => gmdate('c', $now),
            'expires_at'       => gmdate('c', $now + self::SESSION_TTL),
            'last_seen_at'     => '',
            'revoked_at'       => '',
            'token_hash'       => self::hash_token($session_token),
        ];
        if ($attempt_id !== '') {
            $session['connection_attempt'] = $attempt_id;
            $session['owner_user_id'] = $owner_id;
            $session['access_profile'] = 'full';
            if (!LCFA_Connection_Attempt::approved($attempt_id, $pairing_id, $owner_id, $session_id)) {
                return ['ok' => false, 'message' => __('This connection request expired. Start again.', 'livecanvas-forge-ai')];
            }
        }

        LCFA_Session_Store::mutate(static function ($sessions) use ($session_id, $session) {
            if (isset($sessions[$session_id])) throw new RuntimeException('session_id_conflict');
            $sessions[$session_id] = $session;
            return $sessions;
        });

        $record['status'] = 'approved';
        $record['session_id'] = $session_id;
        $record['session_token'] = $session_token;
        $record['approved_at'] = gmdate('c', $now);
        self::save_pairing_record($pairing_id, $record);

        self::invalidate_ready_state(sprintf(
            __('A new %s pairing session was approved. Run the smoke test again.', 'livecanvas-forge-ai'),
            $client_label
        ));

        return [
            'ok'         => true,
            'session_id' => $session_id,
            'client'     => $client,
            'connection_mode' => (string) $session['connection_mode'],
            'project_label' => $project_label,
            'site_fingerprint' => (string) $session['site_fingerprint'],
            'scopes' => (array) $session['scopes'],
            'message'    => sprintf(
                __('%1$s pairing approved. Ask %1$s to retry the connection handoff.', 'livecanvas-forge-ai'),
                $client_label
            ),
        ];
    }

    public static function get_pending_pairings(): array {
        self::cleanup_pairing_index();
        $pairings = [];
        foreach (self::get_pairing_index() as $pairing_id) {
            $record = self::get_pairing_record($pairing_id);
            if (!$record || ($record['status'] ?? '') !== 'pending') {
                continue;
            }
            unset($record['device_secret_hash'], $record['session_token']);
            $pairings[] = $record;
        }

        return $pairings;
    }

    public static function get_sessions(bool $include_expired = true): array {
        $sessions = LCFA_Session_Store::read();
        if (!is_array($sessions)) {
            return [];
        }

        $normalized = [];
        foreach ($sessions as $session_id => $session) {
            if (!is_array($session)) {
                continue;
            }
            $session_id = sanitize_key((string) ($session['session_id'] ?? $session_id));
            if ($session_id === '') {
                continue;
            }
            $session['session_id'] = $session_id;
            if (!$include_expired && self::session_is_expired($session)) {
                continue;
            }
            $normalized[$session_id] = $session;
        }

        return $normalized;
    }

    public static function get_public_sessions(): array {
        $public = [];
        foreach (self::get_sessions() as $session) {
            unset($session['token_hash'], $session['worker_request_id']);
            $session['expired'] = self::session_is_expired($session);
            $session['revoked'] = trim((string) ($session['revoked_at'] ?? '')) !== '';
            $public[] = $session;
        }

        usort($public, static function (array $a, array $b): int {
            return strcmp((string) ($b['created_at'] ?? ''), (string) ($a['created_at'] ?? ''));
        });

        return $public;
    }

    public static function revoke_session(string $session_id): array {
        $session_id = sanitize_key($session_id);
        $sessions = self::get_sessions();
        if (empty($sessions[$session_id])) {
            return [
                'ok'      => false,
                'message' => __('The AI Bridge MCP session was not found.', 'livecanvas-forge-ai'),
            ];
        }

        $client_label = self::get_client_label((string) ($sessions[$session_id]['client'] ?? 'codex'));
        LCFA_Session_Store::mutate(static function ($current) use ($session_id) {
            if (isset($current[$session_id])) $current[$session_id]['revoked_at'] = gmdate('c');
            return $current;
        });
        self::invalidate_ready_state(sprintf(
            __('The active %1$s session was revoked. Pair %1$s again before testing.', 'livecanvas-forge-ai'),
            $client_label
        ));

        return [
            'ok'      => true,
            'message' => __('AI Bridge MCP session revoked.', 'livecanvas-forge-ai'),
        ];
    }

    public static function reset_access_state(): array {
        $revoked_sessions = 0;
        $revoked_at = gmdate('c');
        LCFA_Session_Store::mutate(static function ($sessions) use ($revoked_at, &$revoked_sessions) {
            $revoked_sessions = 0;
            foreach ($sessions as $session_id => $session) {
                if (!empty($session['revoked_at']) || self::session_is_expired($session)) continue;
                $sessions[$session_id]['revoked_at'] = $revoked_at;
                $revoked_sessions++;
            }
            return $sessions;
        });

        $pairing_ids = self::get_pairing_index();
        foreach ($pairing_ids as $pairing_id) {
            self::delete_pairing($pairing_id);
        }

        return [
            'revoked_sessions' => $revoked_sessions,
            'cleared_pairings' => count($pairing_ids),
        ];
    }

    public static function get_session_from_request(?WP_REST_Request $request, string $required_scope = 'read') {
        self::$current_session = [];
        if (!$request instanceof WP_REST_Request) {
            return false;
        }

        $token = trim((string) $request->get_header('x-lcfa-mcp-session'));
        if ($token === '') {
            $authorization = trim((string) $request->get_header('authorization'));
            if (stripos($authorization, 'Bearer ') === 0) {
                $token = trim(substr($authorization, 7));
            }
        }
        if ($token === '') {
            $token = sanitize_text_field((string) $request->get_param('mcp_session'));
        }
        if ($token === '') {
            return false;
        }

        $session = self::validate_session_token($token, $required_scope);
        if (!is_array($session)) {
            return $session;
        }

        $package_version = sanitize_text_field((string) $request->get_header('x-lcfa-mcp-package-version'));
        if ($package_version !== '' && preg_match('/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/', $package_version)) {
            $session_id = sanitize_key((string) ($session['session_id'] ?? ''));
            $session = self::touch_session($session_id, self::hash_token($token), ['mcp_package_version' => $package_version, 'mcp_package_seen_at' => gmdate('c')], $session);
            if (!$session) { self::$current_session = []; return false; }
        }

        if (self::is_connection_handoff_request($request)) {
            self::mark_connection_handoff_from_session($session);
        }

        if (!in_array($required_scope, ['read', 'preview'], true) && class_exists('LCFA_Private_Chat', false)) {
            try {
                if (!LCFA_Private_Chat::authorize_session_write($session, $request)) { self::$current_session = []; return false; }
            } catch (Throwable $error) { self::$current_session = []; return false; }
        }

        return $session;
    }

    public static function bind_worker_request(string $request_id): void {
        $expected = self::$current_session;
        $id = (string) ($expected['session_id'] ?? '');
        if ($id === '') throw new RuntimeException('private_worker_unavailable: Reconnect the worker before claiming work.');
        LCFA_Session_Store::mutate(static function ($sessions) use ($id, $expected, $request_id) {
            $current = $sessions[$id] ?? [];
            if (!$current || !self::authorization_matches($current, $expected) || !empty($current['revoked_at']) || self::session_is_expired($current)) throw new RuntimeException('private_worker_unavailable: The worker connection changed during the claim.');
            $sessions[$id]['worker_request_id'] = $request_id;
            return $sessions;
        });
        self::$current_session['worker_request_id'] = $request_id;
    }

    public static function validate_session_token(string $token, string $required_scope = 'read') {
        self::$current_session = [];
        $token_hash = self::hash_token($token);
        $sessions = self::get_sessions();
        foreach ($sessions as $session_id => $session) {
            if (!hash_equals((string) ($session['token_hash'] ?? ''), $token_hash)) {
                continue;
            }
            if (trim((string) ($session['revoked_at'] ?? '')) !== '' || self::session_is_expired($session)) {
                return false;
            }
            if (!empty($session['owner_user_id'])) {
                $capabilities = ['read' => 'edit_pages', 'preview' => 'edit_pages', 'write' => 'edit_pages', 'media' => 'upload_files', 'theme_files' => 'edit_theme_options', 'debug' => 'manage_options', 'cache' => 'manage_options', 'seo' => 'edit_pages'];
                if (!function_exists('user_can') || !user_can((int) $session['owner_user_id'], $capabilities[$required_scope] ?? 'manage_options')) return false;
                if (($session['access_profile'] ?? '') === 'full') {
                    if (!self::owner_can_authorize_full_access((int) $session['owner_user_id'])) return false;
                }
            }
            $session_fingerprint = sanitize_text_field((string) ($session['site_fingerprint'] ?? ''));
            $site_fingerprint = self::get_site_fingerprint();
            if ($session_fingerprint !== '' && $site_fingerprint !== '' && !hash_equals($site_fingerprint, $session_fingerprint)) {
                $client_label = self::get_client_label((string) ($session['client'] ?? 'codex'));
                self::invalidate_ready_state(sprintf(
                    __('The active %1$s session belongs to another AI Bridge site fingerprint. Pair %1$s again.', 'livecanvas-forge-ai'),
                    $client_label
                ));
                return false;
            }
            $scopes = self::sanitize_scopes((array) ($session['scopes'] ?? []));
            if (!self::scope_allows($scopes, $required_scope)) {
                return false;
            }

            $updated = self::touch_session($session_id, $token_hash, ['last_seen_at' => gmdate('c')], $session);
            if (!$updated) return false;
            self::$current_session = $updated;
            return $updated;
        }

        return false;
    }

    private static function authorization_matches(array $current, array $expected): bool {
        foreach (['session_id', 'owner_user_id', 'client', 'site_fingerprint', 'scopes', 'access_profile', 'expires_at'] as $key) {
            if (($current[$key] ?? null) !== ($expected[$key] ?? null)) return false;
        }
        return true;
    }

    private static function touch_session(string $id, string $token_hash, array $fields, array $expected): array {
        $updated = LCFA_Session_Store::mutate(static function ($sessions) use ($id, $token_hash, $fields, $expected) {
            $session = $sessions[$id] ?? [];
            if (!$session || !self::authorization_matches($session, $expected) || !empty($session['revoked_at']) || self::session_is_expired($session) || !hash_equals((string) ($session['token_hash'] ?? ''), $token_hash)) return $sessions;
            $sessions[$id] = array_merge($session, $fields);
            return $sessions;
        });
        $session = $updated[$id] ?? [];
        if (!$session || !self::authorization_matches($session, $expected) || !empty($session['revoked_at']) || self::session_is_expired($session) || !hash_equals((string) ($session['token_hash'] ?? ''), $token_hash)) return [];
        unset($session['token_hash']);
        return $session;
    }

    public static function owner_can_authorize_full_access(int $user_id): bool {
        if ($user_id < 1 || !function_exists('user_can')) return false;
        foreach (['edit_pages', 'upload_files', 'edit_theme_options', 'manage_options'] as $capability) {
            if (!user_can($user_id, $capability)) return false;
        }
        return true;
    }

    public static function has_full_access_context(): bool {
        return self::current_owner_user_id() > 0 && (self::$current_session['access_profile'] ?? '') === 'full'
            && !empty(self::$current_session['owner_user_id'])
            && !self::session_is_expired(self::$current_session)
            && array_diff(LCFA_Agent_Registry::full_access_scopes(), (array) (self::$current_session['scopes'] ?? [])) === [];
    }

    public static function current_worker_request_id(): string {
        if (!self::current_owner_user_id()) return '';
        $session = LCFA_Session_Store::read()[(string) (self::$current_session['session_id'] ?? '')] ?? [];
        return (string) ($session['worker_request_id'] ?? '');
    }

    public static function current_owner_user_id(): int {
        $id = (string) (self::$current_session['session_id'] ?? '');
        $session = $id !== '' ? (self::get_sessions()[$id] ?? []) : [];
        if (!$session || !self::authorization_matches($session, self::$current_session) || !empty($session['revoked_at']) || self::session_is_expired($session)) return 0;
        return (int) ($session['owner_user_id'] ?? 0);
    }

    public static function has_active_session(): bool {
        foreach (self::get_sessions() as $session) {
            if (trim((string) ($session['revoked_at'] ?? '')) === '' && !self::session_is_expired($session)) {
                return true;
            }
        }

        return false;
    }

    public static function current_worker_identity(): array {
        if (!self::current_owner_user_id()) return [];
        return ['session_id' => (string) self::$current_session['session_id'], 'client' => (string) self::$current_session['client']];
    }

    public static function get_latest_verified_session(string $client = '', string $connection_mode = ''): array {
        if (!class_exists('LCFA_Settings', false)) {
            return [];
        }

        $client = $client !== '' ? self::sanitize_client($client) : '';
        $connection_mode = $connection_mode !== '' ? self::sanitize_connection_mode($connection_mode) : '';
        $connections = LCFA_Settings::get_connections();
        $verified_session_id = sanitize_key((string) ($connections['connection_last_handoff_session_id'] ?? ''));
        if ($verified_session_id === '') {
            return [];
        }

        foreach (self::get_sessions() as $session_id => $session) {
            $session_id = sanitize_key((string) ($session['session_id'] ?? $session_id));
            if ($session_id === '' || !hash_equals($verified_session_id, $session_id)) {
                continue;
            }
            if (trim((string) ($session['revoked_at'] ?? '')) !== '' || self::session_is_expired($session)) {
                return [];
            }
            if (trim((string) ($session['last_seen_at'] ?? '')) === '') {
                return [];
            }
            if ($client !== '' && self::sanitize_client((string) ($session['client'] ?? '')) !== $client) {
                return [];
            }
            if ($connection_mode !== '' && self::sanitize_connection_mode((string) ($session['connection_mode'] ?? 'remote')) !== $connection_mode) {
                return [];
            }

            unset($session['token_hash']);
            return $session;
        }

        return [];
    }

    private static function get_pairing_record(string $pairing_id) {
        $pairing_id = sanitize_key($pairing_id);
        $records = self::get_pairing_records();
        $record = $records[$pairing_id] ?? false;
        if (!is_array($record)) {
            $record = get_transient(self::PAIRING_TRANSIENT_PREFIX . $pairing_id);
        }
        return is_array($record) ? $record : false;
    }

    private static function save_pairing_record(string $pairing_id, array $record): void {
        $pairing_id = sanitize_key($pairing_id);
        if ($pairing_id === '') {
            return;
        }

        $records = self::get_pairing_records();
        $records[$pairing_id] = $record;
        update_option(self::PAIRINGS_OPTION_KEY, $records, false);
        set_transient(self::PAIRING_TRANSIENT_PREFIX . $pairing_id, $record, self::PAIRING_TTL);
    }

    private static function get_pairing_records(): array {
        $records = get_option(self::PAIRINGS_OPTION_KEY, []);
        if (!is_array($records)) {
            return [];
        }

        $normalized = [];
        foreach ($records as $pairing_id => $record) {
            $pairing_id = sanitize_key((string) $pairing_id);
            if ($pairing_id === '' || !is_array($record)) {
                continue;
            }
            $normalized[$pairing_id] = $record;
        }

        return $normalized;
    }

    private static function delete_pairing(string $pairing_id): void {
        $pairing_id = sanitize_key($pairing_id);
        delete_transient(self::PAIRING_TRANSIENT_PREFIX . $pairing_id);
        $records = self::get_pairing_records();
        unset($records[$pairing_id]);
        update_option(self::PAIRINGS_OPTION_KEY, $records, false);
        $index = array_values(array_diff(self::get_pairing_index(), [$pairing_id]));
        update_option(self::PAIRING_INDEX_OPTION_KEY, $index, false);
    }

    private static function index_pairing(string $pairing_id): void {
        $index = self::get_pairing_index();
        $index[] = sanitize_key($pairing_id);
        update_option(self::PAIRING_INDEX_OPTION_KEY, array_values(array_unique($index)), false);
    }

    private static function get_pairing_index(): array {
        $index = get_option(self::PAIRING_INDEX_OPTION_KEY, []);
        $index = is_array($index) ? array_values(array_filter(array_map('sanitize_key', $index))) : [];
        return array_values(array_unique(array_merge($index, array_keys(self::get_pairing_records()))));
    }

    private static function cleanup_pairing_index(): void {
        $next = [];
        $records = self::get_pairing_records();
        foreach (self::get_pairing_index() as $pairing_id) {
            $record = self::get_pairing_record($pairing_id);
            if (!$record || self::is_expired((string) ($record['expires_at'] ?? ''))) {
                delete_transient(self::PAIRING_TRANSIENT_PREFIX . $pairing_id);
                unset($records[$pairing_id]);
                continue;
            }
            $next[] = $pairing_id;
        }
        update_option(self::PAIRINGS_OPTION_KEY, $records, false);
        update_option(self::PAIRING_INDEX_OPTION_KEY, array_values(array_unique($next)), false);
    }

    private static function is_pairing_rate_limited(?WP_REST_Request $request) {
        $ip = $request instanceof WP_REST_Request ? (string) ($request->get_header('x-forwarded-for') ?: ($_SERVER['REMOTE_ADDR'] ?? 'unknown')) : 'unknown';
        $key = self::PAIRING_RATE_PREFIX . md5($ip);
        $count = absint(get_transient($key));
        if ($count >= 20) {
            return new WP_Error(
                'lcfa_pairing_rate_limited',
                __('Too many pairing requests. Wait a few minutes and try again.', 'livecanvas-forge-ai'),
                ['status' => 429]
            );
        }
        $minute = defined('MINUTE_IN_SECONDS') ? MINUTE_IN_SECONDS : 60;
        set_transient($key, $count + 1, 5 * $minute);

        return true;
    }

    private static function get_verification_url(string $attempt_id = ''): string {
        return function_exists('admin_url')
            ? admin_url('admin.php?page=lcfa-dashboard&tab=connections' . ($attempt_id !== '' ? '&connection_attempt=' . rawurlencode($attempt_id) . '#lcfa-connect' : '&connection_ui=manual#' . self::PAIRING_ADMIN_ANCHOR))
            : '';
    }

    private static function get_session_expires_at(string $session_id): string {
        $sessions = self::get_sessions();
        return (string) ($sessions[$session_id]['expires_at'] ?? '');
    }

    private static function sanitize_client(string $client): string {
        $client = sanitize_key($client);
        return LCFA_Agent_Registry::normalize($client);
    }

    private static function sanitize_connection_mode(string $mode): string {
        return sanitize_key($mode) === 'local' ? 'local' : 'remote';
    }

    private static function get_client_label(string $client): string {
        return LCFA_Agent_Registry::label($client);
    }

    private static function sanitize_scopes(array $scopes): array {
        $allowed = ['read', 'preview', 'write', 'media', 'theme_files', 'debug', 'cache', 'seo'];
        $normalized = [];
        foreach ($scopes as $scope) {
            $scope = sanitize_key((string) $scope);
            if (in_array($scope, $allowed, true)) {
                $normalized[] = $scope;
            }
        }
        if ($normalized === []) {
            $normalized = ['read', 'preview', 'write'];
        }

        return array_values(array_unique($normalized));
    }

    private static function scope_allows(array $scopes, string $required_scope): bool {
        $required_scope = sanitize_key($required_scope);
        if ($required_scope === '' || $required_scope === 'read') {
            return in_array('read', $scopes, true);
        }
        if ($required_scope === 'preview') {
            return in_array('preview', $scopes, true) || in_array('write', $scopes, true);
        }

        return in_array($required_scope, $scopes, true);
    }

    private static function session_is_expired(array $session): bool {
        return self::is_expired((string) ($session['expires_at'] ?? ''));
    }

    private static function is_expired(string $expires_at): bool {
        $timestamp = strtotime($expires_at);
        return !$timestamp || $timestamp < time();
    }

    private static function invalidate_ready_state(string $message): void {
        if (!class_exists('LCFA_Settings', false)) {
            return;
        }
        $connections = LCFA_Settings::get_connections();
        if ((string) ($connections['connection_status'] ?? '') !== 'ready') {
            return;
        }
        $connections['connection_status'] = 'needs_attention';
        $connections['connection_current_step'] = 'smoke_test';
        $connections['connection_last_error'] = $message;
        LCFA_Settings::update_connections($connections);
    }

    private static function mark_connection_handoff_from_session(array $session): void {
        if (!class_exists('LCFA_Settings', false)) {
            return;
        }

        $connections = LCFA_Settings::get_connections();
        $changed = false;
        $connection_mode = self::sanitize_connection_mode((string) ($session['connection_mode'] ?? 'remote'));
        $session_id = sanitize_key((string) ($session['session_id'] ?? ''));
        $already_ready_for_session = (string) ($connections['connection_status'] ?? '') === 'ready'
            && $session_id !== ''
            && hash_equals((string) ($connections['connection_last_handoff_session_id'] ?? ''), $session_id);
        if ($already_ready_for_session) {
            $package_expected = defined('LCFA_MCP_PACKAGE_VERSION') ? (string) LCFA_MCP_PACKAGE_VERSION : '';
            $package_detected = sanitize_text_field((string) ($session['mcp_package_version'] ?? ''));
            $package_verified = sanitize_text_field((string) ($connections['connection_last_verified_mcp_package_version'] ?? ''));
            $already_ready_for_session = $package_expected !== ''
                && $package_detected !== ''
                && $package_verified !== ''
                && hash_equals($package_expected, $package_detected)
                && hash_equals($package_verified, $package_detected);
        }
        $updates = [
            'preferred_client'       => self::sanitize_client((string) ($session['client'] ?? 'codex')),
            'connection_mode'        => $connection_mode,
            'connection_strategy'    => $connection_mode === 'local' ? 'local-mcp-bridge' : 'ai-bridge-session',
            'connection_last_error'  => '',
            'connection_last_handoff_session_id' => $session_id,
        ];

        if (!$already_ready_for_session) {
            $updates['connection_status'] = '';
            $updates['connection_current_step'] = 'smoke_test';
            $updates['connection_last_verified_at'] = '';
        }

        foreach ($updates as $key => $value) {
            if ((string) ($connections[$key] ?? '') !== $value) {
                $connections[$key] = $value;
                $changed = true;
            }
        }

        $handoff_at = function_exists('current_time') ? current_time('mysql', true) : gmdate('Y-m-d H:i:s');
        if ((string) ($connections['connection_last_handoff_at'] ?? '') !== $handoff_at) {
            $connections['connection_last_handoff_at'] = $handoff_at;
            $changed = true;
        }

        $project_label = sanitize_text_field((string) ($session['project_label'] ?? ''));
        if ($connection_mode === 'remote' && $project_label !== '' && trim((string) ($connections['remote_project_label'] ?? '')) === '') {
            $connections['remote_project_label'] = $project_label;
            $changed = true;
        }

        if ($changed) {
            LCFA_Settings::update_connections($connections);
        }
    }

    private static function is_connection_handoff_request(WP_REST_Request $request): bool {
        if (!method_exists($request, 'get_route')) {
            return false;
        }

        $route = rtrim((string) $request->get_route(), '/');
        $suffix = '/studio/connection-handoff';

        return $route !== '' && substr($route, -strlen($suffix)) === $suffix;
    }

    private static function get_site_fingerprint(): string {
        return class_exists('LCFA_Settings', false) && method_exists('LCFA_Settings', 'get_site_fingerprint')
            ? LCFA_Settings::get_site_fingerprint()
            : '';
    }

    private static function hash_token(string $token): string {
        $salt = function_exists('wp_salt') ? wp_salt('auth') : (defined('AUTH_SALT') ? AUTH_SALT : 'lcfa');
        return hash_hmac('sha256', $token, (string) $salt);
    }

    private static function random_url_token(int $bytes): string {
        try {
            $raw = random_bytes($bytes);
        } catch (Throwable $throwable) {
            $raw = function_exists('wp_generate_password')
                ? wp_generate_password($bytes, true, true)
                : uniqid('lcfa', true) . mt_rand();
        }

        return rtrim(strtr(base64_encode((string) $raw), '+/', '-_'), '=');
    }

    private static function generate_user_code(): string {
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $code = '';
        for ($i = 0; $i < 8; $i++) {
            try {
                $index = random_int(0, strlen($alphabet) - 1);
            } catch (Throwable $throwable) {
                $index = mt_rand(0, strlen($alphabet) - 1);
            }
            $code .= $alphabet[$index];
        }

        return substr($code, 0, 4) . '-' . substr($code, 4);
    }
}
