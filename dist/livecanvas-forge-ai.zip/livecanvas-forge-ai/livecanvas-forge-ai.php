<?php
/**
 * Plugin Name: LiveCanvas AI Bridge
 * Plugin URI: https://livecanvas.com/
 * Description: AI companion and guided setup flow for LiveCanvas, Picostrap, Picowind, and WindPress.
 * Version: 0.2.0-beta.8
 * Requires at least: 6.8
 * Tested up to: 7.1
 * Requires PHP: 8.0
 * Update URI: https://livecanvas.com/ai-bridge
 * Author: The LiveCanvas Team
 * Author URI: https://livecanvas.com/
 * Text Domain: livecanvas-forge-ai
 */

defined('ABSPATH') || exit;

define('LCFA_VERSION', '0.2.0-beta.8');
define('LCFA_MCP_PACKAGE_VERSION', '0.2.0-beta.8');
define('LCFA_MCP_PACKAGE_SPEC', '@livecanvas/ai-bridge-mcp@' . LCFA_MCP_PACKAGE_VERSION);
define('LCFA_FILE', __FILE__);
define('LCFA_DIR', plugin_dir_path(__FILE__));
define('LCFA_URL', plugin_dir_url(__FILE__));

$lcfa_composer_autoload = LCFA_DIR . 'vendor/autoload.php';
if (is_readable($lcfa_composer_autoload)) {
    require_once $lcfa_composer_autoload;
}

require_once LCFA_DIR . 'includes/class-lcfa-agent-registry.php';
require_once LCFA_DIR . 'includes/class-lcfa-settings.php';
require_once LCFA_DIR . 'includes/class-lcfa-oauth-storage.php';
if (
    class_exists('League\\OAuth2\\Server\\AuthorizationServer')
    && class_exists('Nyholm\\Psr7\\ServerRequest')
) {
    require_once LCFA_DIR . 'includes/class-lcfa-oauth-entities.php';
    require_once LCFA_DIR . 'includes/class-lcfa-oauth-repositories.php';
    require_once LCFA_DIR . 'includes/class-lcfa-oauth-server.php';
}
require_once LCFA_DIR . 'includes/class-lcfa-environment.php';
require_once LCFA_DIR . 'includes/class-lcfa-render-target.php';
require_once LCFA_DIR . 'includes/class-lcfa-site-knowledge.php';
require_once LCFA_DIR . 'includes/class-lcfa-write-contract.php';
require_once LCFA_DIR . 'includes/class-lcfa-workflows.php';
require_once LCFA_DIR . 'includes/class-lcfa-changesets.php';
require_once LCFA_DIR . 'includes/class-lcfa-private-store.php';
require_once LCFA_DIR . 'includes/class-lcfa-desktop-delivery.php';
require_once LCFA_DIR . 'includes/class-lcfa-private-chat.php';
LCFA_Render_Target::hooks();
LCFA_Write_Contract::hooks();
require_once LCFA_DIR . 'includes/class-lcfa-stack-capabilities.php';
require_once LCFA_DIR . 'includes/class-lcfa-framework-compatibility.php';
require_once LCFA_DIR . 'includes/class-lcfa-connection-diagnostics.php';
require_once LCFA_DIR . 'includes/class-lcfa-github-updater.php';
require_once LCFA_DIR . 'includes/class-lcfa-framework-prerequisites.php';
require_once LCFA_DIR . 'includes/class-lcfa-installer.php';
require_once LCFA_DIR . 'includes/class-lcfa-inventory.php';
require_once LCFA_DIR . 'includes/class-lcfa-genesis-planner.php';
require_once LCFA_DIR . 'includes/class-lcfa-genesis-executor.php';
require_once LCFA_DIR . 'includes/class-lcfa-windpress-bridge.php';
require_once LCFA_DIR . 'includes/class-lcfa-theme-files-bridge.php';
require_once LCFA_DIR . 'includes/class-lcfa-local-mcp-bridge.php';
require_once LCFA_DIR . 'includes/class-lcfa-mcp-session-manager.php';
require_once LCFA_DIR . 'includes/class-lcfa-codex-config-manager.php';
require_once LCFA_DIR . 'includes/class-lcfa-connection-tester.php';
require_once LCFA_DIR . 'includes/class-lcfa-codex-autorunner.php';
require_once LCFA_DIR . 'includes/class-lcfa-remote-client.php';
require_once LCFA_DIR . 'includes/class-lcfa-design-system-build-gateway.php';
require_once LCFA_DIR . 'includes/class-lcfa-picostrap-compile-manifest.php';
require_once LCFA_DIR . 'includes/class-lcfa-picostrap-bundle-store.php';
require_once LCFA_DIR . 'includes/class-lcfa-picostrap-compile-service.php';
require_once LCFA_DIR . 'includes/class-lcfa-design-system-picostrap-executor.php';
require_once LCFA_DIR . 'includes/class-lcfa-design-system-picowind-executor.php';
require_once LCFA_DIR . 'includes/class-lcfa-design-system-fallback-executor.php';
require_once LCFA_DIR . 'includes/class-lcfa-design-system-apply.php';
require_once LCFA_DIR . 'includes/class-lcfa-design-system-preview.php';
require_once LCFA_DIR . 'includes/class-lcfa-design-system-picostrap-composer.php';
require_once LCFA_DIR . 'includes/class-lcfa-design-system-compose.php';
require_once LCFA_DIR . 'includes/class-lcfa-content-patch-service.php';
require_once LCFA_DIR . 'includes/class-lcfa-media-tools.php';
require_once LCFA_DIR . 'includes/class-lcfa-debug-cache-tools.php';
require_once LCFA_DIR . 'includes/class-lcfa-polylang-seo-tools.php';
require_once LCFA_DIR . 'includes/class-lcfa-page-runtime.php';
require_once LCFA_DIR . 'includes/class-lcfa-theme-library-catalog.php';
require_once LCFA_DIR . 'includes/class-lcfa-theme-library-validator.php';
require_once LCFA_DIR . 'includes/class-lcfa-theme-library-installer.php';
require_once LCFA_DIR . 'includes/class-lcfa-theme-library-importer.php';
require_once LCFA_DIR . 'includes/class-lcfa-theme-library-rollback.php';
require_once LCFA_DIR . 'includes/class-lcfa-connection-bundle-builder.php';
require_once LCFA_DIR . 'includes/class-lcfa-connection-artifact-writer.php';
require_once LCFA_DIR . 'includes/class-lcfa-connection-onboarding.php';
require_once LCFA_DIR . 'includes/class-lcfa-direct-agent-onboarding.php';
require_once LCFA_DIR . 'includes/class-lcfa-power-mode.php';
require_once LCFA_DIR . 'includes/class-lcfa-connection-wizard-presenter.php';
require_once LCFA_DIR . 'includes/class-lcfa-admin-hero-presenter.php';
require_once LCFA_DIR . 'includes/class-lcfa-workspace-access.php';
require_once LCFA_DIR . 'includes/class-lcfa-prompt-suggester.php';
require_once LCFA_DIR . 'includes/class-lcfa-ai-client.php';
require_once LCFA_DIR . 'includes/class-lcfa-context-builder.php';
require_once LCFA_DIR . 'includes/class-lcfa-command-deck.php';
require_once LCFA_DIR . 'includes/class-lcfa-block-patterns.php';
require_once LCFA_DIR . 'includes/class-lcfa-ability-registry.php';
require_once LCFA_DIR . 'includes/class-lcfa-rest-api.php';
require_once LCFA_DIR . 'includes/class-lcfa-admin.php';
require_once LCFA_DIR . 'includes/class-lcfa-connection-screen.php';
require_once LCFA_DIR . 'includes/class-lcfa-plugin.php';

register_activation_hook(LCFA_FILE, ['LCFA_Plugin', 'activate']);
register_deactivation_hook(LCFA_FILE, ['LCFA_Plugin', 'deactivate']);

function lcfa(): LCFA_Plugin {
    return LCFA_Plugin::instance();
}

lcfa();
